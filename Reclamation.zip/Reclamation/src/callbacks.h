#include <gtk/gtk.h>


void
on_radiobutton1_complexrec_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton8_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton10_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton1_accrec_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button1_retajt_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_ajouterrr_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_rec_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button2_ajoutrec_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_modrec_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_suprec_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_rechrec_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_afficher_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_complexrec_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_malrec_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_qualrec_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton1_accrec_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_complexrec_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_malrec_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_qualrec_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button1_modrec_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_rech_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3_retrech_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_CAlcRe_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_AffStat_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_retStat_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button44_stat_clicked               (GtkButton       *button,
                                        gpointer         user_data);
