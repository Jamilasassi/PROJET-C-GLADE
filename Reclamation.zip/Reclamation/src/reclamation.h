#include<gtk/gtk.h>

typedef struct
{
int jour;
int mois;
int annee;
int heure;
int minute;
}DATE;
typedef struct
{
char id[10];
char idListe[10];
DATE date;
char nom[50];
char prenom[50];
char email[50];
char salle[20];
char objet[100];
char description[100];
}reclamation;
typedef struct
{
	char Nom[20];
	char Prenom[20];
	int jour;
	int mois;
	int annee;
        char Region[20];
	int sexe;
	int Nationnalite;
	int CIN;
	int id;
	int Numero_de_telephone;
	int Role;
	int nbv;
	char mail[50];
	char mot_de_passe[15];
	int vote;
        int age;
}utilisateur;

void ajouterReclamation(reclamation r);
void afficherreclamation(GtkWidget *liste);
void modifierReclamation(reclamation r);
void supprimerReclamation(char id []);
int remplirtabRech (reclamation tab[],int nb);
int rechercherReclamation(char id[]);
void afficherreclamationRech(GtkWidget *liste);
void TPHF(char*file,char*hom,char*fem);
int nbrdeReclamation(char idliste[],char *fichierreclamation);
int nbrreclamation(char*file);



