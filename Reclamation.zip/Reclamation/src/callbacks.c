#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "reclamation.h"
int x,l;
char Nbf[20];
char Nbh[20];
char NBrL[20];
char NBT[20];
////////////////////radio boutton
void
on_radiobutton1_complexrec_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{x=1;}
}
void
on_radiobutton1_malrec_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{x=2;}
}


void
on_radiobutton1_qualrec_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{x=3;}
}

/////////////////////check boutton
void
on_checkbutton1_accrec_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{l=1;}
}

/////////////retour fenetre ajouter
void
on_button1_retajt_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowajouter, *windowreclamation;
windowajouter=lookup_widget(button,"Ajouterreclamation");
gtk_widget_destroy(windowajouter);
windowreclamation=create_Reclamation();
gtk_widget_show (windowreclamation);
}

//////////////////boutton ajouter
void
on_button1_ajouterrr_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
reclamation r;
GtkWidget *id,*idll,*jour,*mois,*annee,*heure,*minute,*nom,*prenom,*email,*salle,*objet,*desc,*output,*output1;

id = lookup_widget(button,"entry1_idrec");
idll = lookup_widget(button,"entry1_idlistR");
jour = lookup_widget(button,"spinbutton1_datej");
mois = lookup_widget(button,"spinbutton1_datem");
annee = lookup_widget(button,"spinbutton1_datean");
heure = lookup_widget(button,"spinbutton1_dateh");
minute = lookup_widget(button,"spinbutton1_datem");
nom = lookup_widget(button,"entry1_nomrec");
prenom = lookup_widget(button,"entry1_prenorec");
email = lookup_widget(button,"entry1_mailrec");
salle=lookup_widget(button,"combobox1_sallerec");
desc = lookup_widget(button,"entry1_desc");
strcpy(r.id,gtk_entry_get_text(GTK_ENTRY(id)));
strcpy(r.idListe,gtk_entry_get_text(GTK_ENTRY(idll)));
r.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (jour));
r.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (mois));
r.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (annee));
r.date.heure=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (heure));
r.date.minute=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (minute));
strcpy(r.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(r.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(r.email,gtk_entry_get_text(GTK_ENTRY(email)));
strcpy(r.salle,gtk_combo_box_get_active_text(GTK_COMBO_BOX(salle)));
strcpy(r.description,gtk_entry_get_text(GTK_ENTRY(desc)));
if(x==1)
{strcpy(r.objet,"la_complexite_de_lapplication");} 
else if (x==2)
{strcpy(r.objet,"la_maltraitance_par_les employes");}
else
{strcpy(r.objet,"la_qualite_de_lapplication");}

if (l==1)
{
ajouterReclamation(r);


output1=lookup_widget(button,"label1_ajoutsuc");
gtk_label_set_text(GTK_LABEL(output1), "Ajouter avec Succes");
}


x=0;
l=0;


}

//////////////////treeview 
void
on_treeview1_rec_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

GtkTreeIter iter;
gchar* id;
gchar* idll;
gchar* jour;
gchar* mois;
gchar* annee;
gchar* heure;
gchar* minute;
gchar* nom;
gchar* prenom;
gchar* email;
gchar* salle;
gchar* objet;
gchar* desc;
reclamation r;
GtkTreeModel *model= gtk_tree_view_get_model(treeview);
GtkWidget* windowajout,*windowreclamation,*tre,*idd,*idl,*jj,*mm,*aa,*h,*m,*no,*pre,*mail,*sal,*des;

if (gtk_tree_model_get_iter(model, &iter,path))
{


gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&id,1,&idl,2,&jour,3,&mois,4,&annee,5,&heure,6,&minute,7,&nom,8,&prenom,9,&email,10,&salle,11,&objet,12,&desc,-1);

windowajout=create_Ajouterreclamation();
windowreclamation=create_Reclamation();
gtk_widget_hide(windowreclamation);
gtk_widget_show(windowajout);

idd=lookup_widget(windowajout,"entry1_idrec");
gtk_entry_set_text(GTK_ENTRY(idd),id);

idl=lookup_widget(windowajout,"entry1_idlistR");
gtk_entry_set_text(GTK_ENTRY(idl),idll);

jj=lookup_widget(windowajout,"spinbutton1_datej");
gtk_entry_set_text(GTK_ENTRY(jj),jour);

mm=lookup_widget(windowajout,"spinbutton1_datem");
gtk_entry_set_text(GTK_ENTRY(mm),mois);

aa=lookup_widget(windowajout,"spinbutton1_datean");
gtk_entry_set_text(GTK_ENTRY(aa),annee);

h=lookup_widget(windowajout,"spinbutton1_dateh");
gtk_entry_set_text(GTK_ENTRY(h),heure);

m=lookup_widget(windowajout,"spinbutton1_datemm");
gtk_entry_set_text(GTK_ENTRY(m),minute);

no=lookup_widget(windowajout,"entry1_nomrec");
gtk_entry_set_text(GTK_ENTRY(no),nom);

pre=lookup_widget(windowajout,"entry1_prenorec");
gtk_entry_set_text(GTK_ENTRY(pre),prenom);

mail=lookup_widget(windowajout,"entry1_mailrec");
gtk_entry_set_text(GTK_ENTRY(mail),email);

des=lookup_widget(windowajout,"entry1_desc");
gtk_entry_set_text(GTK_ENTRY(des),desc);


}
}
/////////////////aff fenetre ajouter

void
on_button2_ajoutrec_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowajout,*windowreclamation;

windowreclamation=lookup_widget(button,"Reclamation");
gtk_widget_destroy(windowreclamation);
windowajout=create_Ajouterreclamation();
gtk_widget_show(windowajout);

}
/////////////////aff fenetre modifier

void
on_button2_modrec_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowajouter, *windowreclamation;
windowreclamation=lookup_widget(button,"Reclamation");
gtk_widget_destroy(windowreclamation);
windowajouter=create_Ajouterreclamation();
gtk_widget_show (windowajouter);

}
///////////////////boutton supprimer

void
on_button2_suprec_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
char identi[20];
GtkWidget *windowreclamation,*tree, *iden,*output;
iden = lookup_widget(button,"entry2_supp");
strcpy(identi,gtk_entry_get_text(GTK_ENTRY(iden)));
supprimerReclamation(identi);
windowreclamation=lookup_widget(button,"Reclamation");
tree=lookup_widget(windowreclamation,"treeview1_rec");
afficherreclamation(tree);
output=lookup_widget(button,"label1_supp");
gtk_label_set_text(GTK_LABEL(output), "Supprimer avec Succes");



}

////////////////aff window rech
void
on_button2_rechrec_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowrechercher, *windowreclamation;
windowreclamation=lookup_widget(button,"Reclamation");
gtk_widget_destroy(windowreclamation);
windowrechercher=create_window_rechercher();
gtk_widget_show (windowrechercher);

}
/////////////afficher

void
on_button2_afficher_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *tree,*windowreclamation;

windowreclamation=create_Reclamation();
tree=lookup_widget(windowreclamation,"treeview1_rec");

afficherreclamation(tree);

gtk_widget_hide(windowreclamation);
gtk_widget_show(windowreclamation);

}
///////////////////modifierr
void
on_button1_modrec_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
reclamation r1;
GtkWidget *windowajout,
*windowreclamation,*id1,*idll1,*jour1,*mois1,*annee1,*heure1,*minute1,*nom1,*prenom1,*email1,*salle1,*objet1,*desc1,*accepte1;
windowajout=create_Ajouterreclamation();
windowreclamation=create_Reclamation();
id1 = lookup_widget(button,"entry1_idrec");
idll1 = lookup_widget(button,"entry1_idlistR");
jour1 = lookup_widget(button,"spinbutton1_datej");
mois1 = lookup_widget(button,"spinbutton1_datem");
annee1 = lookup_widget(button,"spinbutton1_datean");
heure1 = lookup_widget(button,"spinbutton1_dateh");
minute1 = lookup_widget(button,"spinbutton1_datem");
nom1 = lookup_widget(button,"entry1_nomrec");
prenom1 = lookup_widget(button,"entry1_prenorec");
email1 = lookup_widget(button,"entry1_mailrec");
salle1=lookup_widget(button,"combobox1_sallerec");
desc1=lookup_widget(button,"entry1_desc");
strcpy(r1.id,gtk_entry_get_text(GTK_ENTRY(id1)));
strcpy(r1.idListe,gtk_entry_get_text(GTK_ENTRY(idll1)));
r1.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (jour1));
r1.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (mois1));
r1.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (annee1));
r1.date.heure=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (heure1));
r1.date.minute=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (minute1));
strcpy(r1.nom,gtk_entry_get_text(GTK_ENTRY(nom1)));
strcpy(r1.prenom,gtk_entry_get_text(GTK_ENTRY(prenom1)));
strcpy(r1.email,gtk_entry_get_text(GTK_ENTRY(email1)));
strcpy(r1.salle,gtk_combo_box_get_active_text(GTK_COMBO_BOX(salle1)));
strcpy(r1.description,gtk_entry_get_text(GTK_ENTRY(desc1)));
if(x==1)
{strcpy(r1.objet,"la_complexite_de_lapplication");} 
else if (x==2)
{strcpy(r1.objet,"la_maltraitance_par_les employes");}
else
{strcpy(r1.objet,"la_qualite_de_lapplication");}
 if (l==1)
{
modifierReclamation(r1);}
x=0;
l=0;
windowajout=lookup_widget(button,"Ajouterreclamation");
gtk_widget_destroy(windowajout);
windowreclamation=create_Reclamation();
gtk_widget_show(windowreclamation);

}


void
on_treeview1_rech_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}

////////////////////// button rech 
void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
char ident[20];
GtkWidget *id,*tree,*windowrechercher,*output;
int ce;
windowrechercher=lookup_widget(button,"window_rechercher");
id = lookup_widget(button,"entry3_rech");
strcpy(ident,gtk_entry_get_text(GTK_ENTRY(id)));

ce=rechercherReclamation(ident);

if (ce==0)
	{

	output=lookup_widget(button,"label_rechercher");
	gtk_label_set_text(GTK_LABEL(output), "Reclamation INTROUVABLE");
	}
if (ce==1)	
	{	

tree=lookup_widget(windowrechercher,"treeview1_rech");
afficherreclamationRech(tree);
}
}


void
on_button3_retrech_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowrechercher, *windowreclamation;
windowrechercher=lookup_widget(button,"window_rechercher");
gtk_widget_destroy(windowrechercher);
windowreclamation=create_Reclamation();
gtk_widget_show (windowreclamation);
}


void
on_button2_CAlcRe_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowstat, *windowreclamation;
windowreclamation=lookup_widget(button,"Reclamation");
gtk_widget_destroy(windowreclamation);
windowstat=create_window_stat();
gtk_widget_show (windowstat);
}


void
on_button4_AffStat_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *output,*output1,*output2;
int nbhomm;
int nbf;


TPHF("utilisateur.txt","homme.txt","femme.txt");
output1 = lookup_widget(button, "label4_TpH") ;
nbhomm=nombre_dehomme("homme.txt");
sprintf(Nbh,"%d",nbhomm);
gtk_label_set_text(GTK_LABEL(output1),Nbh);
output2 = lookup_widget(button, "label4_TpF") ;
nbf=nombre_defemme("femme.txt");
sprintf(Nbf,"%d",nbf);
gtk_label_set_text(GTK_LABEL(output2),Nbf);


}


void
on_button4_retStat_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowstat, *windowreclamation;
windowstat=lookup_widget(button,"window_stat");
gtk_widget_destroy(windowstat);
windowreclamation=create_Reclamation();
gtk_widget_show (windowreclamation);
}


void
on_button44_stat_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *idl,*output3,*output4;
int nbrl;
int nbrt;
char idliste[10];
idl=lookup_widget(button,"entry1_nbrliste");
strcpy(idliste,gtk_entry_get_text(GTK_ENTRY(idl)));
nbrl=nbrdeReclamation(idliste,"Reclamation.txt");
output3 = lookup_widget(button,"label4_nbrliste") ;
sprintf(NBrL,"%d",nbrl);
gtk_label_set_text(GTK_LABEL(output3),NBrL);
nbrt=nbrreclamation("nbrdereclamation.txt");
output4 = lookup_widget(button, "label4_nbrtot") ;
sprintf(NBT,"%d",nbrt);
gtk_label_set_text(GTK_LABEL(output4),NBT);
}

