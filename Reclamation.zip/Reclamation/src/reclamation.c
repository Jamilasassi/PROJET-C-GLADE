#ifdef HAVE_CONFIG_H
#include <config.h>
#endif
#include "reclamation.h"
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<gtk/gtk.h>

enum
{ 
	EID,
	EIDLIST,
	EJOUR,
	EMOIS,
	EANNEE,
	EHEURE,
	EMINUTE,
	ENOM,
	EPRENOM,
	EEMAIL,
	ESALLE,
	EOBJET,
	EDESCRIP,
	COLUMNS,
};

/////////////////////////////////////Fonction Ajouter
void ajouterReclamation(reclamation r)
{
    FILE * f;
    f=fopen("Reclamation.txt", "a+");
   
        fprintf(f,"%s %s %d %d %d %d %d %s %s %s %s %s %s \n",r.id,r.idListe,r.date.jour,r.date.mois,r.date.annee,r.date.heure,r.date.minute,r.nom,r.prenom,r.email,r.salle,r.objet,r.description);
        fclose(f);
}

/////////////////////////////////////Fonction Afficherrrrrrr
void afficherreclamation(GtkWidget *liste){

GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	char id[30];
	char idList[10];
	char jour[10];
	char mois[10];
	char annee[10];
	char heure[10];
	char minute[10];
	char nom[30];
	char prenom[30];
	char email[30];
	char salle[10];
	char objet[100];
	char description[100];
	store=NULL;
	FILE *f;
	store=gtk_tree_view_get_model (liste);
	if (store==NULL)
	{
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("identifiant", renderer, "text",EID,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("idList", renderer, "text",EIDLIST,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);


	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("jour", renderer, "text",EJOUR,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("mois", renderer, "text",EMOIS,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("annee", renderer, "text",EANNEE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("heure", renderer, "text",EHEURE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("minute", renderer, "text",EMINUTE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("nom", renderer, "text",ENOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("prenom", renderer, "text",EPRENOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("email", renderer, "text",EEMAIL,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("salle", renderer, "text",ESALLE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("objet", renderer, "text",EOBJET,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("description", renderer, "text",EDESCRIP,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	}
	store=gtk_list_store_new (COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,  G_TYPE_STRING,   G_TYPE_STRING, G_TYPE_STRING,  G_TYPE_STRING,  G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
	f=fopen("Reclamation.txt","r");
	if(f==NULL)
	{
		return;
	}
	else
	{
		f= fopen("Reclamation.txt","a+");
		while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s %s \n",id,idList,jour,mois,annee,heure,minute,nom,prenom,email,salle,objet,description)!=EOF)
		{
			gtk_list_store_append(store, &iter);
			gtk_list_store_set(store,&iter, EID, id , EIDLIST , idList , EJOUR,jour, EMOIS, mois, EANNEE, annee, EHEURE, heure ,EMINUTE ,minute,  ENOM, nom,EPRENOM,prenom, EEMAIL , email, ESALLE, salle, EOBJET,objet ,EDESCRIP, description,-1);
		}
		fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
		g_object_unref (store);
	}
}

///////////////////////////////Foction MOdifier
void modifierReclamation(reclamation r1){
reclamation r;
FILE *f1;
FILE *f2;
f1=fopen("Reclamation.txt","r");
f2=fopen("reclMod.txt","a");

if((f1!=NULL)&&(f2!=NULL))
{
while(fscanf(f1,"%s %s %d %d %d %d %d %s %s %s %s %s %s \n",r.id,r.idListe,&r.date.jour,&r.date.mois,&r.date.annee,&r.date.heure,&r.date.minute,r.nom,r.prenom,r.email,r.salle,r.objet,r.description)!=EOF)
	{
	if(strcmp(r.id,r1.id)==0)
		{
		fprintf(f2,"%s %s %d %d %d %d %d %s %s %s %s %s %s \n",r1.id,r1.idListe,r1.date.jour,r1.date.mois,r1.date.annee,r1.date.heure,r1.date.minute,r1.nom,r1.prenom,r1.email,r1.salle,r1.objet,r1.description);
		}
	else
		{
		fprintf(f2,"%s %s %d %d %d %d %d %s %s %s %s %s %s \n",r.id,r.idListe,r.date.jour,r.date.mois,r.date.annee,r.date.heure,r.date.minute,r.nom,r.prenom,r.email,r.salle,r.objet,r.description);
		}
	}

}
fclose(f1);
fclose(f2);
remove("Reclamation.txt");
rename("reclMod.txt","Reclamation.txt");

}
////////////////////////////////////Fonction Supprimerrr
void supprimerReclamation(char id [])
{
reclamation r;
FILE *f1;
FILE *f2;

f1=fopen("Reclamation.txt","r");
f2=fopen("recl.txt","w");
while(fscanf(f1,"%s %s %d %d %d %d %d %s %s %s %s %s %s \n",r.id,r.idListe,&r.date.jour,&r.date.mois,&r.date.annee,&r.date.heure,&r.date.minute,r.nom,r.prenom,r.email,r.salle,r.objet,r.description)!=EOF)
{if (strcmp(id,r.id)!=0)
fprintf(f2,"%s %s %d %d %d %d %d %s %s %s %s %s %s \n",r.id,r.idListe,r.date.jour,r.date.mois,r.date.annee,r.date.heure,r.date.minute,r.nom,r.prenom,r.email,r.salle,r.objet,r.description);
}
fclose(f1);
fclose(f2);
remove("Reclamation.txt");
rename("recl.txt","Reclamation.txt");
}

//////////////////////////Fonction Rechercher //////////////////////////

int rechercherReclamation(char id[])
{
reclamation r;
FILE *f1;
FILE *f2;
int k=0;
f1=fopen("Reclamation.txt","r");
f2=fopen("Reclamrechercher.txt","w");
while(fscanf(f1,"%s %s %d %d %d %d %d %s %s %s %s %s %s \n",r.id,r.idListe,&r.date.jour,&r.date.mois,&r.date.annee,&r.date.heure,&r.date.minute,r.nom,r.prenom,r.email,r.salle,r.objet,r.description)!=EOF)
{if (strcmp(id,r.id)==0)
fprintf(f2,"%s %s %d %d %d %d %d %s %s %s %s %s %s \n",r.id,r.idListe,r.date.jour,r.date.mois,r.date.annee,r.date.heure,r.date.minute,r.nom,r.prenom,r.email,r.salle,r.objet,r.description);
k=1;
}
fclose(f1);
fclose(f2);
 return k;
}

//////////////////////////Fonction Afficher Rechercher //////////////////////////

void afficherreclamationRech(GtkWidget *liste){
GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	char id[30];
	char idList[10];
	char jour[10];
	char mois[10];
	char annee[10];
	char heure[10];
	char minute[10];
	char nom[30];
	char prenom[30];
	char email[30];
	char salle[10];
	char objet[100];
	char description[100];
	store=NULL;
	FILE *f;
	store=gtk_tree_view_get_model (liste);
	if (store==NULL)
	{
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("identifiant", renderer, "text",EID,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("idList", renderer, "text",EIDLIST,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);


	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("jour", renderer, "text",EJOUR,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("mois", renderer, "text",EMOIS,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("annee", renderer, "text",EANNEE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("heure", renderer, "text",EHEURE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("minute", renderer, "text",EMINUTE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("nom", renderer, "text",ENOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("prenom", renderer, "text",EPRENOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("email", renderer, "text",EEMAIL,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("salle", renderer, "text",ESALLE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("objet", renderer, "text",EOBJET,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("description", renderer, "text",EDESCRIP,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	}
	store=gtk_list_store_new (COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,  G_TYPE_STRING,   G_TYPE_STRING, G_TYPE_STRING,  G_TYPE_STRING,  G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
	f=fopen("Reclamrechercher.txt","r");
	if(f==NULL)
	{
		return;
	}
	else
	{
		f= fopen("Reclamrechercher.txt","a+");
		while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s %s \n",id,idList,jour,mois,annee,heure,minute,nom,prenom,email,salle,objet,description)!=EOF)
		{
			gtk_list_store_append(store, &iter);
			gtk_list_store_set(store,&iter, EID, id , EIDLIST , idList , EJOUR,jour, EMOIS, mois, EANNEE, annee, EHEURE, heure ,EMINUTE ,minute,  ENOM, nom,EPRENOM,prenom, EEMAIL , email, ESALLE, salle, EOBJET,objet ,EDESCRIP, description,-1);
		}
		fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
		g_object_unref (store);
	}
}
/////////////////////////

///////////////////////////
void TPHF(char*file,char*hom,char*fem)
{utilisateur u;
int nbE=0;
int nbH=0;
int nbF=0;
int Th=0;
int Tf=0;
remove("homme.txt");
remove("femme.txt");
FILE *f=fopen(file ,"r");
FILE *f1=fopen(hom ,"a");
FILE *f2=fopen(fem ,"a");
if (f!=NULL)
{ while (fscanf (f,"%s %s %d %d %d %s %d %d %d %d %d %d %d %s %s %d %d \n",u.Nom,u.Prenom,&u.jour,&u.mois,&u.annee,u.Region,&u.sexe,&u.Nationnalite,&u.CIN,&u.id,&u.Numero_de_telephone,&u.Role,&u.nbv,u.mail,u.mot_de_passe,&u.vote,&u.age) !=EOF){
			
		if(u.sexe==0)
			{nbH++;}
		if (u.sexe==1)
			{nbF++;}
		}
nbE=nbE+1;
			
}
Th=nbH/nbE;
Tf=nbF/nbE;
fprintf(f1,"%d\n",Th);
fprintf(f2,"%d\n",Tf);




fclose (f);
fclose (f1);
fclose (f2);
}
///////////////////////////////////////
int nombre_dehomme(char*file)
{
int nbH;
FILE *f=fopen(file ,"r");
fscanf (f,"%d\n",&nbH);

return nbH;
}
////////////////////////////////////////
int nombre_defemme(char*file)
{
int nbF;
FILE *f=fopen(file ,"r");
fscanf (f,"%d\n",&nbF);
return nbF;
}
//////////////////////////////////////////////
int nbrdeReclamation(char idliste[],char *fichierreclamation)
{
reclamation r;
int nbr=0;
int nbl=0;
FILE *f1;
FILE *f2;
f1=fopen(fichierreclamation,"r");
f2=fopen("nbrdereclamation.txt","w");
while(fscanf(f1,"%s %s %d %d %d %d %d %s %s %s %s %s %s \n",r.id,r.idListe,&r.date.jour,&r.date.mois,&r.date.annee,&r.date.heure,&r.date.minute,r.nom,r.prenom,r.email,r.salle,r.objet,r.description)!=EOF){
if (strcmp(r.idListe,idliste) == 0){
nbl++;
}
nbr=nbr+1;
}
fprintf(f2,"%d\n",nbr);
fclose(f1);
fclose(f2);
 return nbl;
}
////////////////////////////////////////////
int nbrreclamation(char*file)
{
int nbr;
FILE *f=fopen(file ,"r");
fscanf (f,"%d\n",&nbr);
return nbr;
}


