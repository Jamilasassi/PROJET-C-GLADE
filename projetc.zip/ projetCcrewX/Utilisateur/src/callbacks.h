#include <gtk/gtk.h>


void
on_radiobutton1_nn_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton1_confAjt_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_AjouterEl_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_retEl_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_blan_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton1_confAjt_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_1_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_0_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_confirmer_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_retourmod_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_modifier_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_afficher_row_activated    (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button3_ajouter_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3_chercher_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3_supprimer_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3_afficher_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview2_affcherch_row_activated   (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button4_retourChercher_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_homme_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_femme_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_homme_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_femme_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button1_Inscription_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_connexion_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton2_1_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button3_modifier_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_chercher_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_deconnexion_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_stat_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_afficherTPHF_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3_trie_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_trii_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button4_retStat_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_observateur_clicked                 (GtkButton       *button,
                                        gpointer         user_data);
///////////////////obs///////////////////
void
on_confirmerao_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_retourao_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_confirmermo_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_retourmo_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_supo_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_retoursupp_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_retourchercher_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_chero_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_ajoutero_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifiero_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_supprimero_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_cherchero_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_affichero_clicked                   (GtkButton       *button,
                                        gpointer         user_data);
////////////////////////////election////////////////
void
on_button2_ajouter_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_restau_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_general_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_nv_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_anc_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button2_rajout_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_nbr4_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_nbr3_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_nbr2_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_nbr1_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_nbr5_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_nbr6_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton1_confirmer_clicked      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button1_ajouterElection_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_retourajt_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_affElection_row_activated (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button2_windAjouter_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_windModif_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_rechElect_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_SuppElect_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_affElect_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_nbr7_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton1_confirmer_toggled      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_nbr1_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_nbr2_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_nbr3_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_nbr4_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_nbr5_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_nbr7_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_nbr6_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button3_reche_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3_retrecher_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbutton1_confi_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button1_ModifierElection_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_retourajt_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_recElect_row_activated    (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button2_tachcalcul_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview4_TPHF_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button4_retCAl_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3_calculEl_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_nbhhh_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_nbffff_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_election_clicked                    (GtkButton       *button,
                                        gpointer         user_data);
//////////////////liste///////////////
void
on_button1_retourAjout_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_ajouter_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_centre_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_droite_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_gauch_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_treeview1_affListe_row_activated    (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button2_recherche_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton2_gauche_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_centre_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_droite_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton1_accept_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button2_retourMenu_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_supprimer_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_affiche_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_modifier_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_gerliste_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_fentajout_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_gerliste_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_fentajout_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_gerliste_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_fentajout_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3_affvote_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3_affStat_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonvalidv_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_retous_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttontri_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_retv_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview_stat_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_treeview_stat_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_treeview1_affListe_row_activated    (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button2_affiche_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_listeelec_clicked                   (GtkButton       *button,
                                        gpointer         user_data);
////////////////////////////BV/////////////////
void
on_button1_clicked                     (GtkWidget *objet_graphique, gpointer user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton5_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkWidget *objet_graphique, gpointer user_data);

void
on_button8_clicked                     (GtkWidget *objet_graphique, gpointer user_data);

void
on_button6_clicked                     (GtkWidget *objet_graphique, gpointer user_data);

void
on_button3_clicked                     (GtkWidget *objet_graphique, gpointer user_data);

void
on_button5_clicked                     (GtkWidget *objet_graphique, gpointer user_data);

void
on_button4_clicked                     (GtkWidget *objet_graphique, gpointer user_data);

void
on_button9_clicked                     (GtkWidget *objet_graphique, gpointer user_data);

void
on_button7_clicked                     (GtkWidget *objet_graphique, gpointer user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button10_clicked                    (GtkWidget *objet_graphique, gpointer user_data);

void
on_button11_clicked                    (GtkWidget *objet_graphique, gpointer user_data);

void
on_button13_clicked                    (GtkWidget *objet_graphique, gpointer user_data);

void
on_button15_clicked                    (GtkWidget *objet_graphique, gpointer user_data);

void
on_button14_clicked                    (GtkWidget *objet_graphique, gpointer user_data);

void
on_button18_clicked                    (GtkWidget *objet_graphique, gpointer user_data);

void
on_button16_clicked                    (GtkWidget *objet_graphique, gpointer user_data);

void
on_radiobutton6_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton7_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton8_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton9_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton10_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button17_clicked                    (GtkWidget *objet_graphique, gpointer user_data);

void
on_button19_clicked                    (GtkWidget *objet_graphique, gpointer user_data);

void
on_bv_clicked                          (GtkButton       *button,
                                        gpointer         user_data);
//////////////////reclamation/////////////
void
on_button_ok_zaineb_clicked            (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_add_zaineb_clicked           (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_edit_zaineb_clicked          (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_delete_zaineb_clicked        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_display_zaineb_clicked       (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonZ_Logout_clicked              (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radiobutton_female_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_male_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_dashboard_clicked            (GtkWidget       *button,
                                        gpointer         user_data);

void
on_treeview1_zeineb_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_refresh_zaineb_clicked       (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_return_zaineb_clicked        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_recheche_clicked             (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_ajoutes_clicked              (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_effacer_clicked              (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_modif_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_affiche_clicked              (GtkWidget       *button,
                                        gpointer         user_data);



void
on_afficher_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_retour_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_calculer_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_reclamation_clicked                 (GtkButton       *button,
                                        gpointer         user_data);
