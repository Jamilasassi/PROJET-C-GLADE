#include<gtk/gtk.h>


typedef struct
{
    int jour;
    int mois;
    int annee;
}DATE;


typedef struct
{
    char cin[20];
    char nom[20];
    char prenom[20];	
    DATE date;
    char login[30];
    char motpasse[30];
    char genre[10];
    char role[50];
    float vote;
    char numerobureau[20];			

}utilisateur;

void ajouter_utilisateur(utilisateur u,char *utilisateur);
void afficher_utilisateur(GtkWidget *liste);
void modifier__utilisateur(utilisateur u1,char *utilisateur);
void supprimer_utilisateur(char cin []);
void chercher_utilisateur(char cin []);
void afficher_recherche(GtkWidget *liste);
int verifier(char login[]);
//////////////////obs////////////////
typedef struct 
{ 
    int  jour;
    int  mois;
    int  annee;		
}Date;
typedef struct
{ 
    char nom[20];
    char prenom[20];
    Date date;
    char cin[20];
    char id[20];
    char nat[20];
    char pro[20];

  
} observateur;

void ajouter_1(observateur o );
void modifier_1(observateur o);
void supprimer_1(observateur o, char [] );
observateur chercher_1(char ch[]);
void affi(GtkWidget *liste);
//int total(char  *observateur);
//void taux(char * ,float * ,float * );
/////////////////////////election//////////////////
typedef struct
{
    int jour;
    int mois;
    int annee;
}DATE2;


typedef struct
{
    char identifiant[20];
    DATE date;
    char gouvernorat[30];
    char municipalite[30];
    char nbhabit[50];
    int nbcons ;


}election;


void ajouter_election(election e);
void afficher_election(GtkWidget *liste);
void modifier_election(char identifiant[],election e1,char *election);
void supprimer_election(char id []);
int rechercher_election(char id[]);
void afficher_rechercher_election(GtkWidget *liste);
int TPE(char*file);
void TPHF(char*file,char*h,char*f);
int nbv(char * filename,int idListe);
float tvb(char * filename);

//////////////////liste///////////////
typedef struct 
{
char nom[30];
char idliste[30];
char type[30];
int nombre;
char cin[30];
char c1[30];
char c2[30];
}listelectorale;
typedef struct
{ 
int idliste;
int nb_vote;
}liste_vote;


void ajouterListe(listelectorale l , char *liste);
void modifierListe(char idliste[],listelectorale nouv,char *liste);
void afficher_liste_electorale(GtkWidget *liste);
void supprimerListe(char idliste[], char*liste);
int chercherListe(char idliste[], char*liste);
void afficher_liste_electoraleCHercher(GtkWidget *liste);
///////////////////////////bv//////////////
 typedef struct
{
char id[20];
int cpe;
int cpo;
char salle[10];
char ADRsalle[20];
char id_agent[20];
}Vote;

 int ajouter (Vote v,char filename[]);
 int modifier (char id[], Vote nouv,char*filename);
 int supprimer (char id[],char*filename);
 Vote chercher ( char id[] ,char*filename);
 void afficher_vote(GtkTreeView *liste);
///////////////reclamation////////////
typedef struct
{
  int day;
  int month;
  int year;
}dateofrec;
typedef struct{
   char lelec[20];
   char reclamation[50];
   char id[20];
   char type[20];
  dateofrec dor;
}reclam;
typedef struct{
	int id;
	char nom[20];
	char pre[20];
	int age;
	int num_bureau;
        int vote;
        int id_liste;
}user;







int add_rec(reclam r,char *file); //add a reclamation in reclamation.txt
int modify_sadok(reclam r,char *file); // modify a reclamation in reclamation.txt
int del_sadok(char id[],char *file); // delete a reclamation in reclamation.txt
void affichage(GtkWidget *list,char *file); //print all the reclamations
int recherche(char id[],char *file);
int nbv_par_bureau(char * filename, int num_bureau);


