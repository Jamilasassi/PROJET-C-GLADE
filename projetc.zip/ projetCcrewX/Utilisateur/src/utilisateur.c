#ifdef HAVE_CONFIG_H
#include <config.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include"utilisateur.h"
#include <gtk/gtk.h>

enum
{ 
	ECIN,
	ENOM,
	EPRENOM,
	EJOUR,
	EMOIS,
	EANNEE,
	ELOGIN,
	EMTP,
	EGENR,
	EROLE,
	EVOTE,
	EBV,
	COLUMNS,
};


////////////////////Ajouteerr electionn /////////////////
void ajouter_utilisateur(utilisateur u,char *utilisateur){
FILE * f;
f=fopen(utilisateur,"a");
fprintf(f,"%s %s %s %d %d %d %s %s %s %s %f %s  \n",u.cin,u.nom,u.prenom,u.date.jour,u.date.mois,u.date.annee,u.login,u.motpasse,u.genre,u.role,u.vote,u.numerobureau);
fclose(f);
}

/////////////////////////Afficher Election ////////////////
void afficher_utilisateur(GtkWidget *liste){

GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	char cin[30];
	char nom[30];
	char prenom[30];
	char jour[10];
	char mois[10];
	char annee[10];
	char login[30];
	char mtp[30];
	char genre[20];
	char role[30];
	char vote[30];
	char nbv[30];
	store=NULL;
	FILE *f;
	store=gtk_tree_view_get_model (liste);
	if (store==NULL)
	{
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("cin", renderer, "text",ECIN,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("Nom", renderer, "text",ENOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("Prenom", renderer, "text",EPRENOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("jour", renderer, "text",EJOUR,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("mois", renderer, "text",EMOIS,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("annee", renderer, "text",EANNEE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);


	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("login", renderer, "text",ELOGIN,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);


	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("mot de passe", renderer, "text",EMTP,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);


	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("Genre", renderer, "text",EGENR,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("Role", renderer, "text",EROLE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);



	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("Vote", renderer, "text",EVOTE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);



	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("N bureau", renderer, "text",EBV,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);


	}
	store=gtk_list_store_new (COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,  G_TYPE_STRING,   G_TYPE_STRING, G_TYPE_STRING,  G_TYPE_STRING,  G_TYPE_STRING,  G_TYPE_STRING,  G_TYPE_STRING,  G_TYPE_STRING,  G_TYPE_STRING);
	f=fopen("utilisateur.txt","r");
	if(f==NULL)
	{
		return;
	}
	else
	{
		f= fopen("utilisateur.txt","a+");
		while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s  \n",cin,nom,prenom,jour,mois,annee,login,mtp,genre,role,vote,nbv)!=EOF)
		{
			gtk_list_store_append(store, &iter);
			gtk_list_store_set(store,&iter, ECIN, cin ,ENOM ,nom , EPRENOM , prenom , EJOUR,jour, EMOIS, mois, EANNEE, annee, ELOGIN, login ,EMTP ,mtp,EGENR , genre,  EROLE, role,EVOTE,vote , EBV , nbv,-1);
		}
		fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
		g_object_unref (store);
	}
}
//////////////////////Modifier
void modifier_utilisateur(utilisateur u1,char *user){
utilisateur u;
FILE* f1=fopen(user, "r");
FILE* f2=fopen("userm.txt", "w");


if((f1!=NULL)&&(f2!=NULL))
{
while(fscanf(f1,"%s %s %s %d %d %d %s %s %s %s %f %s  \n",u.cin,u.nom,u.prenom,&u.date.jour,&u.date.mois,&u.date.annee,u.login,u.motpasse,u.genre,u.role,&u.vote,u.numerobureau)!=EOF)
	{
	if(strcmp(u.cin,u1.cin)==0)
		{
		fprintf(f2,"%s %s %s %d %d %d %s %s %s %s %f %s  \n",u1.cin,u1.nom,u1.prenom,u1.date.jour,u1.date.mois,u1.date.annee,u1.login,u1.motpasse,u1.genre,u1.role,u1.vote,u1.numerobureau);
		}
	else
		{
		fprintf(f2,"%s %s %s %d %d %d %s %s %s %s %f %s  \n",u.cin,u.nom,u.prenom,u.date.jour,u.date.mois,u.date.annee,u.login,u.motpasse,u.genre,u.role,u.vote,u.numerobureau);
		}
	}

}
fclose(f1);
fclose(f2);
remove(user);
rename("userm.txt",user);


}

/////////////////////Supprimer
void supprimer_utilisateur(char cin[]){
utilisateur u;
FILE *f1;
FILE *f2;

f1=fopen("utilisateur.txt","r");
f2=fopen("users.txt","w");
while(fscanf(f1,"%s %s %s %d %d %d %s %s %s %s %f %s  \n",u.cin,u.nom,u.prenom,&u.date.jour,&u.date.mois,&u.date.annee,u.login,u.motpasse,u.genre,u.role,&u.vote,u.numerobureau)!=EOF)
{if (strcmp(cin,u.cin)!=0)
fprintf(f2,"%s %s %s %d %d %d %s %s %s %s %f %s  \n",u.cin,u.nom,u.prenom,u.date.jour,u.date.mois,u.date.annee,u.login,u.motpasse,u.genre,u.role,u.vote,u.numerobureau);
}
fclose(f1);
fclose(f2);
remove("utilisateur.txt");
rename("users.txt","utilisateur.txt");

}
///////////////////////////////////chercher
void chercher_utilisateur(char cin []){
utilisateur u;
FILE *f1;
FILE *f2;

f1=fopen("utilisateur.txt","r");
f2=fopen("userc.txt","w");
while(fscanf(f1,"%s %s %s %d %d %d %s %s %s %s %f %s  \n",u.cin,u.nom,u.prenom,&u.date.jour,&u.date.mois,&u.date.annee,u.login,u.motpasse,u.genre,u.role,&u.vote,u.numerobureau)!=EOF)
{if (strcmp(cin,u.cin)==0)
fprintf(f2,"%s %s %s %d %d %d %s %s %s %s %f %s  \n",u.cin,u.nom,u.prenom,u.date.jour,u.date.mois,u.date.annee,u.login,u.motpasse,u.genre,u.role,u.vote,u.numerobureau);
}
fclose(f1);
fclose(f2);
}
/////////////////////affiche rechercher
void afficher_recherche(GtkWidget *liste){
GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	char cin[30];
	char nom[30];
	char prenom[30];
	char jour[10];
	char mois[10];
	char annee[10];
	char login[30];
	char mtp[30];
	char genre[20];
	char role[30];
	char vote[30];
	char nbv[30];
	store=NULL;
	FILE *f;
	store=gtk_tree_view_get_model (liste);
	if (store==NULL)
	{
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("cin", renderer, "text",ECIN,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("Nom", renderer, "text",ENOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("Prenom", renderer, "text",EPRENOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("jour", renderer, "text",EJOUR,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);


	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("mois", renderer, "text",EMOIS,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("annee", renderer, "text",EANNEE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);


	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("login", renderer, "text",ELOGIN,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);


	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("mot de passe", renderer, "text",EMTP,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);


	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("Genre", renderer, "text",EGENR,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("Role", renderer, "text",EROLE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);



	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("Vote", renderer, "text",EVOTE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);



	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("N bureau", renderer, "text",EBV,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);


	}
	store=gtk_list_store_new (COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,  G_TYPE_STRING,   G_TYPE_STRING, G_TYPE_STRING,  G_TYPE_STRING,  G_TYPE_STRING,  G_TYPE_STRING,  G_TYPE_STRING,  G_TYPE_STRING,  G_TYPE_STRING);
	f=fopen("userc.txt","r");
	if(f==NULL)
	{
		return;
	}
	else
	{
		f= fopen("userc.txt","a+");
		while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s \n",cin,nom,prenom,jour,mois,annee,login,mtp,genre,role,vote,nbv)!=EOF)
		{
			gtk_list_store_append(store, &iter);
			gtk_list_store_set(store,&iter, ECIN, cin ,ENOM ,nom , EPRENOM , prenom , EJOUR,jour, EMOIS, mois, EANNEE, annee, ELOGIN, login ,EMTP ,mtp,EGENR , genre,  EROLE, role,EVOTE,vote , EBV , nbv,-1);
		}
		fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
		g_object_unref (store);
	}

}
////////////////////////////
int verifier(char login[]){
utilisateur u;
FILE *f1;
FILE *f2;
int v=0;
f1=fopen("utilisateur.txt","r");
while(fscanf(f1,"%s %s %s %d %d %d %s %s %s %s %f %s  \n",u.cin,u.nom,u.prenom,&u.date.jour,&u.date.mois,&u.date.annee,u.login,u.motpasse,u.genre,u.role,&u.vote,u.numerobureau)!=EOF)
{if (strcmp(login,u.login)!=0)
{v=0;}
else{v=1;}
}
return (v);
}
////////////////////////////////////
void TrierUser(char * filename)
{

	utilisateur u,newU,tmp,T[100];
	int n=0,i,j,min;
    	FILE * f=fopen(filename, "r");
	FILE * f3=fopen("newTrier.txt","w");
        if(f!=NULL && f3!=NULL)
        {
        while(fscanf(f,"%s %s %s %d %d %d %s %s %s %s %f %s  \n",u.cin,u.nom,u.prenom,&u.date.jour,&u.date.mois,&u.date.annee,u.login,u.motpasse,u.genre,u.role,&u.vote,u.numerobureau)!=EOF)
        	{
            		if(u.role==1)
            		{
				newU=u;
				T[n]=newU;	
				n++;
			}
	    	}
    
		for (i=0;i<n-1;i++)
		{
		min=i ;
		for (j=i+1;j<n;j++) 
		{
			if (T[j].nom[0]<T[min].nom[0])
				min=j;
		
		}	
		tmp=T[i];
		T[i]=T[min];
		T[min]=tmp;
		}
		for (i=0;i<n;i++){
	 
	fprintf(f3,"%s %s %s %d %d %d %s %s %s %s %f %s  \n",T[i].cin,T[i].nom,T[i].prenom,T[i].date.jour,T[i].date.mois,T[i].date.annee,T[i].login,T[i].motpasse,T[i].genre,T[i].role,T[i].vote,T[i].numerobureau);
	     
	}

  	
    }
    fclose(f);
    fclose(f3);
    
}
//////////////////////////////////////
///////////////////////////
void TPHF(char*file,char*hom,char*fem)
{utilisateur u;
int nbE=0;
int nbH=0;
int nbF=0;
int Th=0;
int Tf=0;
remove("homme.txt");
remove("femme.txt");
FILE *f=fopen(file ,"r");
FILE *f1=fopen(hom ,"a");
FILE *f2=fopen(fem ,"a");
if (f!=NULL)
{ while (fscanf (f,"%s %s %s %d %d %d %s %s %s %s %f %s  \n",u.cin,u.nom,u.prenom,&u.date.jour,&u.date.mois,&u.date.annee,u.login,u.motpasse,u.genre,u.role,&u.vote,u.numerobureau) !=EOF){
			
		if(strcmp(u.genre,"homme")==0)
			{nbH++;}
		if (strcmp(u.genre,"femme")==0)
			{nbF++;}
		}
nbE=nbE+1;
			
}
Th=nbH/nbE;
Tf=nbF/nbE;
fprintf(f1,"%d\n",Th);
fprintf(f2,"%d\n",Tf);




fclose (f);
fclose (f1);
fclose (f2);
}
///////////////////////////////////////
int nombre_dehomme(char*file)
{
int nbH;
FILE *f=fopen(file ,"r");
fscanf (f,"%d\n",&nbH);

return nbH;
}
////////////////////////////////////////
int nombre_defemme(char*file)
{
int nbF;
FILE *f=fopen(file ,"r");
fscanf (f,"%d\n",&nbF);
return nbF;
}
////////////////////////
////////////////////////obs/////////////////
enum
{
	ENOM1,
	EPRENOM1,
	EJOUR1,
	EMOIS1,
	EANNEE1,
        ECIN1,
	EID1,
	ENAT,
	EPRO,
	COLUMNS1,
};

void ajouter_1(observateur o )
{
     FILE *f;
  f=fopen("obs.txt","a+");
    if(f!=NULL)
    {
fprintf(f,"%s %s %d %d %d %s %s %s %s\n", o.nom, o.prenom,o.date.jour,o.date.mois,o.date.annee,o.cin,o.id,o.nat,o.pro);

     fclose(f);
              }
}
void modifier_1(observateur o)
{

FILE *f=NULL,*x;
f=fopen("obs.txt","r");
x=fopen("mod.txt","a+");
observateur n;
if (f!=NULL)
{
while (fscanf(f,"%s %s %d %d %d %s %s %s %s\n", n.nom, n.prenom,&o.date.jour,&o.date.mois,&o.date.annee,n.cin,n.id,n.nat,n.pro)!= EOF)
{
if (strcmp(o.id,n.id)==0)
{
fprintf(x,"%s %s %d %d %d %s %s %s %s\n", o.nom, o.prenom,o.date.jour,o.date.mois,o.date.annee,o.cin,o.id,o.nat,o.pro) ;
}
else
{
fprintf(x,"%s %s %d %d %d %s %s %s %s\n", o.nom, o.prenom,o.date.jour,o.date.mois,o.date.annee,o.cin,o.id,o.nat,o.pro);
}
}
}
fclose(x);
fclose(f);
remove("obs.txt");
rename("mod.txt","obs.txt");

}
void supprimer_1(observateur n, char ch[] )
{

FILE *f=NULL;
FILE *x=NULL ;
f=fopen("obs.txt","r");
x=fopen("mod.txt","a");
if (f!=NULL)
{
while (fscanf(f,"%s %s %d %d %d %s %s %s %s\n", n.nom, n.prenom,&n.date.jour,&n.date.mois,&n.date.annee,n.cin,n.id,n.nat,n.pro)!= EOF)
{
if (strcmp(ch,n.id)!=0)
{
fprintf(x,"%s %s %d %d %d %s %s %s %s\n", n.nom, n.prenom,n.date.jour,n.date.mois,n.date.annee,n.cin,n.id,n.nat,n.pro) ;
}
}
}
fclose(x);
fclose(f);

remove("obs.txt");
rename("mod.txt","obs.txt");
}
observateur chercher_1(char ch[])
{
 
int trouve=0;
observateur n;
 //char ch1[200];
FILE *f=NULL;
f=fopen("obs.txt","r");
if (f!=NULL)
{
while (fscanf(f,"%s %s %d %d %d %s %s %s %s\n", n.nom, n.prenom,&n.date.jour,&n.date.mois,&n.date.annee,n.cin,n.id,n.nat,n.pro)!= EOF)
{if (strcmp(n.id,ch)==0)
{

fclose(f);
return (n);}
    
}
}
}
void affi(GtkWidget *liste)
{
    
    GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;
    GtkTreeIter iter;
    GtkListStore *store;
    char nom[20];
    char prenom[20];
    char jour[20];
    char mois[20];
    char annee[20];
    char cin[20];
    char id[20];
    char nat[20];
    char pro[20];
    store= NULL;
FILE *f;
store=gtk_tree_view_get_model(liste);
if(store==NULL)
{
renderer =gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes(" nom",renderer,"text",ENOM1,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer =gtk_cell_renderer_text_new();
column =gtk_tree_view_column_new_with_attributes(" prenom",renderer,"text",EPRENOM1,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer =gtk_cell_renderer_text_new();
column =gtk_tree_view_column_new_with_attributes(" jour",renderer,"text",EJOUR1,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer =gtk_cell_renderer_text_new();
column =gtk_tree_view_column_new_with_attributes(" mois",renderer,"text",EMOIS1,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer =gtk_cell_renderer_text_new();
column =gtk_tree_view_column_new_with_attributes(" annee",renderer,"text",EANNEE1,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);


renderer =gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes(" cin",renderer,"text",ECIN1,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer =gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes(" id",renderer,"text",EID1,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer =gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes(" nat",renderer,"text",ENAT,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

renderer =gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes(" pro",renderer,"text",EPRO,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);




store=gtk_list_store_new(COLUMNS1, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

  f=fopen("obs.txt","r");
   if (f==NULL)
   {
return;
}
else
{
f=fopen("obs.txt","a+");
while (fscanf(f,"%s %s %s %s %s %s %s %s %s\n", nom, prenom,jour,mois,annee,cin,id,nat,pro)!= EOF)
    {
	gtk_list_store_append(store,&iter);
	gtk_list_store_set (store,&iter,ENOM1,nom,EPRENOM1,prenom,EJOUR1,jour,EMOIS1,mois,EANNEE1,annee,ECIN1,cin,EID1,id,ENAT,nat,EPRO,pro,-1);

    
   }
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste) ,GTK_TREE_MODEL (store));
g_object_unref (store);
}
}
}
/////////////////////////////////////election////////////////////////////////
enum
{ 
	EID2,
	EJOUR2,
	EMOIS2,
	EANNEE2,
	EGOUV,
	EMUNIC,
	ENBHAB,
	ENBCON,
	COLUMNS2,
};


////////////////////Ajouteerr electionn /////////////////
void ajouter_election(election e )
{
FILE *f;
f=fopen("Election.txt","a");
 
fprintf(f,"%s %d %d %d %s %s %s %d  \n",e.identifiant,e.date.jour,e.date.mois,e.date.annee,e.gouvernorat,e.municipalite,e.nbhabit,e.nbcons);
fclose(f);
}
/////////////////////////Afficher Election ////////////////
void afficher_election(GtkWidget *liste){

GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	char identifiant[30];
	char jour[10];
	char mois[10];
	char annee[10];
	char gouvernorat[30];
	char municipalite[30];
	char nbhabit[30];
	char nbcons[10];
	store=NULL;
	FILE *f;
	store=gtk_tree_view_get_model (liste);
	if (store==NULL)
	{
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("identifiant", renderer, "text",EID2,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("jour", renderer, "text",EJOUR2,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("mois", renderer, "text",EMOIS2,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("annee", renderer, "text",EANNEE2,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);


	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("gouvernorat", renderer, "text",EGOUV,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("municipalite", renderer, "text",EMUNIC,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("nbhabit", renderer, "text",ENBHAB,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("nbcons", renderer, "text",ENBCON,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	}
	store=gtk_list_store_new (COLUMNS2, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,  G_TYPE_STRING,   G_TYPE_STRING, G_TYPE_STRING,  G_TYPE_STRING,  G_TYPE_STRING);
	f=fopen("Election.txt","r");
	if(f==NULL)
	{
		return;
	}
	else
	{
		f= fopen("Election.txt","a+");
		while(fscanf(f,"%s %s %s %s %s %s %s %s  \n",identifiant,jour,mois,annee,gouvernorat,municipalite,nbhabit,nbcons)!=EOF)
		{
			gtk_list_store_append(store, &iter);
			gtk_list_store_set(store,&iter, EID2, identifiant, EJOUR2,jour, EMOIS2, mois, EANNEE2, annee, EGOUV, gouvernorat ,EMUNIC ,municipalite,  ENBHAB, nbhabit,ENBCON,nbcons,-1);
		}
		fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
		g_object_unref (store);
	}
}

//////////////////////////////Fonction Modifier///////////////////////
void modifier_election(char identifiant[],election e1,char *elect){
election e;
FILE* f1=fopen(elect, "r");
FILE* f2=fopen("elecModif.txt", "w");


if((f1!=NULL)&&(f2!=NULL))
{
while(fscanf(f1,"%s %d %d %d %s %s %s %d  \n",e.identifiant,&e.date.jour,&e.date.mois,&e.date.annee,e.gouvernorat,e.municipalite,e.nbhabit,&e.nbcons)!=EOF)
	{
	if(strcmp(e.identifiant,e1.identifiant)==0)
		{
		fprintf(f2,"%s %d %d %d %s %s %s %d  \n",e1.identifiant,e1.date.jour,e1.date.mois,e1.date.annee,e1.gouvernorat,e1.municipalite,e1.nbhabit,e1.nbcons);
		}
	else
		{
		fprintf(f2,"%s %d %d %d %s %s %s %d  \n",e.identifiant,e.date.jour,e.date.mois,e.date.annee,e.gouvernorat,e.municipalite,e.nbhabit,e.nbcons);
		}
	}

}
fclose(f1);
fclose(f2);
remove("Election.txt");
rename("elecModif.txt",elect);

}
///////////////////////////////Fonction Supprimer ////////////////////////
void supprimer_election(char id []){
election e;
FILE *f1;
FILE *f2;

f1=fopen("Election.txt","r");
f2=fopen("elecSup.txt","w");
while(fscanf(f1,"%s %d %d %d %s %s %s %d  \n",e.identifiant,&e.date.jour,&e.date.mois,&e.date.annee,e.gouvernorat,e.municipalite,e.nbhabit,&e.nbcons)!=EOF)
{if (strcmp(id,e.identifiant)!=0)
fprintf(f2,"%s %d %d %d %s %s %s %d  \n",e.identifiant,e.date.jour,e.date.mois,e.date.annee,e.gouvernorat,e.municipalite,e.nbhabit,e.nbcons);
}
fclose(f1);
fclose(f2);
remove("Election.txt");
rename("elecSup.txt","Election.txt");
}

//////////////////////////Fonction Remplir TAbleau /////////////////////
int remplirtabRech (election tab[],int nb)
{
    char id[20];
    int jour,mois,annee;
    char gouv[20],munic[20];
    char nbhab[30];
    int nbcon;    
    FILE* fichier ;
    int i;

    fichier = fopen("Election.txt", "a+");

        while (fscanf(fichier,"%s %d %d %d %s %s %s %d  \n",id,&jour,&mois,&annee,gouv,munic,nbhab,&nbcon)!=EOF)
        {
            
            strcpy(tab[i].identifiant,id);
	    tab[i].date.jour=jour;
            tab[i].date.mois=mois;
	    tab[i].date.annee=annee;
	    strcpy(tab[i].gouvernorat,gouv);
	    strcpy(tab[i].municipalite,munic);
	    strcpy(tab[i].nbhabit,nbhab);
	    tab[i].nbcons=nbcon;
            nb++;
	    i++;    
        }
        

        fclose(fichier);
	return(nb);
}
///////////////////////////////////////Fonctio Rechercher ////////////
int rechercher_election(char id[]){
election tab[100];
int nb;
int ce,i;
FILE*f;
ce=0;
nb=remplirtabRech (tab,nb);
for (i=0;i<nb;i++)
	{if ((strcmp(id,tab[i].identifiant)==0) ||(strcmp(id,tab[i].gouvernorat)==0) || (strcmp(id,tab[i].municipalite)==0))
		{
		ce=1;
		f=fopen("recheElection.txt", "w+");
		if("f!=NULL")			
	{fprintf(f,"%s %d %d %d %s %s %s %d  \n",tab[i].identifiant,tab[i].date.jour,tab[i].date.mois,tab[i].date.annee,tab[i].gouvernorat,tab[i].municipalite,tab[i].nbhabit,tab[i].nbcons);}
		fclose(f);		
		}
	
	}

return(ce);


}
//////////////////////////////////Afficher Recherchee/////////////////
void afficher_rechercher_election(GtkWidget *liste){
GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	char identifiant[30];
	char jour[10];
	char mois[10];
	char annee[10];
	char gouvernorat[30];
	char municipalite[30];
	char nbhabit[30];
	char nbcons[10];
	store=NULL;
	FILE *f;
	store=gtk_tree_view_get_model (liste);
	if (store==NULL)
	{
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("identifiant", renderer, "text",EID2,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("jour", renderer, "text",EJOUR2,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("mois", renderer, "text",EMOIS2,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("annee", renderer, "text",EANNEE2,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);


	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("gouvernorat", renderer, "text",EGOUV,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("municipalite", renderer, "text",EMUNIC,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("nbhabit", renderer, "text",ENBHAB,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("nbcons", renderer, "text",ENBCON,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	}
	store=gtk_list_store_new (COLUMNS2, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,  G_TYPE_STRING,   G_TYPE_STRING, G_TYPE_STRING,  G_TYPE_STRING,  G_TYPE_STRING);
	f=fopen("recheElection.txt","r");
	if(f==NULL)
	{
		return;
	}
	else
	{
		f= fopen("recheElection.txt","a+");
		while(fscanf(f,"%s %s %s %s %s %s %s %s  \n",identifiant,jour,mois,annee,gouvernorat,municipalite,nbhabit,nbcons)!=EOF)
		{
			gtk_list_store_append(store, &iter);
			gtk_list_store_set(store,&iter, EID2, identifiant, EJOUR2,jour, EMOIS2, mois, EANNEE2, annee, EGOUV, gouvernorat ,EMUNIC ,municipalite,  ENBHAB, nbhabit,ENBCON,nbcons,-1);
		}
		fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
		g_object_unref (store);
	}
}


///////////////////////////////////////
float tvb(char * filename)
{
    utilisateur u;
    int nbvb=0,nbvt=0;
    float taux;
    FILE * f=fopen(filename, "r");
    if(f!=NULL)
    {
        while(fscanf(f,"%s %s %s %s %d %d %d %s %s %s %d %s \n",u.cin,u.nom,u.prenom,u.genre,&u.date.jour,&u.date.mois,&u.date.annee,u.login,u.motpasse,u.role,&u.vote,u.numerobureau)!=EOF)
        {
            if(u.vote!=-1)
                nbvt=nbvt+1;

        }
        fclose(f);
        f=fopen(filename, "r");
        while(fscanf(f,"%s %s %s %s %d %d %d %s %s %s %d %s \n",u.cin,u.nom,u.prenom,u.genre,&u.date.jour,&u.date.mois,&u.date.annee,u.login,u.motpasse,u.role,&u.vote,u.numerobureau)!=EOF)
        {
            if(u.vote==0)
                nbvb=nbvb+1;

        }
        float a=nbvb;
        taux=a/nbvt;
        fclose(f);


    }
    return taux;


}
////////////////////////////////////////////
int nbv(char * filename,int idListe)
{
   utilisateur u;
   int nbv=0;
   FILE * f=fopen(filename, "r");
    if(f!=NULL)
    {
        while(fscanf(f,"%s %s %s %s %d %d %d %s %s %s %d %s \n",u.cin,u.nom,u.prenom,u.genre,&u.date.jour,&u.date.mois,&u.date.annee,u.login,u.motpasse,u.role,&u.vote,u.numerobureau)!=EOF)
        {
            if((u.vote>0)&&(u.vote==idListe))
                nbv=nbv+1;

        }

       fclose(f);


    }
    return nbv;


}
//////////////////////liste///////////////
enum 
{
 ENOM3,
 EID3,
 ETYPE3,
 ENB,
 ECIN3,
 EC1,
 EC2,
 COLUMNS3 
};
/**********AJOUTERRRR************/
void ajouterListe(listelectorale l , char *liste)
{
  FILE * f=fopen(liste, "a");
 
    
   fprintf(f,"%s %s %s %d %s %s %s \n",l.nom,l.idliste,l.type,l.nombre,l.cin,l.c1,l.c2);
   fclose(f); 
}
/******MODIFIER***************/
void modifierListe(char idliste[],listelectorale nouv,char *liste)
{
listelectorale l;
  FILE* f=fopen(liste, "r");
  FILE* f2=fopen("Listemod.txt", "w");
  
  if((f!=NULL) ||( f2!=NULL))
 {
while(fscanf(f,"%s %s %s %d %s %s %s \n",l.nom,l.idliste,l.type,&l.nombre,l.cin,l.c1,l.c2)!=EOF)
{
if(strcmp(l.idliste,nouv.idliste)==0)
  fprintf(f2,"%s %s %s %d %s %s %s \n",nouv.nom,nouv.idliste,nouv.type,nouv.nombre,nouv.cin,nouv.c1,nouv.c2);
else
 fprintf(f2,"%s %s %s %d %s %s %s \n",l.nom,l.idliste,l.type,l.nombre,l.cin,l.c1,l.c2);
}
   fclose(f);
   fclose(f2);
remove(liste);
rename("Listemod.txt",liste);
 }
}
/******************Afficheer****************************/
void afficher_liste_electorale(GtkWidget *liste){
GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	char nom[30];
	char idliste[10];
	char type[10];
	char nombre[10];
	char cin[30];
	char cin1[30];
	char cin2[30];
	store=NULL;
	FILE *f;
	store=gtk_tree_view_get_model (liste);
	if (store==NULL)
	{
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("nom", renderer, "text",ENOM3,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("idliste", renderer, "text",EID3,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("type", renderer, "text",ETYPE3,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("nombre", renderer, "text",ENB,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);


	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("cin", renderer, "text",ECIN3,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("cin1", renderer, "text",EC1,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("cin2", renderer, "text",EC2,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	}
	store=gtk_list_store_new (COLUMNS3, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,  G_TYPE_STRING,   G_TYPE_STRING, G_TYPE_STRING,  G_TYPE_STRING);
	f=fopen("liste.txt","r");
	if(f==NULL)
	{
		return;
	}
	else
	{
		f= fopen("liste.txt","a+");
		while(fscanf(f,"%s %s %s %s %s %s %s   \n",nom,idliste,type,nombre,cin,cin1,cin2)!=EOF)
		{
			gtk_list_store_append(store, &iter);
			gtk_list_store_set(store,&iter, ENOM3, nom, EID3,idliste, ETYPE3, type, ENB, nombre, ECIN3, cin ,EC1 ,cin1,  EC2, cin2,-1);
		}
		fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
		g_object_unref (store);
	}
}

/**********Supprimer**********/
void supprimerListe(char idliste[], char*liste)
{
listelectorale l;
  FILE* f=fopen(liste, "r");
  FILE* f2=fopen("ListeSupp.txt", "w");
  
while(fscanf(f,"%s %s %s %d %s %s %s \n",l.nom,l.idliste,l.type,&l.nombre,l.cin,l.c1,l.c2)!=EOF)
{
if(strcmp(l.idliste,idliste)!=0)
  fprintf(f2,"%s %s %s %d %s %s %s \n",l.nom,l.idliste,l.type,l.nombre,l.cin,l.c1,l.c2);
}
   fclose(f);
   fclose(f2);
remove(liste);
rename("ListeSupp.txt",liste);
 }
/*********CHERCHER****/
int chercherListe(char idliste[], char*liste)
{
listelectorale l;
  FILE* f=fopen(liste, "r");
  FILE* f2=fopen("ListeCHercher.txt", "w");
  int trv=0;
while(fscanf(f,"%s %s %s %d %s %s %s \n",l.nom,l.idliste,l.type,&l.nombre,l.cin,l.c1,l.c2)!=EOF)
{
if(strcmp(l.idliste,idliste)==0)
  fprintf(f2,"%s %s %s %d %s %s %s \n",l.nom,l.idliste,l.type,l.nombre,l.cin,l.c1,l.c2);
	trv=1;
}
   fclose(f);
   fclose(f2);
	return trv;

 }
/******************Afficheer Chercher****************************/
void afficher_liste_electoraleCHercher(GtkWidget *liste){
GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	char nom[30];
	char idliste[10];
	char type[10];
	char nombre[10];
	char cin[30];
	char cin1[30];
	char cin2[30];
	store=NULL;
	FILE *f;
	store=gtk_tree_view_get_model (liste);
	if (store==NULL)
	{
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("nom", renderer, "text",ENOM3,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("idliste", renderer, "text",EID3,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("type", renderer, "text",ETYPE3,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("nombre", renderer, "text",ENB,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);


	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("cin", renderer, "text",ECIN3,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("cin1", renderer, "text",EC1,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("cin2", renderer, "text",EC2,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	}
	store=gtk_list_store_new (COLUMNS3, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,  G_TYPE_STRING,   G_TYPE_STRING, G_TYPE_STRING,  G_TYPE_STRING);
	f=fopen("ListeCHercher.txt","r");
	if(f==NULL)
	{
		return;
	}
	else
	{
		f= fopen("ListeCHercher.txt","a+");
		while(fscanf(f,"%s %s %s %s %s %s %s   \n",nom,idliste,type,nombre,cin,cin1,cin2)!=EOF)
		{
			gtk_list_store_append(store, &iter);
			gtk_list_store_set(store,&iter, ENOM3, nom, EID3,idliste, ETYPE3, type, ENB, nombre, ECIN3, cin ,EC1 ,cin1,  EC2, cin2,-1);
		}
		fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
		g_object_unref (store);
	}
}

/*liste_electorale chercher(char * liste,int id_liste)
{
    liste_electorale l ;
    int tr;
    FILE * f=fopen(liste, "r");
tr=0;
    if(f!=NULL)
    {
        while(tr==0&& fscanf(f,"%s %d %d %d %d %d %d \n",l.nom_liste, &l.id_liste, &l.type_liste, &l.nb_candidat, &l.cin, &l.c1, &l.c2)!=EOF)
        {
            if(l.id_liste == id_liste)
                tr=1;
        }
    }
    fclose(f);
    if(tr==0)
        l.id_liste=-1;
    return l; 
}*/
/***********ecrireeeee************/
/*void ecrire()
{
FILE* f=fopen("vote.txt", "w");
int i=1;
for(i=1;i<4;i++)
fprintf(f,"%d %d\n",i,0);
fclose(f);
}*/
/*******nombre vote *******/
/*int nbv (char * vote, int idliste)
{
    liste_vote v;
    FILE * f=fopen(vote, "r");
    FILE * f2=fopen("liste.txt", "w");
    if(f==NULL || f2==NULL)
return 0;
else
{
while(fscanf(f,"\n %d %d\n",&v.idliste,&v.nb_vote)!=EOF)
{
if (v.idliste!=idliste)
fprintf (f2,"\n %d %d\n",v.idliste, v.nb_vote);
else
{
v.nb_vote++;
fprintf (f2,"\n %d %d\n",v.idliste, v.nb_vote);
}
}
fclose(f);
fclose(f2);
remove(vote);
rename("liste.txt",vote);
return 1 ; 
}
}*/
/********************triiiii*****************/
/*int L_ordre ( char *vote)
{
int mx=0;
liste_vote aux;
liste_vote t[200];
liste_vote v;
int x=0,y=0;
int i,j;
FILE * f=fopen(vote, "r");
FILE * f2=fopen("liste.txt", "w");
if(f==NULL || f2==NULL)
return 0;
else
{
while(fscanf(f,"\n %d %d\n",&v.id_liste,&v.nb_vote)!=EOF)
{
t[y]=v;
y++;
}
for(i=0;i<y-1;i++)
{
mx=i;
for(j=i+1;j<y;j++)
{
if (t[j].nb_vote>t[mx].nb_vote)
mx=j;
}
aux=t[i];
t[i]=t[mx];
t[mx]=aux;
}
while (x<y)
{
fprintf(f2,"\n %d %d\n", t[x].id_liste,t[x].nb_vote);
x++;
}
}
fclose(f);
fclose(f2);
remove(vote);
rename("liste.txt",vote);
return 1 ;}*/
/************************afficher**********************/
/*
void afficher_liste_electorale(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
listelectorale le ;

store=NULL;
FILE *f;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",ENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("idliste",renderer,"text",EID,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("type",renderer,"text",EORIENTATION,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("nombre",renderer,"text",ENB,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("cin",renderer,"text",ECIN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("c1",renderer,"text",EC1,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("c2",renderer,"text",EC2,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
f=fopen("liste.txt","r");
if(f==NULL)
{
return;
}
else {
f=fopen("liste.txt","a+");
while (fscanf(f,"%s %s %s %d %s %s %s \n", l.nom, l.idliste, l.type, &l.nombre, l.cin, l.c1, l.c2)!= EOF)
{
gtk_list_store_append (store, &iter);
gtk_list_store_set (store, &iter, ENOM, l.nom, EID, l.idliste, ETYPE, l.typ, ENB, l.nombre, ECIN, l.cin, EC1,l.c1, EC2, l.c2, -1);
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
g_object_unref(store);
}
/////////////
void resultat( int choix[], char texte[])
{
if (choix[0]==1)
strcat(texte,"J'accepte les conditions de confidentialité en tant que tête de liste");
}
void afficher_vote()
{

}*/
////////////////////////////////BV////////////////////////////////////
 enum
{
	EID5,
	ECPE,
	ECPO,
	ESALLE,
	EID_AGENT,
	EADRSALLE,
	COLUMNS5
};
 int ajouter(Vote v , char filename[])
{
 FILE* f=fopen(filename,"a+");
 if(f!=NULL)
 {
  fprintf(f,"%s %d %d %s %s %s\n",v.id,v.cpe,v.cpo,v.salle,v.id_agent,v.ADRsalle);
 fclose(f);
 return 1;
 }
 else return 0;
}
 
int modifier(char id[], Vote nouv, char * filename)
{
Vote v;
    FILE * f=fopen(filename, "r");
    FILE * f2 =fopen("aux.txt", "w");
    if(f==NULL || f2==NULL)
return 0;
else
    {
while(fscanf(f,"%s %d %d %s %s %s\n",v.id,&v.cpe,&v.cpo,v.salle,v.id_agent,v.ADRsalle)!=EOF)
{
if(strcmp(v.id,id)==0)
        
	fprintf(f2,"%s %d %d %s %s %s\n",nouv.id,nouv.cpe,nouv.cpo,nouv.salle,nouv.id_agent,nouv.ADRsalle);
else

  	fprintf(f2,"%s %d %d %s %s %s\n",v.id,v.cpe,v.cpo,v.salle,v.id_agent,v.ADRsalle);

}
        fclose(f);
        fclose(f2);
remove(filename);
rename("aux.txt", filename);
        return 1;
    }


  
}
int supprimer(char id[], char * filename)
{
Vote v;
int t=0;
    FILE * f=fopen(filename, "r");
    FILE * f2 =fopen("aux.txt", "a+");
    if(f==NULL || f2==NULL)
return 0;
else
    {
while(fscanf(f,"%s %d %d %s %s %s\n",v.id,&v.cpe,&v.cpo,v.salle,v.id_agent,v.ADRsalle)!=EOF)
{
if(strcmp(v.id,id)==0)
	t=1;
else
fprintf(f2,"%s %d %d %s %s %s\n",v.id,v.cpe,v.cpo,v.salle,v.id_agent,v.ADRsalle);
}
        fclose(f);
        fclose(f2);
remove(filename);
rename("aux.txt", filename);
if(t==1)
        return 1;
else
	return 0;
    }
}

Vote chercher(char id[], char * filename)
{
Vote v;
 int tr=0;
    FILE * f=fopen(filename, "r");
 if(f!=NULL )
    {
while(fscanf(f,"%s %d %d %s %s %s\n",v.id,&v.cpe,&v.cpo,v.salle,v.id_agent,v.ADRsalle)!=EOF && tr==0)
{if(strcmp(v.id,id)==0)
tr=1;
return v;
}
}
if(tr==0)
strcpy(v.id,"-1");
return v;

}
void afficher_vote(GtkTreeView *liste)
{
GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;
    GtkTreeIter iter ;
    GtkListStore *store;
Vote v;
    store=NULL;
    FILE *f;
    store=GTK_LIST_STORE(gtk_tree_view_get_model(liste));
    if(store==NULL){
        
        renderer=gtk_cell_renderer_text_new();
        column=gtk_tree_view_column_new_with_attributes("id",renderer,"text",EID5,NULL);
        gtk_tree_view_append_column(liste,column);

        renderer=gtk_cell_renderer_text_new();
        column=gtk_tree_view_column_new_with_attributes("cpe",renderer,"text",ECPE,NULL);
        gtk_tree_view_append_column(liste,column);

        renderer=gtk_cell_renderer_text_new();
        column=gtk_tree_view_column_new_with_attributes("cpo",renderer,"text",ECPO,NULL);
        gtk_tree_view_append_column(liste,column); 

        renderer=gtk_cell_renderer_text_new();
        column=gtk_tree_view_column_new_with_attributes("salle",renderer,"text",ESALLE,NULL);
        gtk_tree_view_append_column(liste,column);
 
        renderer=gtk_cell_renderer_text_new();
        column=gtk_tree_view_column_new_with_attributes("ADRsalle",renderer,"text",EADRSALLE,NULL);
        gtk_tree_view_append_column(liste,column);

        renderer=gtk_cell_renderer_text_new();
        column=gtk_tree_view_column_new_with_attributes("id_agent",renderer,"text",EID_AGENT,NULL);
        gtk_tree_view_append_column(liste,column);

         
    }
          
    store=gtk_list_store_new(COLUMNS5,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
    f=fopen("vote.txt","r");
    if(f==NULL){return;}
    else
    {
                 f=fopen("vote.txt","a+");
         while(fscanf(f,"%s %d %d %s %s %s\n",v.id,&v.cpe,&v.cpo,v.salle,v.id_agent,v.ADRsalle)!=EOF)
         {
            gtk_list_store_append(store,&iter);
            gtk_list_store_set(store,&iter,0,v.id,1,v.cpe,2,v.cpo,3,v.salle,4,v.ADRsalle,5,v.id_agent,-1);
         }
     fclose(f);
     gtk_tree_view_set_model(liste,GTK_TREE_MODEL(store));
     g_object_unref(store);
    }

}
/////////////////:reclamation/////////////
enum{
	Reclamation,
	Type_De_Reclamation,
	Liste_Electoral,
	Id,
	Date_De_Reclamation,
	COLUMNS8
};




///////ADD///////
int add_rec(reclam r, char *file)
{
 int success=0;
FILE* f;
f=fopen(file,"a+");
if(f!=NULL)
{
fprintf(f,"%s %s %s %s %d/%d/%d\n",r.lelec,r.id,r.reclamation,r.type,r.dor.day,r.dor.month,r.dor.year);
fclose(f);
success=1;
}
return success;

}	
//////modify//////
int modify_sadok(reclam r,char *file)
{
char lelec[20],reclamation1[20],type1[20],id[20];
int d,m,y,success=0;

FILE* f=fopen(file,"r+");
FILE* g=fopen("tmp.txt","w");
if(f!=NULL)
{
	while(fscanf(f,"%s %s %s %s %d/%d/%d\n",lelec,id,reclamation1,type1,&d,&m,&y)!=EOF)
	{
		
		if(strcmp(id,r.id)==0)
		{
			fprintf(g,"%s %s %s %s %d/%d/%d\n",r.lelec,r.id,r.reclamation,r.type,r.dor.day,r.dor.month,r.dor.year);
			success=1;
		}
		else
		{
			fprintf(g,"%s %s %s %s %d/%d/%d\n",lelec,id,reclamation1,type1,d,m,y);
		}

	}
}
fclose(f);
fclose(g);
remove(file);
rename("tmp.txt",file);
return success;
}
///////delete//////
int del_sadok(char id[],char *file)
{
char lelec[20],reclamation1[20],type1[20],id1[20];
int d,m,y,success=0;
FILE* f=fopen(file,"r+");
FILE* g=fopen("tmp.txt","w");
if(f!=NULL || g!=NULL)
{
	while(fscanf(f,"%s %s %s %s %d/%d/%d\n",lelec,id1,reclamation1,type1,&d,&m,&y)!=EOF)
	{
		if(strcmp(id,id1)!=0)
		{
			fprintf(g,"%s %s %s %s %d/%d/%d\n",lelec,id1,reclamation1,type1,d,m,y);
			success=1;
		}

	}
fclose(f);
fclose(g);
remove(file);
rename("tmp.txt",file);

}
return success;
}
////////////affichage//////////
void affichage(GtkWidget *list,char *file)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store=NULL;
reclam r;
int i;
char date[15];
FILE *f;
store=gtk_tree_view_get_model(list);
if(store==NULL)
{
	renderer= gtk_cell_renderer_text_new();
	column= gtk_tree_view_column_new_with_attributes("Reclamation",renderer,"text",Reclamation,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (list),column);

	renderer= gtk_cell_renderer_text_new();
	column= gtk_tree_view_column_new_with_attributes("Type De Reclamation",renderer,"text",Type_De_Reclamation,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (list),column);

	renderer= gtk_cell_renderer_text_new();
	column= gtk_tree_view_column_new_with_attributes("Liste Electoral",renderer,"text",Liste_Electoral,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (list),column);

	renderer= gtk_cell_renderer_text_new();
	column= gtk_tree_view_column_new_with_attributes("Id",renderer,"text",Id,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (list),column);

	renderer= gtk_cell_renderer_text_new();
	column= gtk_tree_view_column_new_with_attributes("Date De Reclamation",renderer,"text",Date_De_Reclamation,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (list),column);
}


store=gtk_list_store_new(COLUMNS8, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

f=fopen(file,"r+");

if(f!=NULL)
{ 
	while(fscanf(f,"%s %s %s %s %d/%d/%d\n",r.lelec,r.id,r.reclamation,r.type,&r.dor.day,&r.dor.month,&r.dor.year)!=EOF)
	{	i=snprintf(date,15,"%d/%d/%d",r.dor.day,r.dor.month,r.dor.year);
		gtk_list_store_append(store,&iter);
						gtk_list_store_set(store,&iter,Reclamation,r.reclamation,Type_De_Reclamation,r.type,Liste_Electoral,r.lelec,Id,r.id,Date_De_Reclamation,date,-1);

	}
	fclose(f);

	gtk_tree_view_set_model (GTK_TREE_VIEW(list), GTK_TREE_MODEL(store));
	g_object_unref(store);

   
}
}




///////////////recherche///////////////////
int recherche(char id[],char *file)
{
char lelec[20],reclamation1[20],type1[20],id1[20];
int d,m,y,success=0;
FILE* f=fopen(file,"r+");
FILE* g=fopen("recherche.txt","w");
if(f!=NULL || g!=NULL)
{
	while(fscanf(f,"%s %s %s %s %d/%d/%d\n",lelec,id1,reclamation1,type1,&d,&m,&y)!=EOF)
	{
		if(strcmp(id,id1)==0)
		{
			fprintf(g,"%s %s %s %s %d/%d/%d\n",lelec,id1,reclamation1,type1,d,m,y);
			success=1;
		}

	}
fclose(f);
fclose(g);


}
return success;
}

/////////////////////calcul//////////////////////
int nbv_par_bureau(char * filename, int num_bureau){
int n=0;
user u;
FILE* f=fopen(filename,"r");
if(f!=NULL){
while(fscanf(f,"%d %s %s %d %d %d %d /n",&u.id,u.nom,u.pre,&u.age,&u.num_bureau,&u.vote,&u.id_liste)!=EOF){
if(num_bureau==u.num_bureau && u.vote!=-1){
n++;}

}
}
return n;



}

