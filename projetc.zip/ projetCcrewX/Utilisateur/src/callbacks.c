#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "utilisateur.h"

int x,y,z;
int n,m,l;

void
on_radiobutton1_homme_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{z=1;}
}


void
on_radiobutton1_femme_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{z=2;}
}
void
on_radiobutton1_nn_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{x=2;}
}

void
on_checkbutton1_confAjt_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{y=1;}
}


void
on_button1_AjouterEl_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
utilisateur u;
GtkWidget *windowajout,*cin,*nom,*preno,*jour,*mois,*annee,*log,*motp,*genr,*rol,*vot,*nbbv,*output,*output1;
windowajout=create_window_ajouterElecteur();
cin = lookup_widget(button,"entry1_cinE");
nom= lookup_widget(button,"entry1_nomE");
preno= lookup_widget(button,"entry1_preE");
jour = lookup_widget(button,"spinbutton1_jourE");
mois = lookup_widget(button,"spinbutton1_moisE");
annee = lookup_widget(button,"spinbutton1_anneeE");
log= lookup_widget(button,"entry1_LoginE");
motp= lookup_widget(button,"entry1_MtE");
rol=lookup_widget(button,"comboboxentry1_roleE");
vot=lookup_widget(button,"spinbutton1_vote");
nbbv=lookup_widget(button,"entry1_nbvE");
strcpy(u.cin,gtk_entry_get_text(GTK_ENTRY(cin)));
strcpy(u.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(u.prenom,gtk_entry_get_text(GTK_ENTRY(preno)));
u.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (jour));
u.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (mois));
u.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (annee));
strcpy(u.login,gtk_entry_get_text(GTK_ENTRY(log)));
strcpy(u.motpasse,gtk_entry_get_text(GTK_ENTRY(motp)));
strcpy(u.role,gtk_combo_box_get_active_text(GTK_COMBO_BOX(rol)));
u.vote=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (vot));
strcpy(u.numerobureau,gtk_entry_get_text(GTK_ENTRY(nbbv)));

if(x==2)
{u.vote=-1;
}
if(z==1)
{strcpy(u.genre,"homme");}
else if(z==2)
{strcpy(u.genre,"femme");}
if ((strcmp(u.cin,"")==0) || (strcmp(u.nom,"")==0)) {
output=lookup_widget(button,"label1_msgerr");
gtk_label_set_text(GTK_LABEL(output), "Données manquantes. \n Veuillez remplir tout les champs!");
output1=lookup_widget(button,"label1_msgSucc");
gtk_label_set_text(GTK_LABEL(output1), "");
}
if (y==1)
{
ajouter_utilisateur(u,"utilisateur.txt");
output=lookup_widget(button,"label1_msgerr");
gtk_label_set_text(GTK_LABEL(output), "");
output1=lookup_widget(button,"label1_msgSucc");
gtk_label_set_text(GTK_LABEL(output1), "Ajouter avec Succes");
}
x=0;
y=0;
}


void
on_button1_retEl_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window_ajouterElecteur, *window_afficherElection;
window_ajouterElecteur=lookup_widget(button,"window_ajouterElecteur");
gtk_widget_destroy(window_ajouterElecteur);
window_afficherElection=create_window_afficherElection();
gtk_widget_show (window_afficherElection);
}
void
on_radiobutton2_homme_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{n=1;}
}


void
on_radiobutton2_femme_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{n=2;}
}
void
on_radiobutton2_1_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{m=1;}
}


void
on_checkbutton2_confirmer_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (button)))
{l=1;}
}


void
on_button2_retourmod_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window_modifierElecteur, *window_afficherElection;
window_modifierElecteur=lookup_widget(button,"window_modifierElecteur");
gtk_widget_destroy(window_modifierElecteur);
window_afficherElection=create_window_afficherElection();
gtk_widget_show (window_afficherElection);
}


void
on_button1_modifier_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
utilisateur u1;
GtkWidget *windowajout,*cin,*nom,*preno,*jour,*mois,*annee,*log,*motp,*genr,*rol,*vot,*nbbv,*output,*output1;
windowajout=create_window_ajouterElecteur();
cin = lookup_widget(button,"entry2_cin");
nom= lookup_widget(button,"entry2_nom");
preno= lookup_widget(button,"entry2_prenom");
jour = lookup_widget(button,"spinbutton2_jour");
mois = lookup_widget(button,"spinbutton2_mois");
annee = lookup_widget(button,"spinbutton2_annee");
log= lookup_widget(button,"entry2_login");
motp= lookup_widget(button,"entry2_mtp");
rol=lookup_widget(button,"comboboxentry2_role");
vot=lookup_widget(button,"spinbutton2_vote");
nbbv=lookup_widget(button,"entry2_nbureau");
strcpy(u1.cin,gtk_entry_get_text(GTK_ENTRY(cin)));
strcpy(u1.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(u1.prenom,gtk_entry_get_text(GTK_ENTRY(preno)));
u1.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (jour));
u1.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (mois));
u1.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (annee));
strcpy(u1.login,gtk_entry_get_text(GTK_ENTRY(log)));
strcpy(u1.motpasse,gtk_entry_get_text(GTK_ENTRY(motp)));
strcpy(u1.role,gtk_combo_box_get_active_text(GTK_COMBO_BOX(rol)));
u1.vote=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (vot));
strcpy(u1.numerobureau,gtk_entry_get_text(GTK_ENTRY(nbbv)));

if(m==1)
{u1.vote=-1;
}
if(n==1)
{strcpy(u1.genre,"homme");}
else if(n==2)
{strcpy(u1.genre,"femme");}
if (l==1)
{
modifier_utilisateur(u1,"utilisateur.txt");
}
n=0;
m=0;
l=0;

}


void
on_treeview1_afficher_row_activated    (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar* cin;
gchar* nom;
gchar* prenom;
gchar* jour;
gchar* mois;
gchar* annee;
gchar* log;
gchar* mtp;
gchar* genre;
gchar* role;
gchar* vote;
gchar* nbv;

GtkTreeModel *model= gtk_tree_view_get_model(treeview);
GtkWidget* window_modifierElecteur,*window_afficherElection,*tre,*ci,*no,*pr,*jj,*mm,*aa,*lg,*mp,*ge,*rol,*vot,*nb;

if (gtk_tree_model_get_iter(model, &iter,path))
{


gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&cin,1,&nom,2,&prenom,3,&jour,4,&mois,5,&annee,6,&log,7,&mtp,8,&genre,9,&role,10,&vote,11,&nbv,-1);

window_modifierElecteur=create_window_modifierElecteur();
window_afficherElection=create_window_afficherElection();
gtk_widget_hide(window_afficherElection);
gtk_widget_show(window_modifierElecteur);

ci=lookup_widget(window_modifierElecteur,"entry2_cin");
gtk_entry_set_text(GTK_ENTRY(ci),cin);

no=lookup_widget(window_modifierElecteur,"entry2_nom");
gtk_entry_set_text(GTK_ENTRY(no),nom);

pr=lookup_widget(window_modifierElecteur,"entry2_prenom");
gtk_entry_set_text(GTK_ENTRY(pr),prenom);


jj=lookup_widget(window_modifierElecteur,"spinbutton2_jour");
gtk_entry_set_text(GTK_ENTRY(jj),jour);

mm=lookup_widget(window_modifierElecteur,"spinbutton2_mois");
gtk_entry_set_text(GTK_ENTRY(mm),mois);

aa=lookup_widget(window_modifierElecteur,"spinbutton2_annee");
gtk_entry_set_text(GTK_ENTRY(aa),annee);

lg=lookup_widget(window_modifierElecteur,"entry2_login");
gtk_entry_set_text(GTK_ENTRY(lg),log);

mp=lookup_widget(window_modifierElecteur,"entry2_mtp");
gtk_entry_set_text(GTK_ENTRY(mp),mtp);

nb=lookup_widget(window_modifierElecteur,"entry2_nbureau");
gtk_entry_set_text(GTK_ENTRY(nb),nbv);


}
}


void
on_button3_ajouter_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window_ajouterElecteur, *window_afficherElection;
window_afficherElection=lookup_widget(button,"window_afficherElection");
gtk_widget_destroy(window_afficherElection);
window_ajouterElecteur=create_window_ajouterElecteur();
gtk_widget_show (window_ajouterElecteur);


}
void
on_button3_modifier_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window_modifierElecteur, *window_afficherElection;
window_afficherElection=lookup_widget(button,"window_afficherElection");
gtk_widget_destroy(window_afficherElection);
window_modifierElecteur=create_window_modifierElecteur();
gtk_widget_show (window_modifierElecteur);
}


void
on_button3_chercher_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window_chercher, *window_afficherElection;
window_afficherElection=lookup_widget(button,"window_afficherElection");
gtk_widget_destroy(window_afficherElection);
window_chercher=create_window_chercher();
gtk_widget_show (window_chercher);

}


void
on_button3_supprimer_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
char cin[20];
GtkWidget *window_afficherElection,*tree, *ci,*output;
ci = lookup_widget(button,"entry3_supprim");
strcpy(cin,gtk_entry_get_text(GTK_ENTRY(ci)));
supprimer_utilisateur(cin);
window_afficherElection=lookup_widget(button,"window_afficherElection");
tree=lookup_widget(window_afficherElection,"treeview1_afficher");
afficher_utilisateur(tree);
output=lookup_widget(button,"label2_SuppEl");
gtk_label_set_text(GTK_LABEL(output), "Supprimer avec Succes");
}


void
on_button3_afficher_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *tree,*windowuser;
windowuser=lookup_widget(button,"window_afficherElection");
gtk_widget_destroy(windowuser);
windowuser=create_window_afficherElection();
tree=lookup_widget(windowuser,"treeview1_afficher");

afficher_utilisateur(tree);

gtk_widget_hide(windowuser);
gtk_widget_show(windowuser);
}


void
on_treeview2_affcherch_row_activated   (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}




void
on_button4_chercher_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
char cin[20];
GtkWidget *ci,*tree,*window_chercher;
window_chercher=lookup_widget(button,"window_chercher");
ci = lookup_widget(button,"entry4_chercher");
strcpy(cin,gtk_entry_get_text(GTK_ENTRY(ci)));
chercher_utilisateur(cin);
	

tree=lookup_widget(window_chercher,"treeview2_affcherch");
afficher_recherche(tree);

}
void
on_button4_retourChercher_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window_chercher, *window_afficherElection;
window_chercher=lookup_widget(button,"window_chercher");
gtk_widget_destroy(window_chercher);
window_afficherElection=create_window_afficherElection();
gtk_widget_show (window_afficherElection);
}







void
on_button1_Inscription_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window_login, *window_ajouterElecteur;
window_login=lookup_widget(button,"window_chercher");
gtk_widget_destroy(window_login);
window_ajouterElecteur=create_window_ajouterElecteur();
gtk_widget_show (window_ajouterElecteur);
}


void
on_button1_connexion_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajouter01;
GtkWidget *fenetre_afficher01;
GtkWidget *treeview1;



 
 fenetre_ajouter01=lookup_widget (button,"window_login");
 gtk_widget_destroy(fenetre_ajouter01);
 fenetre_afficher01=lookup_widget (button, "window1");
 fenetre_afficher01=create_window1();

 gtk_widget_show(fenetre_afficher01); 

 treeview1=lookup_widget(fenetre_afficher01,"treeview1");
 affi(treeview1);
}

void
on_button1_deconnexion_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *window_login, *window_afficherElection;
window_afficherElection=lookup_widget(button,"window_afficherElection");
gtk_widget_destroy(window_afficherElection);
window_login=create_window_login();
gtk_widget_show (window_login);
}


void
on_button1_stat_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowutuser, *windowstat;
windowutuser=lookup_widget(button,"window_afficherElection");
gtk_widget_destroy(windowutuser);
windowstat=create_window_stat();
gtk_widget_show (windowstat);
}


void
on_button2_afficherTPHF_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *output,*output1,*output2;
int nbhomm;
int nbf;
char Nbh[20],Nbf[20];

TPHF("utilisateur.txt","homme.txt","femme.txt");
output1 = lookup_widget(button, "label58_homme") ;
nbhomm=nombre_dehomme("homme.txt");
sprintf(Nbh,"%d",nbhomm);
gtk_label_set_text(GTK_LABEL(output1),Nbh);
output2 = lookup_widget(button, "label59_femme") ;
nbf=nombre_defemme("femme.txt");
sprintf(Nbf,"%d",nbf);
gtk_label_set_text(GTK_LABEL(output2),Nbf);
}


void
on_button3_trie_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *tree,*windowuser;
windowuser=lookup_widget(button,"window_stat");
gtk_widget_destroy(windowuser);
windowuser=create_window_stat();
tree=lookup_widget(windowuser,"treeview1_trii");
TrierUser("utilisateur.txt");
afficher_utilisateur(tree);

gtk_widget_hide(windowuser);
gtk_widget_show(windowuser);
}


void
on_treeview1_trii_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_button4_retStat_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowutuser, *windowstat;
windowutuser=lookup_widget(button,"window_stat");
gtk_widget_destroy(windowutuser);
windowstat=create_window_afficherElection();
gtk_widget_show (windowstat);

}

/////////////////////obs////////////////
int choix;
int choix1;

void
on_confirmerao_clicked                 (GtkButton       *objet,
                                        gpointer         user_data)
{

observateur o;
GtkWidget *ao1,*ao2,*jj,*mm,*aa,*ao4,*ao5, *ao6;
GtkWidget *ajouto;
GtkWidget *spinbuttonau;
ajouto=lookup_widget(objet,"ajouto");
ao1=lookup_widget(objet,"ao1");
ao2=lookup_widget(objet,"ao2");
jj=lookup_widget(objet,"spinbutton1_jour");
mm=lookup_widget(objet,"spinbutton1_mois");
aa=lookup_widget(objet,"spinbutton1_annee");
ao4=lookup_widget(objet,"ao4");
ao5=lookup_widget(objet,"ao5");
ao6=lookup_widget(objet,"combobox1_proffesion");


strcpy(o.nom,gtk_entry_get_text(GTK_ENTRY(ao1)));
strcpy(o.prenom,gtk_entry_get_text(GTK_ENTRY(ao2)));
o.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (jj));
o.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (mm));
o.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (aa));
strcpy(o.cin,gtk_entry_get_text(GTK_ENTRY(ao4)));
strcpy(o.id,gtk_entry_get_text(GTK_ENTRY(ao5)));
strcpy(o.pro,gtk_combo_box_get_active_text(GTK_COMBO_BOX(ao6)));


if(choix==0)

strcpy(o.nat,"tunisien");
else 
if(choix==1)
strcpy(o.nat,"etranger");
ajouter_1(o);
}


void
on_retourao_clicked                    (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *lobservateur, *ajouto;
ajouto=lookup_widget(objet,"ajouto");  
gtk_widget_destroy(ajouto);
lobservateur=create_lobservateur();
gtk_widget_show(lobservateur);
}


void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
choix=1;
}

/*
void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
choix=0;
}*/

/*
void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
choix1=0;
}*/


void
on_radiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
choix1=1;
}


void
on_confirmermo_clicked                 (GtkButton       *objet,
                                        gpointer         user_data)
{
observateur o;
GtkWidget *mo1,*mo2,*jj,*mm,*aa,*mo4,*mo5, *mo6;
GtkWidget *modifiero;
modifiero=lookup_widget(objet,"modifiero");
mo1=lookup_widget(objet,"mo1");
mo2=lookup_widget(objet,"mo2");
jj=lookup_widget(objet,"spinbutton2_jour");
mm=lookup_widget(objet,"spinbutton2_mois");
aa=lookup_widget(objet,"spinbutton2_annee");
mo4=lookup_widget(objet,"mo4");
mo5=lookup_widget(objet,"mo5");
mo6=lookup_widget(objet,"combobox2_proffesion");


strcpy(o.nom,gtk_entry_get_text(GTK_ENTRY(mo1)));
strcpy(o.prenom,gtk_entry_get_text(GTK_ENTRY(mo2)));
o.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (jj));
o.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (mm));
o.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (aa));
strcpy(o.cin,gtk_entry_get_text(GTK_ENTRY(mo4)));
strcpy(o.id,gtk_entry_get_text(GTK_ENTRY(mo5)));
strcpy(o.pro,gtk_combo_box_get_active_text(GTK_COMBO_BOX(mo6)));

if(choix1==0)

strcpy(o.nat,"tunisien");
else 
if(choix1==1)
strcpy(o.nat,"étranger");
modifier_1(o);
}


void
on_retourmo_clicked                    (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *lobservateur, *modifiero;
modifiero=lookup_widget(objet,"modifiero");  
gtk_widget_destroy(modifiero);
lobservateur=create_lobservateur();
gtk_widget_show(lobservateur);
}


void
on_supo_clicked                        (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *suppo,*suo;
observateur o;
char ch1[20];
suo=lookup_widget(objet,"suo");
strcpy(ch1,gtk_entry_get_text(GTK_ENTRY(suo)));
supprimer_1(o,ch1);
}


void
on_retoursupp_clicked                  (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *lobservateur, *suppo;
suppo=lookup_widget(objet,"suppo");  
gtk_widget_destroy(suppo);
lobservateur=create_lobservateur();
gtk_widget_show(lobservateur);
}


void
on_retourchercher_clicked              (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *lobservateur, *chercheo;
chercheo=lookup_widget(objet,"chercheo");  
gtk_widget_destroy(chercheo);
lobservateur=create_lobservateur();
gtk_widget_show(lobservateur);
}


void
on_chero_clicked                       (GtkButton       *objet,
                                        gpointer         user_data)
{
char ch1[30];
observateur u;
  GtkWidget *label20;
  GtkWidget *label21;
  GtkWidget *label22;
  GtkWidget *label23;
  GtkWidget *label24;
  GtkWidget *label25;
  GtkWidget *label26;

label20=lookup_widget(objet,"label20");
label21=lookup_widget(objet,"label21");
label22=lookup_widget(objet,"label22");
label23=lookup_widget(objet,"label23");
label24=lookup_widget(objet,"label24");
label25=lookup_widget(objet,"label25");
label26=lookup_widget(objet,"label26");


GtkWidget *cher;
cher=lookup_widget(objet,"cher");
strcpy(ch1,gtk_entry_get_text(GTK_ENTRY(cher)));
u=chercher_1(ch1);
if (strcmp(u.cin,"")==0){
gtk_label_set_text(GTK_LABEL(label21),"Introuvable");
gtk_label_set_text(GTK_LABEL(label20),"");
gtk_label_set_text(GTK_LABEL(label22),"");
gtk_label_set_text(GTK_LABEL(label23),"");
gtk_label_set_text(GTK_LABEL(label24),"");
gtk_label_set_text(GTK_LABEL(label25),"");
gtk_label_set_text(GTK_LABEL(label26),"");

}
else{
gtk_label_set_text(GTK_LABEL(label20),u.nom);
gtk_label_set_text(GTK_LABEL(label21),u.prenom);
gtk_label_set_text(GTK_LABEL(label23),u.cin);
gtk_label_set_text(GTK_LABEL(label24),u.id);
gtk_label_set_text(GTK_LABEL(label25),u.nat);
gtk_label_set_text(GTK_LABEL(label26),u.pro);}
}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
    gchar* nom;
    gchar* prenom;
    gchar* dateo;
    gchar* cin;
    gchar* id;
    gchar* nat;
    gchar* pro;
     
   observateur u;

GtkTreeModel *model= gtk_tree_view_get_model(treeview);
GtkWidget* windowMod,*windowobs,*tre,*no,*pre,*dat,*ci,*idd,*na,*pr;


if (gtk_tree_model_get_iter(model,&iter,path))
{
gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&nom,1,&prenom,2,&dateo,3,&cin,4,&id,5,&nat,6,&pro,-1);
windowMod=create_modifiero();
windowobs=create_lobservateur();
gtk_widget_hide(windowobs);
gtk_widget_show(windowMod);


no=lookup_widget(windowMod,"mo1");
gtk_entry_set_text(GTK_ENTRY(no),nom);

pre=lookup_widget(windowMod,"mo2");
gtk_entry_set_text(GTK_ENTRY(pre),prenom);

dat=lookup_widget(windowMod,"mo3");
gtk_entry_set_text(GTK_ENTRY(dat),dateo);

ci=lookup_widget(windowMod,"mo4");
gtk_entry_set_text(GTK_ENTRY(ci),cin);

idd=lookup_widget(windowMod,"mo5");
gtk_entry_set_text(GTK_ENTRY(idd),id);

pr=lookup_widget(windowMod,"mo6");
gtk_entry_set_text(GTK_ENTRY(pr),pro);




}
}


void
on_ajoutero_clicked                    (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *lobservateur, *ajouto;
lobservateur=lookup_widget(objet,"lobservateur");  
gtk_widget_destroy(lobservateur);
ajouto=create_ajouto();
gtk_widget_show(ajouto);
}


void
on_modifiero_clicked                   (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *lobservateur, *modifiero;
lobservateur=lookup_widget(objet,"lobservateur");  
gtk_widget_destroy(lobservateur);
modifiero=create_modifiero();
gtk_widget_show(modifiero);
}


void
on_supprimero_clicked                  (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *lobservateur, *suppo;
lobservateur=lookup_widget(objet,"lobservateur");  
gtk_widget_destroy(lobservateur);
suppo=create_suppo();
gtk_widget_show(suppo);
}


void
on_cherchero_clicked                   (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *lobservateur, *chercheo;
lobservateur=lookup_widget(objet,"lobservateur");  
gtk_widget_destroy(lobservateur);
chercheo=create_chercheo();
gtk_widget_show(chercheo);
}


void
on_affichero_clicked                   (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *lobservateur; 
GtkWidget *treeview1;
lobservateur=lookup_widget(objet,"lobservateur");
treeview1=lookup_widget(lobservateur,"treeview1");
affi(treeview1);
}

void
on_observateur_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajouter01;
GtkWidget *fenetre_afficher01;
GtkWidget *treeview1;



 
 fenetre_ajouter01=lookup_widget (button,"window1");
 gtk_widget_destroy(fenetre_ajouter01);
 fenetre_afficher01=lookup_widget (button, "lobservateur");
 fenetre_afficher01=create_lobservateur();

 gtk_widget_show(fenetre_afficher01); 

 treeview1=lookup_widget(fenetre_afficher01,"treeview1");
 affi(treeview1);
}

/////////////////////////election///////////////////////
int x,y;
char Tpe[20];
char Nbh[20];
char Nbf[20];

void
on_radiobutton1_nbr1_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{x=1;}
}

void
on_radiobutton1_nbr2_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{x=2;}
}

void
on_radiobutton1_nbr3_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{x=3;}
}

void
on_radiobutton1_nbr4_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{x=4;}
}

void
on_radiobutton1_nbr5_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{x=5;}
}


void
on_radiobutton1_nbr6_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{x=6;}
}

void
on_radiobutton1_nbr7_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{x=7;}
}

void
on_checkbutton1_confi_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{y=1;}
}

void
on_button1_ajouterElection_clicked     (GtkButton       *button,
                                        gpointer         user_data)
{
election e;
GtkWidget *windowajout, *windowelection,*id,*jour,*mois,*annee,*gou,*munic,*nbrh,*nbrc,*output,*output1;
windowajout=create_window_ajouter_election();
windowelection=create_window_election();
id = lookup_widget(button,"entry1_ideclection");
gou= lookup_widget(button,"entry1_gouvernorat");
jour = lookup_widget(button,"spinbutton1_jour");
mois = lookup_widget(button,"spinbutton1_mois");
annee = lookup_widget(button,"spinbutton1_annee");
munic=lookup_widget(button,"comboboxentry1_munic");
strcpy(e.identifiant,gtk_entry_get_text(GTK_ENTRY(id)));
strcpy(e.gouvernorat,gtk_entry_get_text(GTK_ENTRY(gou)));
e.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (jour));
e.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (mois));
e.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (annee));
strcpy(e.municipalite,gtk_combo_box_get_active_text(GTK_COMBO_BOX(munic)));
if(x==1 )
{strcpy(e.nbhabit,"5000");
e.nbcons=12;
} 
else if(x==2)
{strcpy(e.nbhabit,"5001->10000");
e.nbcons=16;
}
else if(x==3)
{strcpy(e.nbhabit,"10001->25000");
e.nbcons=22;
}
else if(x==4)
{strcpy(e.nbhabit,"25001->50000");
e.nbcons=30;
}
else if(x==5)
{strcpy(e.nbhabit,"50001->100000");
e.nbcons=36;
}
else if(x==7)
{strcpy(e.nbhabit,"100001->500000");
e.nbcons=40;
}
else if(x==6)
{strcpy(e.nbhabit,"Plus500000");
e.nbcons=60;
}
if ((strcmp(e.identifiant,"")==0) || (strcmp(gou,"")==0)) {
output=lookup_widget(button,"label2_donnemanq");
gtk_label_set_text(GTK_LABEL(output), "Données manquantes. \n Veuillez remplir tout les champs!");
output1=lookup_widget(button,"label1_ajouter");
gtk_label_set_text(GTK_LABEL(output1), "");
}
if (y==1)
{
ajouter_election(e);
output=lookup_widget(button,"label2_donnemanq");
gtk_label_set_text(GTK_LABEL(output), "");
output1=lookup_widget(button,"label1_ajouter");
gtk_label_set_text(GTK_LABEL(output1), "Ajouter avec Succes");
}
x=0;
y=0;


}


void
on_button1_retourajt_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowajouter, *windowElection;
windowajouter=lookup_widget(button,"window_ajouter_election");
gtk_widget_destroy(windowajouter);
windowElection=create_window_election ();
gtk_widget_show (windowElection);
}


void
on_treeview1_affElection_row_activated (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar* id;
gchar* jour;
gchar* mois;
gchar* annee;
gchar* gou;
gchar* muni;
gchar* nbh;
gchar* nbc;
election e;
GtkTreeModel *model= gtk_tree_view_get_model(treeview);
GtkWidget* windowajout,*windowelection,*tre,*idd,*jj,*mm,*aa,*go,*mu,*nh,*nc;

if (gtk_tree_model_get_iter(model, &iter,path))
{


gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&id,1,&jour,2,&mois,3,&annee,4,&gou,5,&muni,6,&nbh,7,&nbc,-1);

windowajout=create_window_ajouter_election();
windowelection=create_window_election();
gtk_widget_hide(windowelection);
gtk_widget_show(windowajout);

idd=lookup_widget(windowajout,"entry1_ideclection");
gtk_entry_set_text(GTK_ENTRY(idd),id);

jj=lookup_widget(windowajout,"spinbutton1_jour");
gtk_entry_set_text(GTK_ENTRY(jj),jour);

mm=lookup_widget(windowajout,"spinbutton1_mois");
gtk_entry_set_text(GTK_ENTRY(mm),mois);

aa=lookup_widget(windowajout,"spinbutton1_annee");
gtk_entry_set_text(GTK_ENTRY(aa),annee);

go=lookup_widget(windowajout,"entry1_gouvernorat");
gtk_entry_set_text(GTK_ENTRY(go),gou);



}
}


void
on_button2_windAjouter_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window_ajouter_election, *windowElection;
windowElection=lookup_widget(button,"window_election");
gtk_widget_destroy(windowElection);
window_ajouter_election=create_window_ajouter_election ();
gtk_widget_show (window_ajouter_election);

}


void
on_button2_windModif_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window_ajouter_election, *windowElection;
windowElection=lookup_widget(button,"window_election");
gtk_widget_destroy(windowElection);
window_ajouter_election=create_window_ajouter_election ();
gtk_widget_show (window_ajouter_election);
}


void
on_button2_rechElect_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window_rech, *windowElection;
windowElection=lookup_widget(button,"window_election");
gtk_widget_destroy(windowElection);
window_rech=create_window_recherelect ();
gtk_widget_show (window_rech);
}


void
on_button2_SuppElect_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
char identi[20];
GtkWidget *windowElection,*tree, *iden,*output;
iden = lookup_widget(button,"entry2_SuppELect");
strcpy(identi,gtk_entry_get_text(GTK_ENTRY(iden)));
supprimer_election(identi);
windowElection=lookup_widget(button,"window_election");
tree=lookup_widget(windowElection,"treeview1_affElection");
afficher_election(tree);
output=lookup_widget(button,"label2_SuppEl");
gtk_label_set_text(GTK_LABEL(output), "Supprimer avec Succes");
}


void
on_button2_affElect_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *tree,*windowElection;
windowElection=lookup_widget(button,"window_election");
gtk_widget_destroy(windowElection);
windowElection=create_window_election();
tree=lookup_widget(windowElection,"treeview1_affElection");

afficher_election(tree);

gtk_widget_hide(windowElection);
gtk_widget_show(windowElection);

}




void
on_radiobutton1_nbr1_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *output;
output=lookup_widget(button,"label1_nbrCons");
gtk_label_set_text(GTK_LABEL(output), "12");
}


void
on_radiobutton1_nbr2_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *output;
output=lookup_widget(button,"label1_nbrCons");
gtk_label_set_text(GTK_LABEL(output), "16");
}


void
on_radiobutton1_nbr3_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *output;
output=lookup_widget(button,"label1_nbrCons");
gtk_label_set_text(GTK_LABEL(output), "22");
}


void
on_radiobutton1_nbr4_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *output;
output=lookup_widget(button,"label1_nbrCons");
gtk_label_set_text(GTK_LABEL(output), "30");
}


void
on_radiobutton1_nbr5_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *output;
output=lookup_widget(button,"label1_nbrCons");
gtk_label_set_text(GTK_LABEL(output), "36");
}


void
on_radiobutton1_nbr7_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *output;
output=lookup_widget(button,"label1_nbrCons");
gtk_label_set_text(GTK_LABEL(output), "40");
}


void
on_radiobutton1_nbr6_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *output;
output=lookup_widget(button,"label1_nbrCons");
gtk_label_set_text(GTK_LABEL(output), "60");
}


void
on_treeview1_recElect_row_activated    (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_button3_reche_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
remove("RechElect.txt");
char ident[20];
GtkWidget *id,*tree,*windowrechercher,*output;
int k;
windowrechercher=lookup_widget(button,"window_recherelect");
id = lookup_widget(button,"entry3_rechelect");
strcpy(ident,gtk_entry_get_text(GTK_ENTRY(id)));
k=rechercher_election(ident);
if (k==0)
	{

	output=lookup_widget(button,"label3_rechint");
	gtk_label_set_text(GTK_LABEL(output), "Election INTROUVABLE");
	}
if (k==1)	
	{	

tree=lookup_widget(windowrechercher,"treeview1_recElect");
afficher_rechercher_election(tree);
}

}


void
on_button3_retrecher_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window_rech, *windowElection;
window_rech=lookup_widget(button,"window_recherelect");
gtk_widget_destroy(window_rech);
windowElection=create_window_election ();
gtk_widget_show (windowElection);
}





void
on_button1_ModifierElection_clicked    (GtkButton       *button,
                                        gpointer         user_data)
{
election e1;
GtkWidget *windowajout, *windowelection,*id1,*jour1,*mois1,*annee1,*gou1,*munic1,*nbrh1,*nbrc1,*output2,*output3;
windowajout=create_window_ajouter_election();
windowelection=create_window_election();
id1 = lookup_widget(button,"entry1_ideclection");
gou1= lookup_widget(button,"entry1_gouvernorat");
jour1 = lookup_widget(button,"spinbutton1_jour");
mois1 = lookup_widget(button,"spinbutton1_mois");
annee1 = lookup_widget(button,"spinbutton1_annee");
munic1=lookup_widget(button,"comboboxentry1_munic");
strcpy(e1.identifiant,gtk_entry_get_text(GTK_ENTRY(id1)));
strcpy(e1.gouvernorat,gtk_entry_get_text(GTK_ENTRY(gou1)));
e1.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (jour1));
e1.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (mois1));
e1.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (annee1));
strcpy(e1.municipalite,gtk_combo_box_get_active_text(GTK_COMBO_BOX(munic1)));
if(x==1 )
{strcpy(e1.nbhabit,"5000");
e1.nbcons=12;
} 
else if(x==2)
{strcpy(e1.nbhabit,"5001->10000");
e1.nbcons=16;
}
else if(x==3)
{strcpy(e1.nbhabit,"10001->25000");
e1.nbcons=22;
}
else if(x==4)
{strcpy(e1.nbhabit,"25001->50000");
e1.nbcons=30;
}
else if(x==5)
{strcpy(e1.nbhabit,"50001->100000");
e1.nbcons=36;
}
else if(x==7)
{strcpy(e1.nbhabit,"100001->500000");
e1.nbcons=40;
}
else if(x==6)
{strcpy(e1.nbhabit,"Plus500000");
e1.nbcons=60;
}
if ((strcmp(e1.identifiant,"")==0) || (strcmp(gou1,"")==0)) {
output2=lookup_widget(button,"label2_donnemanq");
gtk_label_set_text(GTK_LABEL(output2), "Données manquantes. \n Veuillez remplir tout les champs!");
output3=lookup_widget(button,"label1_modifier");
gtk_label_set_text(GTK_LABEL(output3), "");
}
if (y==1)
{
modifier_election(e1.identifiant,e1,"Election.txt");
output2=lookup_widget(button,"label2_donnemanq");
gtk_label_set_text(GTK_LABEL(output2), "");
output3=lookup_widget(button,"label1_modifier");
gtk_label_set_text(GTK_LABEL(output3), "Modifier avec Succes");
}
x=0;
y=0;


}







void
on_button2_tachcalcul_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window_calcul, *windowElection;
windowElection=lookup_widget(button,"window_election");
gtk_widget_destroy(windowElection);
window_calcul=create_window_calcul();
gtk_widget_show (window_calcul);
}


void
on_treeview4_TPHF_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_button4_retCAl_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window_calcul, *windowElection;
window_calcul=lookup_widget(button,"window_calcul");
gtk_widget_destroy(window_calcul);
windowElection=create_window_election ();
gtk_widget_show (windowElection);
}


void
on_button3_calculEl_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *output,*output1,*input;
float vb;
int nbv1,idliste;
output = lookup_widget(button, "label4_NVB") ;
vb=tvb("utilisateur.txt");
sprintf(Tpe,"%f",vb);
gtk_label_set_text(GTK_LABEL(output),Tpe);


input=lookup_widget(button, "nbvote");
idliste=atoi(gtk_entry_get_text(GTK_ENTRY(input)));
nbv1=nbv("utilisateur.txt",idliste);
output1 = lookup_widget(button, "label4_nbvote") ;
sprintf(Nbh,"%d",nbv1);
gtk_label_set_text(GTK_LABEL(output1),Nbh);

}


void
on_election_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajouter01;
GtkWidget *fenetre_afficher01;
GtkWidget *treeview1;



 
 fenetre_ajouter01=lookup_widget (button,"window1");
 gtk_widget_destroy(fenetre_ajouter01);
 fenetre_afficher01=lookup_widget (button, "window_election");
 fenetre_afficher01=create_window_election();

 gtk_widget_show(fenetre_afficher01); 

 treeview1=lookup_widget(fenetre_afficher01,"treeview1");
 affi(treeview1);
}
///////////////////////liste/////////////////
int x,y;
int z;
void
on_button1_retourAjout_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowajouter, *fentchoix;
windowajouter=lookup_widget(button,"window_ajout");
gtk_widget_destroy(windowajouter);
fentchoix=create_window_choix ();
gtk_widget_show (fentchoix);
}


void
on_button1_ajouter_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
listelectorale l;
GtkWidget *no,*id,*typ,*nb,*cin,*ci1,*ci2,*output;
no= lookup_widget(button,"entry1_nmlist");
id= lookup_widget(button,"entry1_idlist");
nb = lookup_widget(button,"spinbutton1_nbrCand");
cin = lookup_widget(button,"entry1_cinlist");
ci1=lookup_widget(button,"entry1_cincand1");
ci2= lookup_widget(button,"entry1_cincand2");
strcpy(l.nom,gtk_entry_get_text(GTK_ENTRY(no)));
strcpy(l.idliste,gtk_entry_get_text(GTK_ENTRY(id)));
l.nombre=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (nb));
strcpy(l.cin,gtk_entry_get_text(GTK_ENTRY(cin)));
strcpy(l.c1,gtk_entry_get_text(GTK_ENTRY(ci1)));
strcpy(l.c2,gtk_entry_get_text(GTK_ENTRY(ci2)));
if(x==1)
{strcpy(l.type,"Gauche");}
else if(x==2)
{strcpy(l.type,"Centre");}
else if(x==3)
{strcpy(l.type,"Droite");}
ajouterListe(l,"liste.txt");
output=lookup_widget(button,"label1_ajouter");
gtk_label_set_text(GTK_LABEL(output), "Ajouter avec Succes");
}

void
on_radiobutton1_gauch_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{x=1;}
}
void
on_radiobutton1_centre_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{x=2;}
}

void
on_radiobutton1_droite_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{x=3;}
}

void
on_treeview1_affListe_row_activated    (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar* nom;
gchar* idlist;
gchar* type;
gchar* nbrC;
gchar* cin;
gchar* cin1;
gchar* cin2;
listelectorale le;
GtkTreeModel *model= gtk_tree_view_get_model(treeview);
GtkWidget* gestionListe,*tre,*no,*id,*ty,*nb,*ci,*ci1,*ci2;

if (gtk_tree_model_get_iter(model, &iter,path))
{


gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&nom,1,&idlist,2,&type,3,&nbrC,4,&cin,5,&cin1,6,&cin2,-1);

gestionListe=create_window_gestionListe();
gtk_widget_hide(gestionListe);
gtk_widget_show(gestionListe);

no=lookup_widget(gestionListe,"entry2_nomList");
gtk_entry_set_text(GTK_ENTRY(no),nom);

id=lookup_widget(gestionListe,"entry2_idListe");
gtk_entry_set_text(GTK_ENTRY(id),idlist);

nb=lookup_widget(gestionListe,"spinbutton2_nbrCand");
gtk_entry_set_text(GTK_ENTRY(nb),nbrC);

ci=lookup_widget(gestionListe,"entry2_cin");
gtk_entry_set_text(GTK_ENTRY(ci),cin);

ci1=lookup_widget(gestionListe,"entry2_cin1");
gtk_entry_set_text(GTK_ENTRY(ci1),cin1);

ci2=lookup_widget(gestionListe,"entry2_cin2");
gtk_entry_set_text(GTK_ENTRY(ci2),cin2);

}
}

//////////// PAS ENCORE ///////////
void
on_button2_recherche_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
char id[20];
GtkWidget *idl,*tree,*windowrechercher,*gestionListe,*output;
int tv;
gestionListe=lookup_widget(button,"window_gestionListe");
idl = lookup_widget(button,"entry2_rechercher");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(idl)));
tv=chercherListe(id,"liste.txt");
if (tv==0)
	{

	output=lookup_widget(button,"label3_rechint");
	gtk_label_set_text(GTK_LABEL(output), "Election INTROUVABLE");
	}
if (tv==1)	
	{	

windowrechercher=create_window_chercher ();
gtk_widget_show (windowrechercher);

tree=lookup_widget(windowrechercher,"treeview1_chercher");
afficher_liste_electoraleCHercher(tree);
}

}


void
on_radiobutton2_gauche_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{y=1;}
}


void
on_radiobutton2_centre_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{y=2;}
}


void
on_radiobutton2_droite_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{y=3;}
}


void
on_checkbutton1_accept_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{z=1;}
}


void
on_button2_retourMenu_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *gestionListe, *fentchoix;
gestionListe=lookup_widget(button,"window_gestionListe");
gtk_widget_destroy(gestionListe);
fentchoix=create_window_choix ();
gtk_widget_show (fentchoix);
}


void
on_button2_supprimer_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
char idlist[20];
GtkWidget *gestionListe,*tree, *id,*output;
id= lookup_widget(button,"entry2_idrech");
strcpy(idlist,gtk_entry_get_text(GTK_ENTRY(id)));
supprimerListe(idlist,"liste.txt");
gestionListe=lookup_widget(button,"window_gestionListe");
tree=lookup_widget(gestionListe,"treeview1_affListe");
afficher_liste_electorale(tree);
/*output=lookup_widget(button,"label2_SuppEl");
gtk_label_set_text(GTK_LABEL(output), "Supprimer avec Succes");*/
}


void
on_button2_affiche_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *tree,*gestionListe;
gestionListe=lookup_widget(button,"window_choix");
tree=lookup_widget(gestionListe,"treeview1_affListe");

afficher_liste_electorale(tree);

gtk_widget_hide(gestionListe);
gtk_widget_show(gestionListe);
}


void
on_button2_modifier_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
listelectorale l1;
GtkWidget *no1,*id1,*typ1,*nb1,*cin1,*ci11,*ci21,*output1;
no1= lookup_widget(button,"entry2_nomList");
id1= lookup_widget(button,"entry2_idListe");
nb1 = lookup_widget(button,"spinbutton2_nbrCand");
cin1 = lookup_widget(button,"entry2_cin");
ci11=lookup_widget(button,"entry2_cin1");
ci21= lookup_widget(button,"entry2_cin2");
strcpy(l1.nom,gtk_entry_get_text(GTK_ENTRY(no1)));
strcpy(l1.idliste,gtk_entry_get_text(GTK_ENTRY(id1)));
l1.nombre=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (nb1));
strcpy(l1.cin,gtk_entry_get_text(GTK_ENTRY(cin1)));
strcpy(l1.c1,gtk_entry_get_text(GTK_ENTRY(ci11)));
strcpy(l1.c2,gtk_entry_get_text(GTK_ENTRY(ci21)));
if(y==1)
{strcpy(l1.type,"Gauche");}
else if(y==2)
{strcpy(l1.type,"Centre");}
else if(y==3)
{strcpy(l1.type,"Droite");}
modifierListe(l1.idliste,l1,"liste.txt");
output1=lookup_widget(button,"label1_ajouter");
gtk_label_set_text(GTK_LABEL(output1), "Ajouter avec Succes");
}



void
on_button1_gerliste_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *gestionListe, *fentchoix;
fentchoix=lookup_widget(button,"window_choix");
gtk_widget_destroy(fentchoix);
gestionListe=create_window_gestionListe ();
gtk_widget_show (gestionListe);
}


void
on_button1_fentajout_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowajouter, *fentchoix;
fentchoix=lookup_widget(button,"window_choix");
gtk_widget_destroy(fentchoix);
windowajouter=create_window_ajout ();
gtk_widget_show (windowajouter);
}

void
on_button3_affvote_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowvote, *fentchoix;
fentchoix=lookup_widget(button,"window_choix");
gtk_widget_destroy(fentchoix);
windowvote=create_window_vote ();
gtk_widget_show (windowvote);
}


void
on_button3_affStat_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowstat, *fentchoix;
fentchoix=lookup_widget(button,"window_choix");
gtk_widget_destroy(fentchoix);
windowstat=create_window_stat();
gtk_widget_show (windowstat);
}

//////////////////// pas encore verifie 
void
on_buttonvalidv_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
/*listelectorale le;
GtkWidget *window_vote;
GtkWidget *idliste;

idliste=lookup_widget(objet,"comboboxentry1");
strcpy(le.idliste,gtk_combo_box_get_active_text(GTK_COMBO_BOX(idliste)));

nbv("vote.txt",idliste);
output=lookup_widget(button,"labelvote");
gtk_label_set_text(GTK_LABEL(output), "Vote enregistré avec succès ! ");*/
}


void
on_button_retous_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowstat, *fentchoix;
windowstat=lookup_widget(button,"window_stat");
gtk_widget_destroy(windowstat);
fentchoix=create_window_choix ();
gtk_widget_show (fentchoix);
}

//////////// PAS ENCORE ///////////
void
on_buttontri_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
/*GtkWidget *windowstat, *treeview_stat;

windowstat=lookup_widget(button,"window_stat");
treeview_stat=lookup_widget(objet,"treeview_stat");
L_ordre("vote.txt");
afficher_vote(treeview_stat);*/
}


void
on_button_retv_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowvote, *fentchoix;
windowvote=lookup_widget(button,"window_vote");
gtk_widget_destroy(windowvote);
fentchoix=create_window_choix ();
gtk_widget_show (fentchoix);
}

//////////// PAS ENCORE ///////////
void
on_treeview_stat_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
/*GtkTreeIter iter;
gchar* nom;
gchar* idlist;
gint* nb_vote;

listelectorale le;
liste_vote v;
GtkTreeModel *model= gtk_tree_view_get_model(treeview);
GtkWidget* window_stat,*window_gestionListe,*no,*id,*nbv;

if (gtk_tree_model_get_iter(model, &iter,path))
{
gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&nom,1,&idlist,2,&nb_vote,-1);

window_stat=create_window_stat();
gtk_widget_hide(window_stat);
gtk_widget_show(window_stat);

no=lookup_widget(window_gestionListe,"entry2_nomList");
gtk_entry_set_text(GTK_ENTRY(no),nom);

id=lookup_widget(window_gestionListe,"entry2_idListe");
gtk_entry_set_text(GTK_ENTRY(id),idlist);

FILE *f=fopen("vote.txt","r");
if(f!=NULL)
{
while ((fscanf(f,"%s %d", v.idliste, &v.nb_vote))!=EOF)
 
   

*/

}


void
on_listeelec_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajouter01;
GtkWidget *fenetre_afficher01;
GtkWidget *treeview1;



 
 fenetre_ajouter01=lookup_widget (button,"window1");
 gtk_widget_destroy(fenetre_ajouter01);
 fenetre_afficher01=lookup_widget (button, "window_choix");
 fenetre_afficher01=create_window_choix();

 gtk_widget_show(fenetre_afficher01); 

 treeview1=lookup_widget(fenetre_afficher01,"treeview1");
 affi(treeview1);
}
///////////////////////////////////////bv///////////////////////////////////////////////
int cp_ob=1;
int cp_ob2=1;
int test=0;
Vote te;
void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
cp_ob=1;
}

/*
void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
cp_ob=2;
}*/


void
on_radiobutton5_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
cp_ob=5;
}

/*
void
on_radiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
cp_ob=4;
}
*/

void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
cp_ob=3;
}
void
on_radiobutton6_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
cp_ob2=1;
}


void
on_radiobutton7_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
cp_ob2=2;
}


void
on_radiobutton8_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
cp_ob2=3;
}


void
on_radiobutton9_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
cp_ob2=4;
}


void
on_radiobutton10_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
cp_ob2=5;
}
void
on_button1_clicked                     (GtkWidget *objet_graphique, gpointer user_data)
{

}




void
on_button2_clicked                     (GtkWidget *objet_graphique, gpointer user_data)
{
GtkWidget*cin;
GtkWidget*ce;
GtkWidget*s;
GtkWidget*as;
GtkWidget*id;
GtkWidget*win;
GtkWidget*label;
Vote v;
win=lookup_widget(objet_graphique, "ok_vote");
cin=lookup_widget(objet_graphique, "entry3");
strcpy(v.id,gtk_entry_get_text(GTK_ENTRY(cin))); 
ce=lookup_widget(objet_graphique, "spinbutton1");
v.cpe=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ce));
v.cpo=cp_ob;
s=lookup_widget(objet_graphique, "comboboxentry1");
strcpy(v.salle,gtk_combo_box_get_active_text(GTK_COMBO_BOX(s)));
as=lookup_widget(objet_graphique, "entry4");
strcpy(v.ADRsalle,gtk_entry_get_text(GTK_ENTRY(as)));
id=lookup_widget(objet_graphique, "entry5");
strcpy(v.id_agent,gtk_entry_get_text(GTK_ENTRY(id)));
test=ajouter(v , "vote.txt");


win= create_ok_vote ();
gtk_widget_show(win);
}


void
on_button8_clicked                     (GtkWidget *objet_graphique, gpointer user_data)
{
GtkWidget*n;
GtkWidget*p;
n=lookup_widget(objet_graphique, "ajout-vote");
p=lookup_widget(objet_graphique, "menu");
p=  create_menu ();
gtk_widget_show(p);
gtk_widget_destroy(n);
}


void
on_button6_clicked                     (GtkWidget *objet_graphique, gpointer user_data)
{
GtkWidget*n;
GtkWidget*p;
n=lookup_widget(objet_graphique, "afficher-vote");
p=lookup_widget(objet_graphique, "menu");
n= create_afficher_vote ();
gtk_widget_show(n);
 gtk_widget_destroy(p);
}


void
on_button3_clicked                     (GtkWidget *objet_graphique, gpointer user_data)
{
GtkWidget*n;
GtkWidget*p;
n=lookup_widget(objet_graphique, "ajout-vote");
p=lookup_widget(objet_graphique, "menu");
n= create_ajout_vote();
gtk_widget_show(n);
 gtk_widget_destroy(p);
}


void
on_button5_clicked                     (GtkWidget *objet_graphique, gpointer user_data)
{
GtkWidget*n;
GtkWidget*p;
n=lookup_widget(objet_graphique, "window2");
p=lookup_widget(objet_graphique, "menu");
n= create_window2();
gtk_widget_show(n);
 gtk_widget_destroy(p);
}


void
on_button4_clicked                     (GtkWidget *objet_graphique, gpointer user_data)
{
GtkWidget*n;
GtkWidget*p;
n=lookup_widget(objet_graphique, "vaidmod");
p=lookup_widget(objet_graphique, "menu");
n= create_vaidmod();
gtk_widget_show(n);
 gtk_widget_destroy(p);
}


void
on_button9_clicked                     (GtkWidget *objet_graphique, gpointer user_data)
{
GtkWidget*n;
GtkWidget*p;
n=lookup_widget(objet_graphique, "window2");
p=lookup_widget(objet_graphique, "menu");
p= create_menu ();
gtk_widget_show(p);
 gtk_widget_destroy(n);
}


void
on_button7_clicked                     (GtkWidget *objet_graphique, gpointer user_data)
{
GtkWidget *id,*label;
char cin[20];
int t;
id=lookup_widget(objet_graphique, "entry6");
label=lookup_widget(objet_graphique, "label13");
strcpy(cin,gtk_entry_get_text(GTK_ENTRY(id))); 
t=supprimer (cin,"vote.txt");
if(t==1)
gtk_label_set_text(GTK_LABEL(label)," valider");
else
gtk_label_set_text(GTK_LABEL(label)," error");
}

/*
void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar *id;
gchar *ADRsalle;
gchar *id_agent;
gchar *salle;
gint *cpe;
gint *cpo;
Vote v;
int t;
GtkTreeModel *model=gtk_tree_view_get_model(treeview);
if (gtk_tree_model_get_iter(model,&iter,path))
{ gtk_tree_model_get(GTK_TREE_MODEL(model),&iter,0,&id,1,&cpe,2,&cpo,3,&salle,4,&ADRsalle,5,&id_agent,-1);
strcpy(v.id,id);
strcpy(v.salle,salle);
strcpy(v.ADRsalle,ADRsalle);
strcpy(v.id_agent,id_agent);
v.cpe=*cpe;
v.cpo=*cpo;
if(t=supprimer (v.id,"vote.txt")==1)
afficher_vote(treeview);
}
}
*/

void
on_button10_clicked                    (GtkWidget *objet_graphique, gpointer user_data)
{
GtkWidget *treeview;

treeview=lookup_widget(objet_graphique,"treeview1");
afficher_vote(GTK_TREE_VIEW(treeview));}


void
on_button11_clicked                    (GtkWidget *objet_graphique, gpointer user_data)
{
GtkWidget*n;
GtkWidget*p;
n=lookup_widget(objet_graphique, "afficher-vote");
p=lookup_widget(objet_graphique, "menu");
p= create_menu ();
gtk_widget_show(p);
 gtk_widget_destroy(n);
}


void
on_button13_clicked                    (GtkWidget *objet_graphique, gpointer user_data)
{
GtkWidget*label;
label=lookup_widget(objet_graphique, "label17");
if(test==0)
gtk_label_set_text(GTK_LABEL(label),"ajout échouée");
else
gtk_label_set_text(GTK_LABEL(label),"ajout avec success");
}


void
on_button15_clicked                    (GtkWidget *objet_graphique, gpointer user_data)
{
GtkWidget*n;
GtkWidget*p;
n=lookup_widget(objet_graphique, "vaidmod");
p=lookup_widget(objet_graphique, "menu");
p=  create_menu ();
gtk_widget_show(p);
gtk_widget_destroy(n);
}


void
on_button14_clicked                    (GtkWidget *objet_graphique, gpointer user_data)
{
GtkWidget*id;
GtkWidget*label;

char ch[20];

label=lookup_widget(objet_graphique, "label19");
id=lookup_widget(objet_graphique, "entry8");

strcpy(ch,gtk_entry_get_text(GTK_ENTRY(id)));
te=chercher(ch,"vote.txt");
if(strcmp(te.id,"-1")==0)
gtk_label_set_text(GTK_LABEL(label),"id non trouvé");
else
{
gtk_label_set_text(GTK_LABEL(label),"trouvé");

}
}


void
on_button18_clicked                    (GtkWidget *objet_graphique, gpointer user_data)
{
GtkWidget*n;
GtkWidget*p;
n=lookup_widget(objet_graphique, "vaidmod");
p=lookup_widget(objet_graphique, "modify_vote");
p=create_modify_vote();
gtk_widget_show(p);
gtk_widget_destroy(n);
}


void
on_button16_clicked                    (GtkWidget *objet_graphique, gpointer user_data)
{
GtkWidget*cin;
GtkWidget*ce;
GtkWidget*s;
GtkWidget*as;
GtkWidget*id;
Vote v;
int t;
cin=lookup_widget(objet_graphique, "entry11");
strcpy(v.id,gtk_entry_get_text(GTK_ENTRY(cin))); 
ce=lookup_widget(objet_graphique, "spinbutton2");
v.cpe=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ce));
v.cpo=cp_ob;
s=lookup_widget(objet_graphique, "comboboxentry2");
strcpy(v.salle,gtk_combo_box_get_active_text(GTK_COMBO_BOX(s)));
as=lookup_widget(objet_graphique, "entry10");
strcpy(v.ADRsalle,gtk_entry_get_text(GTK_ENTRY(as)));
id=lookup_widget(objet_graphique, "entry9");
strcpy(v.id_agent,gtk_entry_get_text(GTK_ENTRY(id)));
t=modifier(v.id, v, "vote.txt");
}





void
on_button17_clicked                    (GtkWidget *objet_graphique, gpointer user_data)
{
GtkWidget*n;
GtkWidget*p;
n=lookup_widget(objet_graphique, "modify_vote");
p=lookup_widget(objet_graphique, "menu");
p=  create_menu ();
gtk_widget_show(p);
gtk_widget_destroy(n);
}


void
on_button19_clicked                    (GtkWidget *objet_graphique, gpointer user_data)
{
GtkWidget*id;
GtkWidget*ce;
GtkWidget*r1;
GtkWidget*r2;
GtkWidget*r3;
GtkWidget*r4;
GtkWidget*r5;
GtkWidget*s;
GtkWidget*as;
GtkWidget*ida;
GtkWidget*win;
int x;
id=lookup_widget(objet_graphique, "entry11");
ce=lookup_widget(objet_graphique, "spinbutton2");
r1=lookup_widget(objet_graphique, "radiobutton6");
r2=lookup_widget(objet_graphique, "radiobutton7");
r3=lookup_widget(objet_graphique, "radiobutton8");
r4=lookup_widget(objet_graphique, "radiobutton9");
r5=lookup_widget(objet_graphique, "radiobutton10");
s=lookup_widget(objet_graphique, "comboboxentry2");
as=lookup_widget(objet_graphique, "entry10");
ida=lookup_widget(objet_graphique, "entry9");
if(te.cpo==1)
gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(r1),TRUE);
else if(te.cpo==2)
gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(r2),TRUE);
else if(te.cpo==3)
gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(r3),TRUE);
else if(te.cpo==4)
gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(r4),TRUE);
else 
gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(r5),TRUE);
x=te.cpe;
gtk_spin_button_set_value(GTK_SPIN_BUTTON(ce),x);
if((strcmp(te.salle,"A")==0))
gtk_combo_box_set_active(GTK_COMBO_BOX(s),1);
else if((strcmp(te.salle,"B")==0))
gtk_combo_box_set_active(GTK_COMBO_BOX(s),2);
else if((strcmp(te.salle,"C")==0))
gtk_combo_box_set_active(GTK_COMBO_BOX(s),3);
else if((strcmp(te.salle,"D")==0))
gtk_combo_box_set_active(GTK_COMBO_BOX(s),4);
else if((strcmp(te.salle,"E")==0))
gtk_combo_box_set_active(GTK_COMBO_BOX(s),5);
else
gtk_combo_box_set_active(GTK_COMBO_BOX(s),6);
gtk_entry_set_text(GTK_ENTRY(id),te.id);
gtk_entry_set_text(GTK_ENTRY(as),te.ADRsalle);
gtk_entry_set_text(GTK_ENTRY(ida),te.id_agent);
}


void
on_bv_clicked                          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajouter01;
GtkWidget *fenetre_afficher01;
GtkWidget *treeview1;



 
 fenetre_ajouter01=lookup_widget (button,"window1");
 gtk_widget_destroy(fenetre_ajouter01);
 fenetre_afficher01=lookup_widget (button, "menu");
 fenetre_afficher01=create_menu();

 gtk_widget_show(fenetre_afficher01); 

 treeview1=lookup_widget(fenetre_afficher01,"treeview1");
 affi(treeview1);
}
///////////////reclamation////////////////
int role;
char genrez[10];
  GtkWidget *reclamation;
  GtkWidget *entry_search;
  GtkWidget *entry_lelec;
  GtkWidget *entry_id;
  GtkWidget *entry_reclamation;
  GtkWidget *entry_type;
  GtkWidget *button_ok;
  GtkWidget *button_add;
  GtkWidget *button_edit;
  GtkWidget *button_delete;
  GtkWidget *button5_exit;
  GtkWidget *button_display;
  GtkWidget *label155;
  GtkWidget *spinbutton_jr;
  GtkWidget *spinbutton_mois;
  GtkWidget *spinbutton_annee;
  GtkWidget *label209;
  GtkWidget *entry1_bureau_de_vote;
  GtkWidget *nb_vote	;

void
on_button_recheche_clicked             (GtkWidget       *graphic_object,
                                        gpointer         user_data)
{
 GtkWidget *treeview;
 GtkWidget *displaying;
 GtkWidget *reclamation;
reclam t;
int success;

entry_lelec=lookup_widget(graphic_object,"entry_recherche");
strcpy(t.id, gtk_entry_get_text(GTK_ENTRY(entry_lelec)));
success=recherche(t.id,"reclamation.txt");



reclamation=lookup_widget(graphic_object,"reclamation");
displaying=lookup_widget(graphic_object,"affichage");

gtk_widget_destroy(reclamation);

displaying=create_affichage();
gtk_widget_show(displaying);
treeview=lookup_widget(displaying,"treeview_rec");
affichage(treeview,"recherche.txt");


}


void
on_button_ajoutes_clicked              (GtkWidget       *graphic_object,
                                        gpointer         user_data)
{
reclam t;
int success;


entry_lelec=lookup_widget(graphic_object,"entry_lelec");
entry_id=lookup_widget(graphic_object,"entry_id");
entry_reclamation=lookup_widget(graphic_object,"entry_reclamation");
entry_type=lookup_widget(graphic_object,"entry_type_reclamation");
spinbutton_jr=lookup_widget(graphic_object,"spinbutton_jr");
spinbutton_mois=lookup_widget(graphic_object,"spinbutton_mois");
spinbutton_annee=lookup_widget(graphic_object,"spinbutton_annee");
label155=lookup_widget(graphic_object,"label155");

strcpy(t.lelec, gtk_entry_get_text(GTK_ENTRY(entry_lelec)));
strcpy(t.id, gtk_entry_get_text(GTK_ENTRY(entry_id)));



strcpy(t.reclamation, gtk_entry_get_text(GTK_ENTRY(entry_reclamation)));
strcpy(t.type, gtk_entry_get_text(GTK_ENTRY(entry_type)));


t.dor.day=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton_jr));
t.dor.month=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton_mois));
t.dor.year=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton_annee));





success=add_rec(t,"reclamation.txt");
if(success==1) gtk_label_set_text(GTK_LABEL(label155),"bien ajoute ") ;
else gtk_label_set_text(GTK_LABEL(label155),"erreur");
}


void
on_button_effacer_clicked              (GtkWidget       *graphic_object,
                                        gpointer         user_data)
{
char id[20];
int success=0;


entry_id=lookup_widget(graphic_object,"entry_id");
label155=lookup_widget(graphic_object,"label155");



strcpy(id, gtk_entry_get_text(GTK_ENTRY(entry_id)));


success=del_sadok(id,"reclamation.txt");
if(success==1) gtk_label_set_text(GTK_LABEL(label155),"bien supprimer") ;
else gtk_label_set_text(GTK_LABEL(label155),"erreur");
}


void
on_button_modif_clicked                (GtkWidget       *graphic_object,
                                        gpointer         user_data)
{

reclam t;
int success;


entry_lelec=lookup_widget(graphic_object,"entry_lelec");
entry_id=lookup_widget(graphic_object,"entry_id");
entry_reclamation=lookup_widget(graphic_object,"entry_reclamation");
entry_type=lookup_widget(graphic_object,"entry_type_reclamation");
spinbutton_jr=lookup_widget(graphic_object,"spinbutton_jr");
spinbutton_mois=lookup_widget(graphic_object,"spinbutton_mois");
spinbutton_annee=lookup_widget(graphic_object,"spinbutton_annee");
label155=lookup_widget(graphic_object,"label155");



strcpy(t.lelec, gtk_entry_get_text(GTK_ENTRY(entry_lelec)));
strcpy(t.id, gtk_entry_get_text(GTK_ENTRY(entry_id)));



strcpy(t.reclamation, gtk_entry_get_text(GTK_ENTRY(entry_reclamation)));
strcpy(t.type, gtk_entry_get_text(GTK_ENTRY(entry_type)));


t.dor.day=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton_jr));
t.dor.month=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton_mois));
t.dor.year=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spinbutton_annee));

success=modify_sadok(t,"reclamation.txt");
if(success==1) gtk_label_set_text(GTK_LABEL(label155),"ien modifier") ;
else gtk_label_set_text(GTK_LABEL(label155),"Erreur");
}






void
on_afficher_clicked                    (GtkButton       *graphic_object,
                                        gpointer         user_data)
{
 GtkWidget *treeview;
 GtkWidget *displaying;
 GtkWidget *reclamation;

reclamation=lookup_widget(graphic_object,"reclamation");
displaying=lookup_widget(graphic_object,"affichage");

gtk_widget_destroy(reclamation);

displaying=create_affichage();
gtk_widget_show(displaying);
treeview=lookup_widget(displaying,"treeview_rec");
affichage(treeview,"reclamation.txt");

}


void
on_retour_clicked                      (GtkButton       *graphic_object,
                                        gpointer         user_data)
{
 GtkWidget *displaying;
 GtkWidget *reclamation;
 reclamation=lookup_widget(graphic_object,"reclamation");
 displaying=lookup_widget(graphic_object,"affichage");

 gtk_widget_destroy(displaying);

displaying=create_reclamation();
gtk_widget_show(displaying);





}



void
on_calculer_clicked                    (GtkButton       *graphic_object,
                                        gpointer         user_data)
{

int bureau_de_vote,nb;


char string[4];
entry1_bureau_de_vote=lookup_widget(graphic_object,"entry1_bureau_de_vote");



nb_vote=lookup_widget(graphic_object,"nb_vote");


strcpy(string, gtk_entry_get_text(GTK_ENTRY(entry1_bureau_de_vote)));
bureau_de_vote = atoi(string);
nb=nbv_par_bureau("user.txt",bureau_de_vote );


sprintf(string, "%d", nb);

gtk_label_set_text(GTK_LABEL(nb_vote), string);





}



void
on_reclamation_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajouter01;
GtkWidget *fenetre_afficher01;
GtkWidget *treeview1;



 
 fenetre_ajouter01=lookup_widget (button,"window1");
 gtk_widget_destroy(fenetre_ajouter01);
 fenetre_afficher01=lookup_widget (button, "reclamation");
 fenetre_afficher01=create_reclamation();

 gtk_widget_show(fenetre_afficher01); 

 treeview1=lookup_widget(fenetre_afficher01,"treeview1");
 affi(treeview1);
}

