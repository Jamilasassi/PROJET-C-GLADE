#include <gtk/gtk.h>


void
on_button2_ajouter_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_restau_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_general_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_nv_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_anc_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button2_rajout_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_nbr4_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_nbr3_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_nbr2_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_nbr1_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_nbr5_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_nbr6_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton1_confirmer_clicked      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button1_ajouterElection_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_retourajt_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_affElection_row_activated (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button2_windAjouter_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_windModif_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_rechElect_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_SuppElect_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_affElect_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_nbr7_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton1_confirmer_toggled      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_nbr1_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_nbr2_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_nbr3_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_nbr4_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_nbr5_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_nbr7_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_nbr6_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button3_reche_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3_retrecher_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbutton1_confi_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button1_ModifierElection_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_retourajt_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_recElect_row_activated    (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button2_tachcalcul_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview4_TPHF_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button4_retCAl_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3_calculEl_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_nbhhh_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_nbffff_clicked              (GtkButton       *button,
                                        gpointer         user_data);
