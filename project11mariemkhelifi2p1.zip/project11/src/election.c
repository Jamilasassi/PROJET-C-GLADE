#include "election.h"
#include <gtk/gtk.h>

int ajouter(char *filename, election elect)
{
    FILE * f;
    f=fopen(filename, "a+");
    if(f!=NULL)
    {
        fprintf(f,"%d %d %d %s %s %s %d %s \n", elect.jour,elect.mois, elect.annee,elect.id,e.gouv,elect.nb_habitants, elect.nb_conseillers);
        fclose(f);
      return 1;
    }
    else
      return 0;

	
}
/*int modifier( char *filename, char id[], election nouv )
{
    int tr=0;
    election elect;
    FILE *f=fopen(filename, "r");
    FILE *f2=fopen("nouv.txt", "w");
    if(f!=NULL && f2!=NULL)
    {
        while(fscanf(f,"%d %d %d %s %s %s %d %s\n", &elect.jour,&elect.mois,&elect.annee,elect.gouv,elect.id,elect.nb_habitant, &elect.nb_conseiller, elect.statut)!=EOF)
        {
            if(strcmp(elect.id,id)==0)
            {
                fprintf(f2,"%d %d %d %s %s %s %d %s \n",nouv.jour,nouv.mois,nouv.annee, nouv.id,nouv.gouv, nouv.nb_habitants, nouv.nb_conseillers);
                tr=1;
            }
            else
               fprintf(f2,"%d %d %d %s %s %s %d %s \n", elect.jour,elect.mois, elect.annee,elect.id,elect.gouv,elect.nb_habitants,elect.nb_conseillers, );

        }
    }
    fclose(f);
    fclose(f2);
    remove(filename);
    rename("nouv.txt", filename);
    return tr;

}*/
/*int supprimer(char * filename, char id[])
{
    int tr=0;
    election elect;
    FILE * f=fopen(filename, "r");
    FILE * f2=fopen("nouv.txt", "w");
    if(f!=NULL && f2!=NULL)
    {
          while(fscanf(f,"%d %d %d %s %s %s %d %s \n",&elect.jour,&elect.mois, &elect.annee,elect.id,e.gouv , elect.nb_habitants , &elect.nb_conseillers,)!=EOF)
        {
            if(strcmp(elect.id,id)==0)
                tr=1;
            else
                fprintf(f2,"%d %d %d %s %s %s %d %s \n",elect.jour,elect.mois, elect.annee,elect.id,elect.gouv,elect.nb_habitants,elect.nb_conseillers, );
        }
    }
    fclose(f);
    fclose(f2);
    remove(filename);
    rename("nouv.txt", filename);
    return tr;
election chercher(char *filename, char id[])
{
    election elect;
    int tr=0;
    FILE *f=fopen(filename, "r");
    if(f!=NULL)
    {
        while(tr==0&& fscanf(f,"%d %d %d %s %s %s %d %s \n",&elect.jour,&elect.mois, &elect.annee,elect.gouv,elect.id,elect.nb_habitant, &elect.nb_conseiller)!=EOF)
        {
            if(strcmp(elect.id,id)==0)
                tr=1;
        }
    }
    fclose(f);
    if(tr==0)
        strcpy(elect.id, "-1");
    return elect;

}
/*
int calcul_nb_habitant(long nb_h)
{
int nb_conseiller;
if (nb_h<=5000)
{
nb_conseiller=10;}
else if((nb_h>=5001)&&(nb_h<=10000))
nb_conseiller=12;
else if ((nb_h>=10001)&&(nb_h<=25000))
nb_conseiller=16;
else if ((nb_h>=25001)&&(nb_h<=50000))
nb_conseiller=22;
else if ((nb_h>=50001)&&(nb_h<=100000))
nb_conseiller=30;
else if ((nb_h>=100001)&&(nb_h<=500000))
nb_conseiller=40;
else if (nb_h>=500001)
nb_conseiller=60;
return nb_conseiller;
}
*/

enum
{
JOUR,
MOIS, 
ANNEE, 
GOUVERNORAT,
IDENTIFIANT,
NOMBRE_HABITANTS, 
NOMBRE_CONSEILLERS,
COLUMNS
};
void afficher(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
election e; 
store=NULL;
FILE *f; 
if (store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Jour", renderer, "text", JOUR, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Mois", renderer, "text", MOIS, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Annee", renderer, "text", ANNEE, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Gouvernorat", renderer, "text", MUNICIPALITE, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("ID", renderer, "text", IDENTIFIANT, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Nbr habitants", renderer, "text", NOMBRE_HABITANT, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("Nbr Conseillers", renderer, "text", NOMBRE_CONSEILLER, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);


}


store= gtk_list_store_new(COLUMNS, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT, G_TYPE_STRING);
f=fopen("fichelect.txt", "r");
if (f==NULL)
{
return;
}
else
{f=fopen("fichelect.txt", "a+");
while(fscanf(f,"%d %d %d %s %s %s %d %s\n", &e.jour,&e.mois,&e.annee,e.id,e.nb_habitants, &e.nb_conseillers)!=EOF)
{
gtk_list_store_append (store, &iter);
		gtk_list_store_set (store, &iter, JOUR, e.jour, MOIS, e.mois, ANNEE, e.annee, GOUVERNORAT,e.gouv, IDENTIFIANT, e.id , NOMBRE_HABITANTS, e.nb_habitants ,NOMBRE_CONSEILLERS, e.nb_conseillers,-1);
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
g_object_unref(store);
}
}


/*int supprimer(char * filename ,int id)
{
    int tr=0;
    election E;
    FILE *f=fopen(filename,"r");
    FILE *f2=fopen("nouv.txt","w");
    if (f!=NULL && f2!=NULL)
    { while(fscanf(f,"%d %d %d %d %d %d %s ", &E.id , &E.d.jour,&E.d.mois,&E.d.annee,&E.nbrhabitants,&E.nbrconseillers,
                 E.gouvernorat)!=EOF)
                  {
                       if(E.identifiant==identifiant)
                        tr=1;
                       else
                          fprintf(f2,"%d %d %d %d %d %d %s", E.id , E.d.jour,E.d.mois,E.d.annee,E.nbrhabitants,E.nbrconseillers,
                 E.gouvernorat);
                  }


    }
    fclose(f);
    fclose(f2);
    remove (filename);
    rename ("nouv.txt", filename);
    return tr;
