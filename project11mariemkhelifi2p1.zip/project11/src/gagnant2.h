#ifndef election_H_INCLUDES
#define election_H_INCLUDES
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct Date
{
int j;
int m;
int a;
} date;
typedef struct listElec
{
date d;
char gouvernorat[50];
int nb_habitants;
int nb_conseillers;
int id;
Date d;
}election;
int ajouter(char *, election);
int modifier( char *,int, election);
int supprimer(char *, int );
election chercher (char *, int);
#endif // élection_H_INCLUDES
int 


