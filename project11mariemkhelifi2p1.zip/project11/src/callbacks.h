#include <gtk/gtk.h>


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button2_modifier_une_election_clicked
                                        (GtkWidget       *objet_graphigue,
                                        gpointer         user_data);

void
on_button1_ajouter_une_election_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button3_supprimer_une_election_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button4_afficher_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button7_ajouter_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button8_retour_treeajout_clicked    (GtkWidget       *objet_graphique,
                                      
  gpointer         user_data);

void
on_button9_chercher_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button10_modifier_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button11_retour_treemodif_clicked   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button12_suuprimer_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button13_retour_treesupp_clicked    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_radiobutton1traiter_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);
