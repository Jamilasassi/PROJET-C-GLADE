#ifndef ELECTION_H_INCLUDED
#define ELECTION_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
typedef struct elections{
int jour;
int mois;
int annee;
char id[50];
char gouv[50];
char nb_habitants[50];
int nb_conseillers;
} election;
int ajouter(char *, election elect);
int modifier( char *, char *, election elect);
int supprimer(char *, char*);
election chercher(char *, char *);
void afficher(GtkWidget *);
int calcul_nb_conseillers(long);
#endif //ELECTION_H_INCLUDED
