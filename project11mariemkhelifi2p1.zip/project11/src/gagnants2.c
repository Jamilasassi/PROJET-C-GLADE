#include "gagnant.h"
GDU chercher(char * filename, int id)

{

    GDU s;

    int tr=0;

    FILE * f=fopen(filename, "r");

    if(f!=NULL)

    {

        while(tr==0&& fscanf(f,"%s %s %d/%d/%d %c %d %s %s %s %d %d\n",s.Nom,s.Prenom,&s.jour,&s.mois,&s.annee,&s.Gender,&s.N_CIN,s.Id,s.Pass,s.TypeUtilisateur,&s.vote,&s.NumBV)!=EOF)

        {

            if(s.N_CIN== id)

                tr=1;

        }

    }

    fclose(f);

    if(tr==0)

        s.N_CIN=-1;

    return s;



}
int gagnant( Listelect gag[], int nb_habitant, listelec t[], int n)
{
int nb_conseiller=0;
int i, j, q, y;
i=0;
j=0;
//GDU tab[];
//tab=gag;
//tab=(GDU*)malloc(20*sizeof(GDU));
if (nb_habitant<=5000)
nb_conseiller=10;
else if((nb_habitant>=5001)&&(nb_habitant<=10000))
nb_conseiller=12;
else if ((nb_habitant >=10001)&&(nb_habitant<=25000))
nb_conseiller=16;
else if ((nb_habitant>=25001)&&(nb_habitant<=50000))
nb_conseiller=22;
else if ((nb_habitant>=50001)&&(nb_habitant<=100000))
nb_conseiller=30;
else if ((nb_habitant>=100001)&&(nb_habitant<=500000))
nb_conseiller=40;
else if (nb_habitant>=500001)
nb_conseiller=60;
//calcul du nombre de conseiller d'après le nombre d'habitant

while ((nbr_conseiller!=0)&&(i<n))//N taille du tableau listelec
{
gag[i]=t[i];
//boucle if comparaison avec 0
if (nb_conseiller>=t[i].candidat)
nb_conseiller=nb_conseiller-t[i].candidat;
else if (nb_conseiller<=t[i].candidat)
nb_conseiller=0;
i++;
}


return 0;
}
