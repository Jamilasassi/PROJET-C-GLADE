#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <gtk/gtk.h>
#include "election.h"
#include "callbacks.h"
#include "interface.h"
#include "support.h"



on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar *jour ;
gchar *mois;
gchar *annee;
gchar *identifiant ;
gchar *gouvernorat;
gchar *nombre_habitants;
gchar *nombre_conseillers ;



GtkTreeModel *model= gtk_tree_view_get_model(treeview);
if (gtk_tree_model_get_iter(model,&iter,path))

gtk_tree_model_get(GTK_LIST_STORE(model),&iter,&jour,1,&mois,2,&annee,3,&identifiant,4,&gouvernorat,5,&nombre_habitants,6,&nombre_conseillers,-1);
int k =supprimer("fichelect.txt", identifiant) ;
}


void
on_button2_modifier_une_election_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *w ,*Modifier_election;
GtkWidget *treeview1 ;
w=lookup_widget(objet_graphique,"Afficher");
gtk_widget_hide(w);
  Modifier_election= create_Modifier_election();
  gtk_widget_show (Modifier_election);
}


void
on_button1_ajouter_une_election_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *w ,*Ajouter_election ;
GtkWidget *treeview1 ;
w=lookup_widget(objet_graphique,"Afficher");
gtk_widget_hide(w);
  Ajouter_election= create_Ajouter_election();
  gtk_widget_show (Ajouter_election);
}


void
on_button3_supprimer_une_election_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *w ,*supprimer_election;
GtkWidget *treeview1 ;
w=lookup_widget(objet_graphique,"Afficher");
gtk_widget_hide(w);
  supprimer_election= create_supprimer_election();
  gtk_widget_show (supprimer_election);
}

void
on_button4_afficher_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Afficher , *treeview1;
Afficher=lookup_widget(objet_graphique, "Afficher");
treeview1=lookup_widget(objet_graphique, "treeview1");
afficher(treeview1);
}


void
on_button7_ajouter_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)

	{
GtkWidget *spin_jour;
GtkWidget *spin_mois;
GtkWidget *spin_annee;
GtkWidget *entry_id;
GtkWidget *entry_nbr_habitants; 
GtkWidget *entry_nbr_conseillers; 
GtkWidget *combof;
GtkWidget *output;
election elect;

char jj[10]; 
char mm[10];
char aaaa[10];
char id[30];
char *p=NULL;
long nb_h;
int x;

entry_id=lookup_widget(objet_graphique, "entry_id");
entry_nbr_habitants=lookup_widget(objet_graphique, "entry_nbr_habitants");
entry_nbr_conseillers=lookup_widget(objet_graphique, "entry_nbr_conseillers");
spin_jour=lookup_widget(objet_graphique, "spin_jour");
spin_mois=lookup_widget(objet_graphique, "spin_mois");
spin_annee=lookup_widget(objet_graphique, "spin_annee");
combof=lookup_widget(objet_graphique, "combo_muni");
strcpy(elect.id, gtk_entry_get_text(GTK_ENTRY(entry_id)));
strcpy(elect.nb_habitants,gtk_entry_get_text(GTK_ENTRY(entry_nbr_habitants)));

strcpy(elect.gouv, gtk_combo_box_get_active_text(GTK_COMBO_BOX(combof)));

elect.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin_jour));
elect.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin_mois));
elect.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin_annee));

nb_h=strtol(elect.nb_habitants, &p, 16);

if (nb_h<=5000)
elect.nb_conseillers=10;
else if((nb_h>=5001)&&(nb_h<=10000))
elect.nb_conseillers=12;
else if ((nb_h>=10001)&&(nb_h<=25000))
elect.nb_conseillers=16;
else if ((nb_h>=25001)&&(nb_h<=50000))
elect.nb_conseillers=22;
else if ((nb_h>=50001)&&(nb_h<=100000))
elect.nb_conseillers=30;
else if ((nb_h>=100001)&&(nb_h<=500000))
elect.nb_conseillers=40;
else if (nb_h>=500001)
elect.nb_conseillers=60;

x=ajouter("election.txt", elect);
	}


void
on_button8_retour_treeajout_clicked    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
	{
GtkWidget *w ,*Afficher;
GtkWidget *treeview1 ;
w=lookup_widget(objet_graphique,"Ajouter_election");
gtk_widget_hide(w);
  Afficher= create_Afficher();
  gtk_widget_show (Afficher);
	}


void
on_button9_chercher_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data)

{
GtkWidget *spin_jour;
GtkWidget *spin_mois;
GtkWidget *spin_annee;
GtkWidget *entry_id;
GtkWidget *entry_nbr_habitants; 
GtkWidget *combof;
GtkWidget *output;
GtkWidget *togglef1;
GtkWidget *togglef2;
election elec, e;
char j[10]; 
char mm[10];
char an[10];
char gouv[50];
char idd[30];
long nb_h;
int x1;
int i, jour, mois;
long annee;

entry_id=lookup_widget(objet_graphique, "entry_id2");
entry_nbr_habitants=lookup_widget(objet_graphique, "entry_nb_h2");

spin_jour=lookup_widget(objet_graphique, "spin_jour2");
spin_mois=lookup_widget(objet_graphique, "spin_mois2");
spin_annee=lookup_widget(objet_graphique, "spin_annee2");

combof=lookup_widget(objet_graphique, "combo_muni2");
output=lookup_widget(objet_graphique, "resultatf");
togglef1=lookup_widget(objet_graphique, "Rachevee2");
togglef2=lookup_widget(objet_graphique, "Rcours_2");

strcpy(elec.id, gtk_entry_get_text(GTK_ENTRY(entry_id)));
e=chercher("fichelect.txt", elec.id);

if(strcmp(e.id,"-1")!=0)
{
   gtk_entry_set_text(GTK_ENTRY(entry_nbr_habitants), e.nb_habitants);
        if (strcmp(e.gouv, "Gabes")==0)
	gtk_combo_box_set_active(GTK_COMBO_BOX(combof),0);
    else if(strcmp(e.gouv, "Tunis")==0)
	gtk_combo_box_set_active(GTK_COMBO_BOX(combof),1);
    else if (strcmp(e.gouv, "")==0)
	gtk_combo_box_set_active(GTK_COMBO_BOX(combof),2);
    else if (strcmp(e.gouv,  "Ariana")==0)
	gtk_combo_box_set_active(GTK_COMBO_BOX(combof),3);
    else if (strcmp(e.gouv, "Gbelli")==0)
	gtk_combo_box_set_active(GTK_COMBO_BOX(combof),4);
    else if (strcmp(e.gouv, "Monastir")==0)
	gtk_combo_box_set_active(GTK_COMBO_BOX(combof),5);

	gtk_spin_button_set_value(GTK_SPIN_BUTTON(spin_jour), e.jour);
	gtk_spin_button_set_value(GTK_SPIN_BUTTON(spin_mois), e.mois);
	gtk_spin_button_set_value(GTK_SPIN_BUTTON(spin_annee), e.annee);

}


/*void
on_button10_modifier_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *entry_id;
election elec, e;
char j[10]; 
char mm[10];
char an[10];
char gouv[50];
char idd[30];
entry_id=lookup_widget(objet_graphique, "entry_id");

}*/


void
on_button11_retour_treemodif_clicked   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
	{
GtkWidget *w ,*Afficher;
GtkWidget *treeview1 ;
w=lookup_widget(objet_graphique,"Modifier_election");
gtk_widget_hide(w);
  Afficher= create_Afficher();
  gtk_widget_show (Afficher);
	}


/*void
on_button12_suuprimer_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *spin_jour;
GtkWidget *spin_mois;
GtkWidget *spin_annee;
GtkWidget *entry_id;
election elect e ;

char jj[10]; 
char mm[10];
char aaaa[10];
char id[30];
entry_id=lookup_widget(objet_graphique, "entry_id2");
spin_jour=lookup_widget(objet_graphique, "spin_jour2");
spin_mois=lookup_widget(objet_graphique, "spin_mois2");
spin_annee=lookup_widget(objet_graphique, "spin_annee2");
        gtk_spin_button_set_value(GTK_SPIN_BUTTON(spin_jour), e.jour);
	gtk_spin_button_set_value(GTK_SPIN_BUTTON(spin_mois), e.mois);
	gtk_spin_button_set_value(GTK_SPIN_BUTTON(spin_annee), e.annee);

}*/


void
on_button13_retour_treesupp_clicked    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *w ,*Afficher;
GtkWidget *treeview1 ;
w=lookup_widget(objet_graphique,"supprimer_election");
gtk_widget_hide(w);
  Afficher= create_Afficher();
  gtk_widget_show (Afficher);
}

/*
void
on_radiobutton1traiter_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}*/
/*

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}*/
