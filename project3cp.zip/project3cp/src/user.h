#ifndef FONCTIONS_H_INCLUDED
#define FONCTIONS_H_INCLUDED
#include <gtk/gtk.h>
typedef struct date_de_naissance 
{
int jour ;
int mois ;
int annee ;
}DATE ;
typedef struct parametres_de_connexion 
{
char identifiant[20] ;
char mot_de_passe[20] ;
}pdc;


typedef struct user
{ char cin[20] ;
  char nom[20] ;
  char prenom[20] ;
  char genre[30] ;
  DATE  date ;
  pdc pcx ;
  char role[80] ;
  char num_tel[100] ;
  char ville [100] ;
  int vote ;
  int num_bv ;
 }user ;
int ajouter_user(char * filename, user u);
int modifier_user(user u , char cin[]) ;
int supprimer_user(char * filename ,char cin[]) ;
user chercher_user(char * filename , char cin[]) ;
void afficher_user(GtkWidget *liste);
void vider_user(GtkWidget *liste) ;
int verif_nour (char identifiant[] , char mot_de_passe[]) ;
float TPE(char *filename) ;
float TVB(char  *filename);
#endif

