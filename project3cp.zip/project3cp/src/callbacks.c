#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include "user.h"
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int h=1;
int g=0;
int A[10];

void
on_button_inscrit_nour_authen_clicked  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *w,*ajout_nour;


w=lookup_widget(objet_graphique,"authentification");
gtk_widget_hide(w);
ajout_nour = create_ajout_nour();
  gtk_widget_show (ajout_nour);

}


void
on_button_cnx_nour_authen_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *w,*menu;
GtkWidget *identifiant , *mdp ;
identifiant=lookup_widget(objet_graphique,"entry_id_nour_authen");
mdp=lookup_widget(objet_graphique,"entry_mdp_nour_authen");
w=lookup_widget(objet_graphique,"authentification");
gtk_widget_hide(w);
menu = create_menu();
  gtk_widget_show (menu);

}


void
on_radiobutton_homme_nour_ajout_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if  (gtk_toggle_button_get_active(togglebutton))
{h=1;}

}


void
on_radiobutton_femme_nour_ajout_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if  (gtk_toggle_button_get_active(togglebutton))
{h=2;}

}


void
on_button_retour_nour_ajout_clicked    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *w,*gestion_des_utilisateurs;
w=lookup_widget(objet_graphique,"ajout_nour");
gtk_widget_hide(w);
gestion_des_utilisateurs= create_gestion_des_utilisateurs();
  gtk_widget_show (gestion_des_utilisateurs);
}


void
on_button_ajouter_nour_ajout_clicked   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
user u;
GtkWidget *output;
GtkWidget *nom;
GtkWidget *prenom;
GtkWidget *identifiant;
GtkWidget *cin;
GtkWidget *num_tel;
GtkWidget *mdp;
GtkWidget *ville;
GtkWidget *vote;
GtkWidget *num_bv;
GtkWidget *combobox_role_nour_ajout;
int a,b,c;

GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;
combobox_role_nour_ajout=lookup_widget(objet_graphique,"combobox_role_nour_ajout");
if(strcmp("administrateur",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_role_nour_ajout)))==0)
 strcpy(u.role,"administrateur");
if(strcmp("agent de bureau de vote",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_role_nour_ajout)))==0)
 strcpy(u.role,"agent de bureau de vote");
if(strcmp("électeur",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_role_nour_ajout)))==0)
 strcpy(u.role,"électeur");
if(strcmp("observateur",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_role_nour_ajout)))==0)
 strcpy(u.role,"observateur");
nom=lookup_widget(objet_graphique,"entry_nom_nour_ajout");
prenom=lookup_widget(objet_graphique,"entry_prenom_nour_ajout");
identifiant=lookup_widget(objet_graphique,"entry_id_nour_ajout");
cin=lookup_widget(objet_graphique,"entry_cin_nour_ajout");
num_tel=lookup_widget(objet_graphique,"entry_num_tel_nour_ajout");
mdp=lookup_widget(objet_graphique,"entry_mdp_nour_ajout");
ville=lookup_widget(objet_graphique,"entry_ville_nour_ajout");
vote=lookup_widget(objet_graphique,"entry_vote_nour_ajout");
num_bv=lookup_widget(objet_graphique,"entry_bv_nour_ajout");
strcpy(u.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(u.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(u.pcx.identifiant,gtk_entry_get_text(GTK_ENTRY(identifiant)));
strcpy(u.cin,gtk_entry_get_text(GTK_ENTRY(cin)));

strcpy(u.pcx.mot_de_passe,gtk_entry_get_text(GTK_ENTRY(mdp)));
int m=atoi(gtk_entry_get_text(GTK_ENTRY(vote)));
int n=atoi(gtk_entry_get_text(GTK_ENTRY(num_bv)));
u.vote=m;
u.num_bv=n ;


if(h==1)
{
strcpy(u.genre,"homme");
}
if(h==2)
{
strcpy(u.genre,"femme");
}

jour=lookup_widget(objet_graphique, "spinbutton_jour_nour_ajout");
mois=lookup_widget(objet_graphique, "spinbutton_mois_nour_ajout");
annee=lookup_widget(objet_graphique, "spinbutton_annee_nour_ajout");
output=lookup_widget(objet_graphique,"label_msg_nour_ajout");
u.date.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour));
u.date.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (mois));
u.date.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (annee));

int i=ajouter_user("user.txt", u) ;
if (i==1)
gtk_label_set_text(GTK_LABEL(output),"ajout avec succes");
else if (i==0)
gtk_label_set_text(GTK_LABEL(output),"echec d'ajout");

}


void
on_button_affiche_nour_ajout_clicked   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *w,*gestion_des_utilisateurs;
GtkWidget *treeview_gestion_gu_nour ;
w=lookup_widget(objet_graphique,"ajout_nour");
gtk_widget_destroy(w);
gestion_des_utilisateurs=lookup_widget(objet_graphique,"gestion_des_utilisateurs");
gestion_des_utilisateurs = create_gestion_des_utilisateurs();
  gtk_widget_show (gestion_des_utilisateurs);
treeview_gestion_gu_nour=lookup_widget(objet_graphique,"treeview_gestion_gu_nour");
afficher_user(treeview_gestion_gu_nour);
}


void
on_radiobutton_homme_modifier_nour_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if  (gtk_toggle_button_get_active(togglebutton))
{g=1;}
}


void
on_radiobutton_femme_modifier_nour_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if  (gtk_toggle_button_get_active(togglebutton))
{g=1;}
}


void
on_button_retour_modifier_nour_clicked (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *w,*gestion_des_utilisateurs;
w=lookup_widget(objet_graphique,"modifier_user_nour");
gtk_widget_hide(w);
gestion_des_utilisateurs = create_gestion_des_utilisateurs();
  gtk_widget_show (gestion_des_utilisateurs);
}


void
on_button_modif_modifier_nour_clicked  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
user u;
GtkWidget *output ;
GtkWidget *msg;
GtkWidget *nom;
GtkWidget *prenom;
GtkWidget *identifiant;
GtkWidget *cin;
GtkWidget *num_tel;
GtkWidget *mdp;
GtkWidget *ville;
GtkWidget *vote;
GtkWidget *num_bv;
GtkWidget *combobox_role_modifier_nour;
int a,b,c;

GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;
combobox_role_modifier_nour=lookup_widget(objet_graphique,"combobox_role_modifier_nour");
if(strcmp("administrateur",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_role_modifier_nour)))==0)
 strcpy(u.role,"administrateur");
if(strcmp("agent de bureau de vote",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_role_modifier_nour)))==0)
 strcpy(u.role,"agent de bureau de vote");
if(strcmp("électeur",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_role_modifier_nour)))==0)
 strcpy(u.role,"électeur");
if(strcmp("observateur",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_role_modifier_nour)))==0)
 strcpy(u.role,"observateur");
nom=lookup_widget(objet_graphique,"entry_nom_nour_modifier");
prenom=lookup_widget(objet_graphique,"entry_prenom_nour_modifier");
identifiant=lookup_widget(objet_graphique,"entry_id_nour_modifier");
cin=lookup_widget(objet_graphique,"entry_cin_nour_modifier");
num_tel=lookup_widget(objet_graphique,"entry_num_tel_nour_modifier");
mdp=lookup_widget(objet_graphique,"entry_mdp_nour_modifier");
ville=lookup_widget(objet_graphique,"entry_ville_nour_modifier");
vote=lookup_widget(objet_graphique,"entry_vote_nour_modifier");
num_bv=lookup_widget(objet_graphique,"entry_bv_nour_modifier");
output=lookup_widget(objet_graphique,"label_msg_modifier_nour");
strcpy(u.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(u.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(u.pcx.identifiant,gtk_entry_get_text(GTK_ENTRY(identifiant)));
strcpy(u.cin,gtk_entry_get_text(GTK_ENTRY(cin)));

strcpy(u.pcx.mot_de_passe,gtk_entry_get_text(GTK_ENTRY(mdp)));
int m=atoi(gtk_entry_get_text(GTK_ENTRY(vote)));
int n=atoi(gtk_entry_get_text(GTK_ENTRY(num_bv)));
u.vote=m;
u.num_bv=n ;


if(g==1)
{
strcpy(u.genre,"homme");
}
if(g==2)
{
strcpy(u.genre,"femme");
}
char cin1 [20];
int j=modifier_user(u,cin1);
if (j==1)
gtk_label_set_text(GTK_LABEL(output),"modification avec succes");
else if (j==0)
gtk_label_set_text(GTK_LABEL(output),"echec de modification");


}


void
on_button_chercher_modifier_nour_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)

{
user u ;
GtkWidget *nom,*prenom,*identifiant,*cin,*num_tel,*mot_de_passe, *vote, *ville,*num_bv,*combobox_role_modifier_nour,*jour,*mois,*annee,*homme,*femme,*role,*genre,*msg;
nom = lookup_widget(objet_graphique,"entry_nom_modifier_nour");
prenom = lookup_widget(objet_graphique,"entry_prenom_modifier_nour");
num_tel = lookup_widget(objet_graphique,"entry_num_tel_modifier_nour");
mot_de_passe = lookup_widget(objet_graphique,"entry_mdp_modifier_nour");
ville = lookup_widget(objet_graphique,"entry_ville_modifier_nour");
vote = lookup_widget(objet_graphique,"entry_vote_modifier_nour");
num_bv = lookup_widget(objet_graphique,"entry_bv_modifier_nour");
identifiant = lookup_widget(objet_graphique,"entry_id_modifier_nour");
combobox_role_modifier_nour = lookup_widget(objet_graphique,"combobox_role_modifier_nour");
jour= lookup_widget(objet_graphique,"spinbutton_jour_modifier_nour");
mois= lookup_widget(objet_graphique,"spinbutton_mois_modifier_nour");
annee= lookup_widget(objet_graphique,"spinbutton_annee_modifier_nour");

homme= lookup_widget(objet_graphique,"radiobutton_homme_modifier_nour");
femme= lookup_widget(objet_graphique,"radiobutton_femme_modifier_nour");


 user k=chercher_user("user.txt", atoi(gtk_entry_get_text(GTK_ENTRY(cin))));

gtk_entry_set_text(GTK_ENTRY(nom),u.nom);
gtk_entry_set_text(GTK_ENTRY(prenom),u.prenom);
gtk_entry_set_text(GTK_ENTRY(identifiant),u.pcx.identifiant);
gtk_entry_set_text(GTK_ENTRY(mot_de_passe),u.pcx.mot_de_passe);
gtk_entry_set_text(GTK_ENTRY(vote),u.vote);

gtk_entry_set_text(GTK_ENTRY(ville),u.ville);
gtk_entry_set_text(GTK_ENTRY(num_tel),u.num_tel);
gtk_entry_set_text(GTK_ENTRY(num_bv),u.num_bv);
/*if(strcmp("administrateur",u.role)==0)
gtk_combo_box_set_active_text(GTK_COMBO_BOX(combobox_role_modifier_nour),0);
if(strcmp("agent de bureau de vote",u.role)==0)
gtk_combo_box_set_active_text(GTK_COMBO_BOX(combobox_role_modifier_nour),1);

if(strcmp("électeur",u.role)==0)
gtk_combo_box_set_active_text(GTK_COMBO_BOX(combobox_role_modifier_nour),2);

if(strcmp("observateur",u.role)
gtk_combo_box_set_active_text(GTK_COMBO_BOX(combobox_role_modifier_nour),3)*/

gtk_spin_button_set_value(jour,u.date.jour);
gtk_spin_button_set_value(mois,u.date.mois);
gtk_spin_button_set_value(annee,u.date.annee);

if (strcmp(u.genre,"homme")==0)
{
gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON (homme),TRUE);
}

else if (strcmp(u.genre,"femme")==0)
{
gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON (femme),TRUE);
}


msg = lookup_widget(objet_graphique,"abel_msg_modifier_nour");
gtk_label_set_text(GTK_LABEL(msg),"C'est bon");
}


void
on_treeview_gestion_gu_nour_row_activated
                                        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar *nom ;
gchar *prenom ;
gchar *cin;
gchar *identifiant;
gchar *genre ;
gchar *role ;
gint *jour ;
gint *mois ;
gint *annee ;
gint *vote ;
gint *num_bv ;
user u ;
GtkTreeModel *model= gtk_tree_view_get_model(treeview);
if (gtk_tree_model_get_iter(model,&iter,path))
{
gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&nom,1,&prenom,2,&identifiant,3,&cin,4,&genre,5,&role,6,&jour,7,&mois,8,&annee,9,&vote,10,&role,-1);
strcpy(u.nom,nom);
strcpy(u.prenom,prenom);
strcpy(u.cin,cin);
strcpy(u.pcx.identifiant,identifiant);
strcpy(u.genre,genre);
strcpy(u.role,role);
u.date.jour= *jour ;
u.date.mois= *mois ;
u.date.annee= *annee ;
u.vote= *vote;
u.num_bv= *num_bv ;
}
/*int s=ajouter_user("user.txt", u);
int v=modifier_user("user.txt", u,cin);
int l=supprimer_user("user.txt",cin);
user g=chercher_user("user.txt",identifiant);*/
/*afficher_user(treeview);*/
/*vider_user(liste);*/

}


void
on_button_ajouter_gu_nour_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *w,*ajout_nour;
w=lookup_widget(objet_graphique,"gestion_des_utilisateurs");
gtk_widget_hide(w);
ajout_nour= create_ajout_nour();
  gtk_widget_show (ajout_nour);
}


void
on_button_supp_gu_nour_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *w,*supprimer_nour;
w=lookup_widget(objet_graphique,"gestion_des_utilisateurs");
gtk_widget_hide(w);
supprimer_nour= create_supprimer_nour();
  gtk_widget_show (supprimer_nour);
}


void
on_button_chercher_gu_nour_clicked     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_retour_gu_nour_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *w,*menu;
w=lookup_widget(objet_graphique,"gestion_des_utilisateurs");
gtk_widget_hide(w);
menu = create_menu();
  gtk_widget_show (menu);
}


/*void
on_checkbutton_cin_nour_supp_clicked   (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
}*/
void
on_button_retour_nour_supp_clicked     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *w,*gestion_des_utilisateurs;
w=lookup_widget(objet_graphique,"supprimer_nour");
gtk_widget_hide(w);
gestion_des_utilisateurs= create_gestion_des_utilisateurs();
  gtk_widget_show (gestion_des_utilisateurs);
}


void
on_button_supprimer_nour_supp_clicked  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

GtkWidget *CIN , *output ;
CIN=lookup_widget(objet_graphique,"entry_cin_nour_supp");
char cin2[30];
user i=chercher_user("user.txt", cin2 ) ;
gtk_label_set_text(GTK_LABEL(output),"utilisateur supprimer avec succées");

}


void
on_button_user_nour_menu_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *w,*gestion_des_utilisateurs;
w=lookup_widget(objet_graphique,"menu");
gtk_widget_hide(w);
gestion_des_utilisateurs = create_gestion_des_utilisateurs();
  gtk_widget_show (gestion_des_utilisateurs);
}


void
on_button_stat_nour_menu_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *w,*stat_nour;
w=lookup_widget(objet_graphique,"menu");
gtk_widget_hide(w);
stat_nour= create_stat_nour();
  gtk_widget_show (stat_nour);
}


void
on_button_modifier_gu_nour_clicked     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *w,*modifier_user_nour;
w=lookup_widget(objet_graphique,"gestion_des_utilisateurs");
gtk_widget_hide(w);
modifier_user_nour= create_modifier_user_nour();
  gtk_widget_show (modifier_user_nour);
}


void
on_button_afficher_gu_nour_clicked     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *gestion_des_utilisateurs;
GtkWidget *treeview_gestion_gu_nour ;
gestion_des_utilisateurs=lookup_widget(objet_graphique,"gestion_des_utilisateurs");
treeview_gestion_gu_nour=lookup_widget(objet_graphique,"treeview_gestion_gu_nour");
afficher_user(treeview_gestion_gu_nour);
}


void
on_button_stat_nour_gu_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *w,*stat_nour;
w=lookup_widget(objet_graphique,"gestion_des_utilisateurs");
gtk_widget_hide(w);
stat_nour= create_stat_nour();
  gtk_widget_show (stat_nour);
}


void
on_button_tpe_nour_stat_clicked        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *w,*tpe,*output;
w=lookup_widget(objet_graphique,"stat_nour");
gtk_widget_hide(w);
tpe= create_tpe();
  gtk_widget_show (tpe);
float a ;
char str[50];
a=TPE("user.txt");
sprintf(str,"%f",a);
output= lookup_widget(objet_graphique,"label_msg_tpe_stat_nopur");
gtk_label_set_text(GTK_LABEL(output),str);
}


void
on_button_retour_tpe_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *w,*gestion_des_utilisateurs;
w=lookup_widget(objet_graphique,"tpe");
gtk_widget_hide(w);
gestion_des_utilisateurs= create_gestion_des_utilisateurs();
  gtk_widget_show (gestion_des_utilisateurs);
}


void
on_button_retour_tvb_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *w,*gestion_des_utilisateurs;
w=lookup_widget(objet_graphique,"tvb");
gtk_widget_hide(w);
gestion_des_utilisateurs= create_gestion_des_utilisateurs();
  gtk_widget_show (gestion_des_utilisateurs);
}


void
on_button_tvb_nour_stat_clicked        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *w,*tvb;
w=lookup_widget(objet_graphique,"stat_nour");
gtk_widget_hide(w);
tvb= create_tvb;
  gtk_widget_show (tvb);
float a ;
char str[50];
a=TVB("user.txt");
sprintf(str,"%f",a);
output= lookup_widget(objet_graphique,"label_msg_tvb");
gtk_label_set_text(GTK_LABEL(output),str);
}


void
on_checkbutton_cin_nour_supp_toggled   (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
A[0]=1;
}

