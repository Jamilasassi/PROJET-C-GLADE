#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "user.h"

#include <gtk/gtk.h>
/*enum
{
	nom ,
	prenom ,
	cin ,
	identifiant ,
	genre ,
	role ,
	jour ,
	mois ,
	annee ,
	vote ,
	num_bv ,
	COLUMNS
};*/
enum
{ 
	NOM,
	PRENOM,
	CIN,
	IDENTIFIANT,
	GENRE,
	ROLE,
	JOUR ,
	MOIS ,
	ANNEE ,
	VOTE ,
	NUM_BV ,
	COLUMNS
};
///ajout 
int ajouter_user(char * filename, user u)
{
FILE *f;
f=fopen(filename,"a+");
if (f!=NULL)
{
fprintf(f,"%s %s %s %s %d %d %d %s %s %s %s %s %d %d \n",u.cin,u.nom,u.prenom,u.genre,u.date.jour,u.date.mois,u.date.annee,u.pcx.identifiant,u.pcx.mot_de_passe,u.role,u.num_tel,u.ville,u.vote,u.num_bv);
fclose(f);
return 1 ;
}
else return 0 ;

}
///modif
int modifier_user( user nouv,char cin[])
{
    char *filename ;
    int tr=0;
    user u ;
    FILE * f=fopen(filename, "r");
    FILE * fich=fopen("nouv.txt", "w+");
    if(f!=NULL && fich!=NULL)
    {
        while(fscanf(f,"%s %s %s %s %d %d %d %s %s %s %s %s %d %d \n",u.cin,u.nom,u.prenom,u.genre,&u.date.jour,&u.date.mois,&u.date.annee,u.pcx.identifiant,u.pcx.mot_de_passe,u.role,u.num_tel,u.ville,&u.vote,&u.num_bv)!=EOF)
        {
            if(strcmp(cin,u.cin)==0)
            {
                fprintf(f,"%s %s %s %s %d %d %d %s %s %s %s %s %d %d \n",nouv.cin,nouv.nom,nouv.prenom,nouv.genre,nouv.date.jour,nouv.date.mois,nouv.date.annee,nouv.pcx.identifiant,nouv.pcx.mot_de_passe,nouv.role,nouv.num_tel,nouv.ville,nouv.vote,nouv.num_bv);
                tr=1;
            }
            else
                fprintf(fich,"%s %s %s %s %d %d %d %s %s %s %s %s %d %d \n",nouv.cin,nouv.nom,nouv.prenom,nouv.genre,nouv.date.jour,nouv.date.mois,nouv.date.annee,nouv.pcx.identifiant,nouv.pcx.mot_de_passe,nouv.role,nouv.num_tel,nouv.ville,nouv.vote,nouv.num_bv);

        }
    }
    fclose(f);
    fclose(fich);
    remove(filename);
    rename("nouv.txt", filename);
    return tr;

}
////supp
int supprimer_user(char*filename ,char cin[])
{
    int tr ;
    user u ;
             FILE * f=fopen(filename,"r");
             FILE * f2=fopen("temputil.txt","w");
             if(f!=NULL && f2!=NULL)
            {
               while ( fscanf(f,"%s %s %s %s %d %d %d %s %s %s %s %s %d %d \n",u.cin, u.nom, u.prenom, u.genre, &u.date.jour, &u.date.mois, &u.date.annee, u.pcx.identifiant, u.pcx.mot_de_passe, u.role, u.num_tel,u.ville,&u.vote,&u.num_bv)!=EOF)
             {
              if(strcmp(cin,u.cin)==0)
               {
                tr=1 ;
               }
              else
              fprintf(f2,"%s %s %s %s %d %d %d %s %s %s %s %s %d %d \n",u.cin, u.nom, u.prenom, u.genre, u.date.jour, u.date.mois, u.date.annee, u.pcx.identifiant,u.pcx.mot_de_passe,u.role,u.num_tel,u.ville,u.vote,u.num_bv);

             }
            }
            fclose(f);
            fclose(f2);
            remove(filename);
            rename("temputil.txt",filename);
            return tr ;

    }
////cherche
user chercher_user(char * filename, char cin[])
{
    user u;
    int tr;
    FILE * f3=fopen(filename, "r");
    if(f3!=NULL)
    {
        while((tr==0)&& (fscanf(f3,"%s %s %s %s %d %d %d %s %s %s %s %s %d %d \n",u.cin,u.nom,u.prenom,u.genre,&u.date.jour,&u.date.mois,&u.date.annee,u.pcx.identifiant,u.pcx.mot_de_passe,u.role,u.num_tel,u.ville,&u.vote,&u.num_bv)!=EOF))
        {
            if(strcmp(u.cin,cin)==0)
                tr=1;
        }
    }
    fclose(f3);
    return u;
}
/////affiche
void afficher_user(GtkWidget *liste )
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
user u ;
char nom[20] ;
char prenom[20] ;
char cin[20] ;
char identifiant[20] ;
char genre[30] ;
char role[100] ;
int jour ;
int mois ;
int annee ;
int vote ;
int num_bv ;
store=NULL;
FILE *f ;
store=GTK_LIST_STORE(gtk_tree_view_get_model(liste));
if(store==NULL)
{
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",NOM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	
	
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",PRENOM,NULL);
	gtk_tree_view_append_column(liste, column);
	

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("cin",renderer,"text",CIN,NULL);
	gtk_tree_view_append_column(liste, column);


	renderer=gtk_cell_renderer_text_new();	
	column=gtk_tree_view_column_new_with_attributes("identifiant",renderer,"text",IDENTIFIANT,NULL);
	gtk_tree_view_append_column(liste, column);
	

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("genre",renderer,"text",GENRE,NULL);
	gtk_tree_view_append_column(liste, column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("role",renderer,"text",ROLE,NULL);
	gtk_tree_view_append_column(liste, column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("jour",renderer,"text",JOUR,NULL);
	gtk_tree_view_append_column(liste, column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("mois",renderer,"text",MOIS,NULL);
	gtk_tree_view_append_column(liste, column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("annee",renderer,"text",ANNEE,NULL);
	gtk_tree_view_append_column(liste, column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("vote",renderer,"text",VOTE,NULL);
	gtk_tree_view_append_column(liste, column);
renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("num_bv",renderer,"text",NUM_BV,NULL);
	gtk_tree_view_append_column(liste, column);

store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING , G_TYPE_STRING  , G_TYPE_STRING , G_TYPE_INT ,G_TYPE_INT ,G_TYPE_INT ,G_TYPE_INT,G_TYPE_INT);
f=fopen("user.txt","r");
if(f==NULL)
{
return ;
}
else
{
f=fopen("user.txt","a+");
   while (fscanf(f,"%s %s %s %s %s %s %d %d %d %d %d \n", nom , prenom , cin , identifiant , genre , role , &jour, &mois, &annee , &vote, &num_bv)!=EOF)
    {
      gtk_list_store_append (store,&iter);
      gtk_list_store_set(store,&iter,NOM,nom,PRENOM,prenom,CIN,cin,IDENTIFIANT,identifiant,ROLE,role,JOUR,jour,MOIS,mois,ANNEE,annee,VOTE,vote,NUM_BV,num_bv,-1);
    
    }
  fclose(f) ;
gtk_tree_view_set_model(liste,GTK_TREE_MODEL(store));
g_object_unref(store);
}
}
}/*
#include"vote.h"
#include<stdio.h>
 enum
{
	EID,
	ECPE,
	ECPO,
	ESALLE,
	EID_AGENT,
	EADRSALLE,
	COLUMNS
};
 int ajouter(Vote v , char filename[])
{
 FILE* f=fopen(filename,"a+");
 if(f!=NULL)
 {
  fprintf(f,"%s %d %d %s %s %s\n",v.id,v.cpe,v.cpo,v.salle,v.id_agent,v.ADRsalle);
 fclose(f);
 return 1;
 }
 else return 0;
}
 
int modifier(char id[], Vote nouv, char * filename)
{
Vote v;
    FILE * f=fopen(filename, "r");
    FILE * f2 =fopen("aux.txt", "w");
    if(f==NULL || f2==NULL)
return 0;
else
    {
while(fscanf(f,"%s %d %d %s %s %s\n",v.id,&v.cpe,&v.cpo,v.salle,v.id_agent,v.ADRsalle)!=EOF)
{
if(strcmp(v.id,id)==0)
        
	fprintf(f2,"%s %d %d %s %s %s\n",nouv.id,nouv.cpe,nouv.cpo,nouv.salle,nouv.id_agent,nouv.ADRsalle);
else

  	fprintf(f2,"%s %d %d %s %s %s\n",v.id,v.cpe,v.cpo,v.salle,v.id_agent,v.ADRsalle);

}
        fclose(f);
        fclose(f2);
remove(filename);
rename("aux.txt", filename);
        return 1;
    }


  
}
int supprimer(char id[], char * filename)
{
Vote v;
int t=0;
    FILE * f=fopen(filename, "r");
    FILE * f2 =fopen("aux.txt", "a+");
    if(f==NULL || f2==NULL)
return 0;
else
    {
while(fscanf(f,"%s %d %d %s %s %s\n",v.id,&v.cpe,&v.cpo,v.salle,v.id_agent,v.ADRsalle)!=EOF)
{
if(strcmp(v.id,id)==0)
	t=1;
else
fprintf(f2,"%s %d %d %s %s %s\n",v.id,v.cpe,v.cpo,v.salle,v.id_agent,v.ADRsalle);
}
        fclose(f);
        fclose(f2);
remove(filename);
rename("aux.txt", filename);
if(t==1)
        return 1;
else
	return 0;
    }
}

Vote chercher(char id[], char * filename)
{
Vote v;
 int tr=0;
    FILE * f=fopen(filename, "r");
 if(f!=NULL )
    {
while(fscanf(f,"%s %d %d %s %s %s\n",v.id,&v.cpe,&v.cpo,v.salle,v.id_agent,v.ADRsalle)!=EOF && tr==0)
{if(strcmp(v.id,id)==0)
tr=1;
return v;
}
}
if(tr==0)
strcpy(v.id,"-1");
return v;

}
void afficher_vote(GtkTreeView *liste)
{
GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;
    GtkTreeIter iter ;
    GtkListStore *store;
Vote v;
    store=NULL;
    FILE *f;
    store=GTK_LIST_STORE(gtk_tree_view_get_model(liste));
    if(store==NULL){
        
        renderer=gtk_cell_renderer_text_new();
        column=gtk_tree_view_column_new_with_attributes("id",renderer,"text",EID,NULL);
        gtk_tree_view_append_column(liste,column);

        renderer=gtk_cell_renderer_text_new();
        column=gtk_tree_view_column_new_with_attributes("cpe",renderer,"text",ECPE,NULL);
        gtk_tree_view_append_column(liste,column);

        renderer=gtk_cell_renderer_text_new();
        column=gtk_tree_view_column_new_with_attributes("cpo",renderer,"text",ECPO,NULL);
        gtk_tree_view_append_column(liste,column); 

        renderer=gtk_cell_renderer_text_new();
        column=gtk_tree_view_column_new_with_attributes("salle",renderer,"text",ESALLE,NULL);
        gtk_tree_view_append_column(liste,column);
 
        renderer=gtk_cell_renderer_text_new();
        column=gtk_tree_view_column_new_with_attributes("ADRsalle",renderer,"text",EADRSALLE,NULL);
        gtk_tree_view_append_column(liste,column);

        renderer=gtk_cell_renderer_text_new();
        column=gtk_tree_view_column_new_with_attributes("id_agent",renderer,"text",EID_AGENT,NULL);
        gtk_tree_view_append_column(liste,column);

         
    }
          
    store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
    f=fopen("vote.txt","r");
    if(f==NULL){return;}
    else
    {
                 f=fopen("vote.txt","a+");
         while(fscanf(f,"%s %d %d %s %s %s\n",v.id,&v.cpe,&v.cpo,v.salle,v.id_agent,v.ADRsalle)!=EOF)
         {
            gtk_list_store_append(store,&iter);
            gtk_list_store_set(store,&iter,0,v.id,1,v.cpe,2,v.cpo,3,v.salle,4,v.ADRsalle,5,v.id_agent,-1);
         }
     fclose(f);
     gtk_tree_view_set_model(liste,GTK_TREE_MODEL(store));
     g_object_unref(store);
    }

}*/
//////vider
/*void vider_user(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
user u ;
char nom[20] ;
char prenom[20] ;
char cin[20] ;
char identifiant[20] ;
char genre[30] ;
char role[100] ;
int jour ;
int mois ;
int annee ;
int vote ;
int num_bv ;
store=NULL ;
FILE *f6 ;
store=gtk_tree_view_get_model(liste);
if(store==NULL)
{
renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",NOM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	
	
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",PRENOM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("cin",renderer,"text",CIN,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	


	renderer=gtk_cell_renderer_text_new();	
	column=gtk_tree_view_column_new_with_attributes("identifiant",renderer,"text",IDENTIFIANT,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("genre",renderer,"text",GENRE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("role",renderer,"text",ROLE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("jour",renderer,"text",JOUR,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("mois",renderer,"text",MOIS,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("annee",renderer,"text",ANNEE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("vote",renderer,"text",VOTE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("num_bv",renderer,"text",NUM_BV,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);



}
store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING , G_TYPE_STRING  , G_TYPE_STRING , G_TYPE_INT , G_TYPE_INT , G_TYPE_INT , G_TYPE_INT, G_TYPE_INT);
gtk_list_store_append(store ,&iter);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
}*/
int verif_nour (char identifiant[] , char mot_de_passe[])
{
int trouve=-1;
FILE *f=NULL;
user u  ;
f=fopen("user.txt","r");
if(f!=NULL)
{
while (fscanf(f,"%s %s %s %s %d %d %d %s %s %s %s %s %d %d \n",u.cin,u.nom,u.prenom,u.genre,&u.date.jour,&u.date.mois,&u.date.annee,u.pcx.identifiant,u.pcx.mot_de_passe,u.role,u.num_tel,u.ville,&u.vote,&u.num_bv)!=EOF)
{
if ((strcmp(u.pcx.identifiant,identifiant)==0) && (strcmp(u.pcx.mot_de_passe,mot_de_passe)==0))
trouve=1;
}
fclose(f);
}
return trouve;
}
float TVB(char  *filename)
{
    user u ;
    float nb ,nbvb ;
    float taux_vb ;
nb=0;
nbvb=0;
FILE* F=fopen(filename, "r");
     while(fscanf(F,"%s %s %s %s %d %d %d %s %s %s %s %s %d %d \n",u.cin,u.nom,u.prenom,u.genre,&u.date.jour,&u.date.mois,&u.date.annee,u.pcx.identifiant,u.pcx.mot_de_passe,u.num_tel,u.ville,u.role,&u.vote,&u.num_bv)!=EOF)
     {
         if (strcmp(u.role,"electeur")==0)
         {
             nb++;
             if (u.vote==0)
                nbvb++;
             }
     }
  taux_vb=nbvb/nb ;
  return taux_vb ;
}
float TPE(char *filename)
{     user u ;
      float nb ,nbv ;
      float taux ;
      nb=0;
      nbv=0;
        FILE* f=fopen(filename, "r");
 while(fscanf(f,"%s %s %s %s %d %d %d %s %s %s %s %s %d %d \n",u.cin,u.nom,u.prenom,u.genre,&u.date.jour,&u.date.mois,&u.date.annee,u.pcx.identifiant,u.pcx.mot_de_passe,u.num_tel,u.ville,u.role,&u.vote,&u.num_bv)!=EOF)

    {
        if (strcmp(u.role,"electeur")==0)
        {
            nb++;
            if (u.vote!=-1)
                nbv++;
        }

    }

    taux=nbv/nb ;
    return taux ;
}


