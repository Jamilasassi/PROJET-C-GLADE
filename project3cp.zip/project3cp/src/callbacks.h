#include <gtk/gtk.h>


void
on_button_inscrit_nour_authen_clicked  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_cnx_nour_authen_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_radiobutton_homme_nour_ajout_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_femme_nour_ajout_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_retour_nour_ajout_clicked    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_ajouter_nour_ajout_clicked   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_affiche_nour_ajout_clicked   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_radiobutton_homme_modifier_nour_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_femme_modifier_nour_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_retour_modifier_nour_clicked (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_modif_modifier_nour_clicked  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_chercher_modifier_nour_clicked
                                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_treeview_gestion_gu_nour_row_activated
                                        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_ajouter_gu_nour_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_supp_gu_nour_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_chercher_gu_nour_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_retour_gu_nour_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_checkbutton_cin_nour_supp_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_retour_nour_supp_clicked     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_supprimer_nour_supp_clicked  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_user_nour_menu_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_stat_nour_menu_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_modifier_gu_nour_clicked     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_afficher_gu_nour_clicked     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_stat_nour_gu_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_tpe_nour_stat_clicked        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_retour_tpe_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_retour_tvb_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_tvb_nour_stat_clicked        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_checkbutton_cin_nour_supp_toggled   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);
