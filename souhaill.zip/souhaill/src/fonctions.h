#ifndef FONCTIONS_H_INCLUDED
#define FONCTIONS_H_INCLUDED

#include <gtk/gtk.h>
typedef struct date_de_naissance {
int jour ;
int mois ;
int annee ;
}ddn ;
typedef struct parametres_de_connexion {
char login[20] ;
char mdp[20] ;
}pdc;


typedef struct utilisateur
{ char cin[20] ;
  char nom[20] ;
  char prenom[20] ;
  char genre[30] ;
  ddn DDN ;
  pdc conx ;
  char role[100] ;

  int vote ;
  int numbv ;

        }utilisateur ;
int ajouter_utilisateur(char * filename, utilisateur u);


int modifier_utilisateur(char * filename ,utilisateur u,char cin[]) ;
int supprimer_utilisateur(char * filename ,char cin[]) ;
utilisateur chercher_utilisateur(char * filename ,char cin[]) ;
int verif_souhail (char log[] , char pw[]) ;
void afficher_utilisateur(GtkWidget *liste) ;
int recherche(char cin[]);
utilisateur chercher_utilisateur_souhail(char * filename, char log[],char mdp[]);
void afficher_electeur(GtkWidget *liste);
void afficher_agent(GtkWidget *liste);
void afficher_observateur(GtkWidget *liste) ;
void afficher_administrateur(GtkWidget *liste)  ;
float TPE(char *filename);
float TVB(char  *filename) ;
int verifier_existant (char cin[]) ;


#endif
