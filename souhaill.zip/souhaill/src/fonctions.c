#include <stdio.h>
#include <string.h>
#include"fonctions.h"
#include <gtk/gtk.h>


enum
{
	ECIN,
	ENOM,
	EPRENOM,
	EROLE,
	EGENRE,
	EJOUR,
        EMOIS,
        EANNEE,
        EVOTE,
        ENUMBV,
	COLUMNSS
};

//--------------------------------*ajouter_souhail*--------------------------------------------//
int ajouter_utilisateur(char * filename, utilisateur u)
{
FILE *f;
f=fopen(filename,"a+");
if (f!=NULL)
{
fprintf(f,"%s %s %s %s %d %d %d %s %s %s %d %d\n",u.cin,u.nom,u.prenom,u.genre,u.DDN.jour,u.DDN.mois,u.DDN.annee,u.conx.login,u.conx.mdp,u.role,u.vote,u.numbv);
fclose(f);
return 1 ;
}
else return 0 ;

}



//--------------------------------*modifier_souhail*--------------------------------------------//

    int modifier_utilisateur( char * filename,utilisateur nvu,char cin[])
{
    int tr=0;
    utilisateur u;
    FILE * f=fopen(filename, "r");
    FILE * f2=fopen("nouv.txt", "w");
    if(f!=NULL && f2!=NULL)
    {
        while(fscanf(f,"%s %s %s %s %d %d %d %s %s %s %d %d\n",u.cin,u.nom,u.prenom,u.genre,&u.DDN.jour,&u.DDN.mois,&u.DDN.annee,u.conx.login,u.conx.mdp,u.role,&u.vote,&u.numbv)!=EOF)
        {
            if(strcmp(cin,u.cin)==0)
            {
                fprintf(f2,"%s %s %s %s %d %d %d %s %s %s %d %d\n",nvu.cin,nvu.nom,nvu.prenom,nvu.genre,nvu.DDN.jour,nvu.DDN.mois,nvu.DDN.annee,nvu.conx.login,nvu.conx.mdp,nvu.role,nvu.vote,nvu.numbv);
                tr=1;
            }
            else
                fprintf(f2,"%s %s %s %s %d %d %d %s %s %s %d %d\n",u.cin,u.nom,u.prenom,u.genre,u.DDN.jour,u.DDN.mois,u.DDN.annee,u.conx.login,u.conx.mdp,u.role,u.vote,u.numbv);

        }
    }
    fclose(f);
    fclose(f2);
    remove(filename);
    rename("nouv.txt", filename);
    return tr;

}


//--------------------------------*supprimer_souhail*--------------------------------------------//
int supprimer_utilisateur(char * filename ,char cin[])
{



 FILE*F,*Fich;
    int tr=0 ;
    utilisateur u ;
             F=fopen(filename,"r");
            Fich=fopen("temputil.txt","w");
            do
            {
                fscanf(F,"%s %s %s %s %d %d %d %s %s %s %d %d\n",u.cin,u.nom,u.prenom,u.genre,&u.DDN.jour,&u.DDN.mois,&u.DDN.annee,u.conx.login,u.conx.mdp,u.role,&u.vote,&u.numbv);
            if(strcmp(cin,u.cin)==0)
            {
               tr=1 ;
            }
else
    fprintf(Fich,"%s %s %s %s %d %d %d %s %s %s %d %d\n",u.cin,u.nom,u.prenom,u.genre,u.DDN.jour,u.DDN.mois,u.DDN.annee,u.conx.login,u.conx.mdp,u.role,u.vote,u.numbv);

            }while(!feof(F));
            fclose(F);
            fclose(Fich);
            remove(filename);
            rename("temputil.txt",filename);
            return tr ;

    }

//--------------------------------*chercher_souhail*--------------------------------------------//

utilisateur chercher_utilisateur(char * filename, char cin[])
{
    utilisateur u;

    int tr=0;
    FILE * f=fopen(filename, "r");
    if(f!=NULL)
    {
        while((tr==0&& fscanf(f,"%s %s %s %s %d %d %d %s %s %s %d %d\n",u.cin,u.nom,u.prenom,u.genre,&u.DDN.jour,&u.DDN.mois,&u.DDN.annee,u.conx.login,u.conx.mdp,u.role,&u.vote,&u.numbv)!=EOF))
        {
            if(strcmp(u.cin,cin)==0)
                tr=1;
        }
    }
    fclose(f);
if(tr==0)
{strcpy(u.cin,"introuvable");
}

    return u;
}


//--------------------------------*verif_souhail*--------------------------------------------//


int verif_souhail (char log[] , char pw[])
{
int trouve=0;
FILE *f=NULL;
utilisateur u  ;
f=fopen("utilisateur.txt","r");
if(f!=NULL)
{
while (fscanf(f,"%s%s%s%s%d%d%d%s%s%s%d%d\n",u.cin,u.nom,u.prenom,u.genre,&u.DDN.jour,&u.DDN.mois,&u.DDN.annee,u.conx.login,u.conx.mdp,u.role,&u.vote,&u.numbv)!=EOF)
{
if ((strcmp(u.conx.login,log)==0) && (strcmp(u.conx.mdp,pw)==0))
{trouve=1;}
}
fclose(f);
}
return trouve;
}

//--------------------------------*afficher_utilisateur_souhail*--------------------------------------------//


void afficher_utilisateur(GtkWidget *liste)
{

char cin[30];
char nom[20];
char prenom[20];
char role[50];
ddn DDN ;
char genre[30] ;
int vote ;
int numbv ;
 pdc conx ;


	GtkCellRenderer *renderer;
       GtkTreeViewColumn *column;
       GtkTreeIter iter;	
       GtkListStore *store;
store=NULL;

FILE *f;
store=gtk_tree_view_get_model(liste);

if (store==NULL)
{
renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes(" cin", renderer, "text",ECIN, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes(" nom", renderer, "text",ENOM, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes(" prenom", renderer, "text",EPRENOM, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes(" role", renderer, "text",EROLE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes(" genre", renderer, "text",EGENRE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new() ;
column = gtk_tree_view_column_new_with_attributes(" jour",renderer, "text",EJOUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes(" mois",renderer, "text",EMOIS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes(" annee",renderer, "text",EANNEE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes(" vote",renderer, "text",EVOTE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes(" numbv",renderer, "text",ENUMBV,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);




}
store=gtk_list_store_new (COLUMNSS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT);

f=fopen("utilisateur.txt","r");
if(f==NULL)
{
	return;
}
else
{
f=fopen("utilisateur.txt","a+");
while(fscanf(f,"%s %s %s %s %d %d %d %s %s %s %d %d\n",cin,nom,prenom,genre,&DDN.jour,&DDN.mois,&DDN.annee,conx.login,conx.mdp,role,&vote,&numbv)!=EOF)
{
gtk_list_store_append (store, &iter);
gtk_list_store_set (store, &iter, ECIN, cin, ENOM, nom, EPRENOM, prenom, EROLE, role, EGENRE, genre, EJOUR, DDN.jour, EMOIS, DDN.mois, EANNEE, DDN.annee, EVOTE, vote, ENUMBV, numbv, -1);
}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}
}

//--------------------------------*recherche_souhail*--------------------------------------------//
int recherche(char cin[])
{
int x=0;
utilisateur u;
FILE* F;
F=fopen("utilisateur.txt","r");
 do
            {
                fscanf(F,"%s %s %s %s %d %d %d %s %s %s %d %d\n",u.cin,u.nom,u.prenom,u.genre,&u.DDN.jour,&u.DDN.mois,&u.DDN.annee,u.conx.login,u.conx.mdp,u.role,&u.vote,&u.numbv);

	if(strcmp(u.cin,cin)==0)
	{
		x=1;
		}


            }while(!feof(F));

fclose(F);
return x;}


//--------------------------------*chercher_utilisateur_souhail*--------------------------------------------//
utilisateur chercher_utilisateur_souhail(char * filename, char log[],char mdp[])
{
    utilisateur u;

   int tr=0 ; 
    FILE * f=fopen(filename, "r");
    if(f!=NULL)
    {
        while((tr==0&& fscanf(f,"%s %s %s %s %d %d %d %s %s %s %d %d\n",u.cin,u.nom,u.prenom,u.genre,&u.DDN.jour,&u.DDN.mois,&u.DDN.annee,u.conx.login,u.conx.mdp,u.role,&u.vote,&u.numbv)!=EOF))
        {
            if((strcmp(u.conx.login,log)==0) && (strcmp(u.conx.mdp,mdp)==0))
                tr=1;
        }
    }
    fclose(f);
if(tr==0)
{strcpy(u.cin,"introuvable");
}

    return u;
}

//---------------------------------------*afficher_electeur*------------------------------//
void afficher_electeur(GtkWidget *liste)
{

char cin[30];
char nom[20];
char prenom[20];
char role[50];
ddn DDN ;
char genre[30] ;
int vote ;
int numbv ;
 pdc conx ;


	GtkCellRenderer *renderer;
       GtkTreeViewColumn *column;
       GtkTreeIter iter;	
       GtkListStore *store;
store=NULL;

FILE *f;
store=gtk_tree_view_get_model(liste);

if (store==NULL)
{
renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes(" cin", renderer, "text",ECIN, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes(" nom", renderer, "text",ENOM, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes(" prenom", renderer, "text",EPRENOM, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes(" role", renderer, "text",EROLE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes(" genre", renderer, "text",EGENRE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new() ;
column = gtk_tree_view_column_new_with_attributes(" jour",renderer, "text",EJOUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes(" mois",renderer, "text",EMOIS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes(" annee",renderer, "text",EANNEE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes(" vote",renderer, "text",EVOTE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes(" numbv",renderer, "text",ENUMBV,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);




}
store=gtk_list_store_new (COLUMNSS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT);

f=fopen("electeur.txt","r");
if(f==NULL)
{
	return;
}
else
{
f=fopen("electeur.txt","a+");
while(fscanf(f,"%s %s %s %s %d %d %d %s %s %s %d %d\n",cin,nom,prenom,genre,&DDN.jour,&DDN.mois,&DDN.annee,conx.login,conx.mdp,role,&vote,&numbv)!=EOF)
{
gtk_list_store_append (store, &iter);
gtk_list_store_set (store, &iter, ECIN, cin, ENOM, nom, EPRENOM, prenom, EROLE, role, EGENRE, genre, EJOUR, DDN.jour, EMOIS, DDN.mois, EANNEE, DDN.annee, EVOTE, vote, ENUMBV, numbv, -1);
}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}
}
//---------------------------------------*afficher_administrateur*------------------------------//
void afficher_administrateur(GtkWidget *liste)
{

char cin[30];
char nom[20];
char prenom[20];
char role[50];
ddn DDN ;
char genre[30] ;
int vote ;
int numbv ;
 pdc conx ;


	GtkCellRenderer *renderer;
       GtkTreeViewColumn *column;
       GtkTreeIter iter;	
       GtkListStore *store;
store=NULL;

FILE *f;
store=gtk_tree_view_get_model(liste);

if (store==NULL)
{
renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes(" cin", renderer, "text",ECIN, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes(" nom", renderer, "text",ENOM, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes(" prenom", renderer, "text",EPRENOM, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes(" role", renderer, "text",EROLE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes(" genre", renderer, "text",EGENRE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new() ;
column = gtk_tree_view_column_new_with_attributes(" jour",renderer, "text",EJOUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes(" mois",renderer, "text",EMOIS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes(" annee",renderer, "text",EANNEE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes(" vote",renderer, "text",EVOTE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes(" numbv",renderer, "text",ENUMBV,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);




}
store=gtk_list_store_new (COLUMNSS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT);

f=fopen("admin.txt","r");
if(f==NULL)
{
	return;
}
else
{
f=fopen("admin.txt","a+");
while(fscanf(f,"%s %s %s %s %d %d %d %s %s %s %d %d\n",cin,nom,prenom,genre,&DDN.jour,&DDN.mois,&DDN.annee,conx.login,conx.mdp,role,&vote,&numbv)!=EOF)
{
gtk_list_store_append (store, &iter);
gtk_list_store_set (store, &iter, ECIN, cin, ENOM, nom, EPRENOM, prenom, EROLE, role, EGENRE, genre, EJOUR, DDN.jour, EMOIS, DDN.mois, EANNEE, DDN.annee, EVOTE, vote, ENUMBV, numbv, -1);
}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}
}
//---------------------------------------*afficher_observateur*------------------------------//
void afficher_observateur(GtkWidget *liste)
{

char cin[30];
char nom[20];
char prenom[20];
char role[50];
ddn DDN ;
char genre[30] ;
int vote ;
int numbv ;
 pdc conx ;


	GtkCellRenderer *renderer;
       GtkTreeViewColumn *column;
       GtkTreeIter iter;	
       GtkListStore *store;
store=NULL;

FILE *f;
store=gtk_tree_view_get_model(liste);

if (store==NULL)
{
renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes(" cin", renderer, "text",ECIN, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes(" nom", renderer, "text",ENOM, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes(" prenom", renderer, "text",EPRENOM, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes(" role", renderer, "text",EROLE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes(" genre", renderer, "text",EGENRE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new() ;
column = gtk_tree_view_column_new_with_attributes(" jour",renderer, "text",EJOUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes(" mois",renderer, "text",EMOIS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes(" annee",renderer, "text",EANNEE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes(" vote",renderer, "text",EVOTE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes(" numbv",renderer, "text",ENUMBV,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);




}
store=gtk_list_store_new (COLUMNSS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT);

f=fopen("observateur.txt","r");
if(f==NULL)
{
	return;
}
else
{
f=fopen("observateur.txt","a+");
while(fscanf(f,"%s %s %s %s %d %d %d %s %s %s %d %d\n",cin,nom,prenom,genre,&DDN.jour,&DDN.mois,&DDN.annee,conx.login,conx.mdp,role,&vote,&numbv)!=EOF)
{
gtk_list_store_append (store, &iter);
gtk_list_store_set (store, &iter, ECIN, cin, ENOM, nom, EPRENOM, prenom, EROLE, role, EGENRE, genre, EJOUR, DDN.jour, EMOIS, DDN.mois, EANNEE, DDN.annee, EVOTE, vote, ENUMBV, numbv, -1);
}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}
}
//---------------------------------------*afficher_agent*------------------------------//
void afficher_agent(GtkWidget *liste)
{

char cin[30];
char nom[20];
char prenom[20];
char role[50];
ddn DDN ;
char genre[30] ;
int vote ;
int numbv ;
 pdc conx ;


	GtkCellRenderer *renderer;
       GtkTreeViewColumn *column;
       GtkTreeIter iter;	
       GtkListStore *store;
store=NULL;

FILE *f;
store=gtk_tree_view_get_model(liste);

if (store==NULL)
{
renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes(" cin", renderer, "text",ECIN, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes(" nom", renderer, "text",ENOM, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes(" prenom", renderer, "text",EPRENOM, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes(" role", renderer, "text",EROLE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes(" genre", renderer, "text",EGENRE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new() ;
column = gtk_tree_view_column_new_with_attributes(" jour",renderer, "text",EJOUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes(" mois",renderer, "text",EMOIS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes(" annee",renderer, "text",EANNEE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes(" vote",renderer, "text",EVOTE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes(" numbv",renderer, "text",ENUMBV,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);




}
store=gtk_list_store_new (COLUMNSS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT);

f=fopen("agent.txt","r");
if(f==NULL)
{
	return;
}
else
{
f=fopen("agent.txt","a+");
while(fscanf(f,"%s %s %s %s %d %d %d %s %s %s %d %d\n",cin,nom,prenom,genre,&DDN.jour,&DDN.mois,&DDN.annee,conx.login,conx.mdp,role,&vote,&numbv)!=EOF)
{
gtk_list_store_append (store, &iter);
gtk_list_store_set (store, &iter, ECIN, cin, ENOM, nom, EPRENOM, prenom, EROLE, role, EGENRE, genre, EJOUR, DDN.jour, EMOIS, DDN.mois, EANNEE, DDN.annee, EVOTE, vote, ENUMBV, numbv, -1);
}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}
}


////-----------------------------*stat souhail*-----------------------------------------////
float TVB(char  *filename)
{
    utilisateur u ;
    float nb ,nbvb ;
    float taux_vb ;
nb=0;
nbvb=0;
FILE* F=fopen(filename, "r");
     while(fscanf(F,"%s %s %s %s %d %d %d %s %s %s %d %d\n",u.cin,u.nom,u.prenom,u.genre,&u.DDN.jour,&u.DDN.mois,&u.DDN.annee,u.conx.login,u.conx.mdp,u.role,&u.vote,&u.numbv)!=EOF)
     {
         if (strcmp(u.role,"Electeur")==0)
         {
             nb++;
             if (u.vote==0)
                nbvb++;
             }
     }
  taux_vb=nbvb/nb ;
  return taux_vb ;
}



float TPE(char *filename)
{    utilisateur u ;
      float nb ,nbv ;
      float taux ;
      nb=0;
      nbv=0;
        FILE* f=fopen(filename, "r");
 while(fscanf(f,"%s %s %s %s %d %d %d %s %s %s %d %d\n",u.cin,u.nom,u.prenom,u.genre,&u.DDN.jour,&u.DDN.mois,&u.DDN.annee,u.conx.login,u.conx.mdp,u.role,&u.vote,&u.numbv)!=EOF)

    {
        if (strcmp(u.role,"Electeur")==0)
        {
            nb++;
            if (u.vote!=-1)
                nbv++;
        }

    }

    taux=nbv/nb ;
    return taux ;
}



//--------------------------------------------*verifier_existant*---------------------------------//



int verifier_existant (char cin[])
{
  int verif =-1;
  utilisateur tableau[100];
utilisateur u ;
  FILE *f;

  int nbline=0, i;

  f= fopen("utilisateur.txt","r");

  if (f != NULL)
    {
      while (fscanf(f,"%s %s %s %s %d %d %d %s %s %s %d %d\n",u.cin,u.nom,u.prenom,u.genre,&u.DDN.jour,&u.DDN.mois,&u.DDN.annee,u.conx.login,u.conx.mdp,u.role,&u.vote,&u.numbv) != EOF)
      {
        
        strcpy(tableau[nbline].cin ,u.cin);
        nbline ++;
      }
      fclose(f);
    }
  for (i =0; i<nbline; i++)
    {
      if (strcmp(cin, tableau[i].cin) == 0)
        {
          verif = 0; //Existant
          break;
        }
      else
      {
        verif =1; //inéxistant
      }
    }
  return verif;
}
