#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"

#include"fonctions.h"
int z=1;
int x=1; 
int y=0;
void
on_button_gestion_des_utilisateurs_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data)
{GtkWidget *w,*fenetre1 ;
GtkWidget *treeview1 ;
w=lookup_widget(objet,"espace_adminstrateur");
gtk_widget_hide(w);


fenetre1 = create_fenetre1 ();
  gtk_widget_show (fenetre1);

treeview1=lookup_widget(fenetre1,"treeview1");
afficher_utilisateur(treeview1);


}


void
on_comboboxentry10_changed             (GtkComboBox     *combobox,
                                        gpointer         user_data)
{

}


void
on_button_ajouter_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *w,*ajouter_un_utilisateur;
w=lookup_widget(objet,"fenetre1");
gtk_widget_hide(w);
 ajouter_un_utilisateur = create_ajouter_un_utilisateur ();
  gtk_widget_show (ajouter_un_utilisateur);
}


void
on_button_modifier_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *w,*modifier_un_utilisateur;
w=lookup_widget(objet,"fenetre1");
gtk_widget_hide(w);
 modifier_un_utilisateur = create_modifier_un_utilisateur ();
  gtk_widget_show (modifier_un_utilisateur);
}


void
on_button_supprimer_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *w,*supprimer_un_utilisateur;
w=lookup_widget(objet,"fenetre1");
gtk_widget_hide(w);
supprimer_un_utilisateur = create_supprimer_un_utilisateur ();
  gtk_widget_show (supprimer_un_utilisateur);
}


void
on_button_retour_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *w,*espace_adminstrateur;
w=lookup_widget(objet,"fenetre1");
gtk_widget_hide(w);
espace_adminstrateur = create_espace_adminstrateur ();
  gtk_widget_show (espace_adminstrateur);

}


void
on_button_retourner_ajout_clicked      (GtkWidget       *objet,
                                        gpointer         user_data)
{GtkWidget *w,*fenetre1 ;
GtkWidget *treeview1 ;
w=lookup_widget(objet,"ajouter_un_utilisateur");
gtk_widget_hide(w);
fenetre1 = create_fenetre1 ();
  gtk_widget_show (fenetre1);
treeview1=lookup_widget(fenetre1,"treeview1");
afficher_utilisateur(treeview1);
}


void
on_button_retourner_modifier_clicked   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *w,*fenetre1;
GtkWidget *treeview1 ; 

w=lookup_widget(objet,"modifier_un_utilisateur");
gtk_widget_hide(w);
fenetre1 = create_fenetre1 ();
  gtk_widget_show (fenetre1);
treeview1=lookup_widget(fenetre1,"treeview1");
afficher_utilisateur(treeview1);
}


void
on_button_retourner_supprimer_clicked  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *w,*fenetre1;
GtkWidget *treeview1 ; 

w=lookup_widget(objet,"supprimer_un_utilisateur");
gtk_widget_hide(w);
fenetre1 = create_fenetre1 ();
  gtk_widget_show (fenetre1);
treeview1=lookup_widget(fenetre1,"treeview1");
afficher_utilisateur(treeview1);
}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar* nom;
gchar* prenom;
gchar* jour;
gchar* mois;
gchar* annee;
gchar* genre;
gchar* cin;
gchar* role;
gchar* vote;
gchar* numbv;
utilisateur u,u2 ;

GtkTreeModel *model = gtk_tree_view_get_model(treeview);

if (gtk_tree_model_get_iter(model, &iter ,path))
{
gtk_tree_model_get (GTK_LIST_STORE(model) , &iter, 0,&cin,1,&nom,2,&prenom,3,&role,4,&genre,5,&jour,6,&mois,7,&annee,8,vote,9,numbv, -1);


int x =supprimer_utilisateur("utilisateur.txt",cin);
afficher_utilisateur(treeview);
}

}

void
on_radiobutton_homme_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if  (gtk_toggle_button_get_active(togglebutton))
{x=1;}
}


void
on_radiobutton_femme_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if  (gtk_toggle_button_get_active(togglebutton))
{x=2;}
}


void
on_button_ajouter1_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{int i,b,c;


GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;



utilisateur u;
GtkWidget *cin ,*nom ,*prenom,*login,*mdp,*vote,*numbv,*popup;
GtkWidget *combobox1 ;




cin=lookup_widget(objet,"cin_ajouter");
nom=lookup_widget(objet,"nom_ajouter");
prenom=lookup_widget(objet,"prenom_ajouter");
login=lookup_widget(objet,"login_ajouter");
mdp=lookup_widget(objet,"mdp_ajouter");
vote=lookup_widget(objet,"vote_ajouter");
numbv=lookup_widget(objet,"numbv_ajouter");

strcpy(u.cin,gtk_entry_get_text(GTK_ENTRY(cin)));
strcpy(u.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(u.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));

strcpy(u.conx.login,gtk_entry_get_text(GTK_ENTRY(login)));
strcpy(u.conx.mdp,gtk_entry_get_text(GTK_ENTRY(mdp)));
int f=atoi(gtk_entry_get_text(GTK_ENTRY(vote)));
int m=atoi(gtk_entry_get_text(GTK_ENTRY(numbv)));
u.vote=f;
u.numbv=m ;


if(x==1)
{
strcpy(u.genre,"Homme");
}
if(x==2)
{
strcpy(u.genre,"Femme");
}

jour=lookup_widget(objet, "spinbutton10");
mois=lookup_widget(objet, "spinbutton20");
annee=lookup_widget(objet, "spinbutton30");

i=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
b=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
c=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));

u.DDN.jour=i ;
u.DDN.mois=b ;
u.DDN.annee=c ;
combobox1=lookup_widget(objet, "combobox1");
strcpy(u.role,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));

  if (verifier_existant(u.cin) != 0)
{
GtkWidget *w,*fenetre1,*ok ;
GtkWidget *treeview1 ;
w=lookup_widget(objet,"ajouter_un_utilisateur");
gtk_widget_hide(w);
ok=create_ajout_succes ();
  gtk_widget_show (ok);
fenetre1 = create_fenetre1 ();
  gtk_widget_show (fenetre1);
  
treeview1=lookup_widget(fenetre1,"treeview1");
afficher_utilisateur(treeview1);

int k=ajouter_utilisateur("utilisateur.txt", u) ;}
else
  { popup=lookup_widget(objet,"label123456");
    gtk_label_set_text(GTK_LABEL(popup), "Erreur ajout (cin déja existe)");
  }






}








void
on_checkbutton_supprimer_utilisateur_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{if  (gtk_toggle_button_get_active(togglebutton))
{y=1;}

}


void
on_button_supprimer2_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{ GtkWidget *w ;
GtkWidget *output ;
char cin[30];
w=lookup_widget(objet,"cin_supp");
strcpy(cin,gtk_entry_get_text(GTK_ENTRY(w)));
output=lookup_widget(objet,"output_sup");
if(y==1)

{
int ml= supprimer_utilisateur("utilisateur.txt",cin) ;
  if (ml==1) 
   { gtk_label_set_text(GTK_LABEL(output),"utilisateur supprimer avec succes");} 
  else 
      {gtk_label_set_text(GTK_LABEL(output),"utilisateur n'est pas trouve");}

   }
else 
{gtk_label_set_text(GTK_LABEL(output),"confirmer pour supprimer") ; }
}


/*
void
on_femme_modifier_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}
*/

void
on_button_modifier1_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{int i,b,c;


GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;



utilisateur u;
GtkWidget *cin ,*nom ,*prenom,*login,*mdp,*vote,*numbv;
GtkWidget *combobox1,*output22 ;


output22=cin=lookup_widget(objet,"output500");

cin=lookup_widget(objet,"cin_modifier");
nom=lookup_widget(objet,"nom_modifier");
prenom=lookup_widget(objet,"prenom_modifier");
login=lookup_widget(objet,"login_modifier");
mdp=lookup_widget(objet,"mdp_modifier");
vote=lookup_widget(objet,"vote_modifier");
numbv=lookup_widget(objet,"numbv_modifier");
strcpy(u.cin,gtk_entry_get_text(GTK_ENTRY(cin)));
strcpy(u.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(u.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));

strcpy(u.conx.login,gtk_entry_get_text(GTK_ENTRY(login)));
strcpy(u.conx.mdp,gtk_entry_get_text(GTK_ENTRY(mdp)));
int f=atoi(gtk_entry_get_text(GTK_ENTRY(vote)));
int m=atoi(gtk_entry_get_text(GTK_ENTRY(numbv)));
u.vote=f;
u.numbv=m ;


if(z==1)
{
strcpy(u.genre,"Homme");
}
if(z==2)
{
strcpy(u.genre,"Femme");
}

jour=lookup_widget(objet, "spinbutton_jour01");
mois=lookup_widget(objet, "spinbutton_mois02");
annee=lookup_widget(objet, "spinbutton_annee02");

i=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
b=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
c=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));

u.DDN.jour=i ;
u.DDN.mois=b ;
u.DDN.annee=c ;
combobox1=lookup_widget(objet, "combobox40");
strcpy(u.role,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));

  int k0=modifier_utilisateur("utilisateur.txt", u,u.cin) ;
         
if (k0==1) 
   { gtk_label_set_text(GTK_LABEL(output22),"modification avec succes");} 
else 
   {gtk_label_set_text(GTK_LABEL(output22),"echec de modification");}


}


void
on_button_afficher_modifier_clicked    (GtkWidget      *objet,
                                        gpointer         user_data)
{
int a;
int i=0;
char cin1[30];

GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;

GtkWidget *cin ,*nom ,*prenom,*login,*mdp,*vote,*numbv;
GtkWidget *role,*output,*homme,*femme ;



output = lookup_widget(objet, "output_4070");
cin=lookup_widget(objet,"cin_modifier");
nom = lookup_widget(objet, "nom_modifier");
prenom = lookup_widget(objet, "prenom_modifier");
login = lookup_widget(objet, "login_modifier");
mdp = lookup_widget(objet, "mdp_modifier");

jour=lookup_widget(objet, "spinbutton_jour01");
mois=lookup_widget(objet, "spinbutton_mois02");
annee=lookup_widget(objet, "spinbutton_annee02"); 
role=lookup_widget(objet, "combobox40");
homme=lookup_widget(objet, "homme_modifier"); 
femme=lookup_widget(objet, "femme_modifier");
vote=lookup_widget(objet, "vote_modifier");
numbv=lookup_widget(objet, "numbv_modifier");


strcpy(cin1,gtk_entry_get_text(GTK_ENTRY(cin)));
utilisateur k=chercher_utilisateur("utilisateur.txt" ,cin1) ;

if (strcmp(k.cin,"introuvable")==0)
{gtk_label_set_text(GTK_LABEL(output),"cin n'est pas trouver") ;
}
else {
if (strcmp(k.cin,"introuvable")!=0)
{gtk_label_set_text(GTK_LABEL(output),"cin trouvé") ;

gtk_entry_set_text(GTK_ENTRY(nom),k.nom);
gtk_entry_set_text(GTK_ENTRY(prenom),k.prenom);

gtk_entry_set_text(GTK_ENTRY(login),k.conx.login);
gtk_entry_set_text(GTK_ENTRY(mdp),k.conx.mdp);





if (strcmp("Administrateur",k.role)==0)
     gtk_combo_box_set_active(GTK_COMBO_BOX(role),0);

if (strcmp("Electeur",k.role)==0)
     gtk_combo_box_set_active(GTK_COMBO_BOX(role),1);

if (strcmp("Agent_de_bureau_de_vote",k.role)==0)
     gtk_combo_box_set_active(GTK_COMBO_BOX(role),2);

if (strcmp("Observateur",k.role)==0)
     gtk_combo_box_set_active(GTK_COMBO_BOX(role),3);



gtk_spin_button_set_value(jour,k.DDN.jour);
gtk_spin_button_set_value(mois,k.DDN.mois);
gtk_spin_button_set_value(annee,k.DDN.annee);

if (strcmp(k.genre,"Homme")==0)
{
gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON (homme),TRUE);
}

else if (strcmp(k.genre,"Femme")==0)
{
gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON (femme),TRUE);
}
char ch1[30] ;
char ch2[30] ;

sprintf(ch1,"%d",k.numbv) ;
sprintf(ch2,"%d",k.vote) ;





gtk_entry_set_text(GTK_ENTRY(numbv),ch1);
gtk_entry_set_text(GTK_ENTRY(vote),ch2);











}


}



}


void
on_homme_modifier_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{ if(gtk_toggle_button_get_active(togglebutton))
    {z=1;}

}


void
on_femme_modifier_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
  if(gtk_toggle_button_get_active(togglebutton))
     {z=2;}
}








void
on_button_identifier1_clicked          (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{int verif ;
GtkWidget *espace_adminstrateur;
  GtkWidget *espace_electeur;
  GtkWidget *espace_observateur;
  GtkWidget *espace_agent_de_bureau_de_vote;
GtkWidget *login, *password , *fenetre1,*w;
GtkWidget *output;
GtkWidget *treeview1;
char log[30];
char pw[30];
int trouve;
login=lookup_widget(objet_graphique,"login1");
password=lookup_widget(objet_graphique,"mdp1");
strcpy(log,gtk_entry_get_text(GTK_ENTRY(login)));
strcpy(pw,gtk_entry_get_text(GTK_ENTRY(password)));
utilisateur u=chercher_utilisateur_souhail("utilisateur.txt", log,pw);
 verif=verif_souhail (log, pw) ;

if (verif==0){
output=lookup_widget(objet_graphique,"msg");
gtk_label_set_text(GTK_LABEL(output),"Incorrect Values");
}
else {if(strcmp(u.role,"Administrateur")==0)
{
w=lookup_widget(objet_graphique,"authentification");
gtk_widget_destroy(w);
espace_adminstrateur = create_espace_adminstrateur ();
  gtk_widget_show (espace_adminstrateur);

}
else {   
        if(strcmp(u.role,"Electeur")==0)
{
w=lookup_widget(objet_graphique,"authentification");
gtk_widget_destroy(w);
 espace_electeur = create_espace_electeur ();
  gtk_widget_show (espace_electeur);
}
else{ 
    if(strcmp(u.role,"Agent_de_bureau_de_vote")==0)
{
w=lookup_widget(objet_graphique,"authentification");
gtk_widget_destroy(w);
 espace_agent_de_bureau_de_vote = create_espace_agent_de_bureau_de_vote ();
  gtk_widget_show (espace_agent_de_bureau_de_vote);
}
else {
        if(strcmp(u.role,"Observateur")==0)
{
w=lookup_widget(objet_graphique,"authentification");
gtk_widget_destroy(w);
 espace_observateur = create_espace_observateur ();
  gtk_widget_show (espace_observateur);

    
}

}
    
}
}
}

}


void
on_stat_souhail_clicked                (GtkWidget      *objet,
                                        gpointer         user_data)
{GtkWidget *w,*supprimer_un_utilisateur;
w=lookup_widget(objet,"fenetre1");
gtk_widget_destroy(w);
supprimer_un_utilisateur = create_stat_souhail ();
  gtk_widget_show (supprimer_un_utilisateur);

}


void
on_afficher_souhail1_clicked           (GtkWidget      *objet,
                                        gpointer         user_data)
{GtkWidget *combobox ,*fenetre1,*treeview1,*w;

char ROLE[100];
combobox=lookup_widget(objet, "combobox4100");
strcpy(ROLE,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox)));
///------------------------------------------------///
if(strcmp(ROLE,"Electeur")==0){
utilisateur u;
    FILE * f=fopen("utilisateur.txt", "r");
    FILE * f2=fopen("electeur.txt", "w");
    if(f!=NULL && f2!=NULL)
    {
        while(fscanf(f,"%s %s %s %s %d %d %d %s %s %s %d %d\n",u.cin,u.nom,u.prenom,u.genre,&u.DDN.jour,&u.DDN.mois,&u.DDN.annee,u.conx.login,u.conx.mdp,u.role,&u.vote,&u.numbv)!=EOF)
        {
            if(strcmp(ROLE,u.role)==0)
            
               {fprintf(f2,"%s %s %s %s %d %d %d %s %s %s %d %d\n",u.cin,u.nom,u.prenom,u.genre,u.DDN.jour,u.DDN.mois,u.DDN.annee,u.conx.login,u.conx.mdp,u.role,u.vote,u.numbv);}

        }
    }
    fclose(f);
    fclose(f2);
    

w=lookup_widget(objet,"fenetre1");
gtk_widget_hide(w);


fenetre1 = create_fenetre1 ();
  gtk_widget_show (fenetre1);

treeview1=lookup_widget(fenetre1,"treeview1");
afficher_electeur(treeview1);
}
///-------------------------------------------///

if(strcmp(ROLE,"Administrateur")==0){
utilisateur u;
    FILE * f=fopen("utilisateur.txt", "r");
    FILE * f2=fopen("admin.txt", "w");
    if(f!=NULL && f2!=NULL)
    {
        while(fscanf(f,"%s %s %s %s %d %d %d %s %s %s %d %d\n",u.cin,u.nom,u.prenom,u.genre,&u.DDN.jour,&u.DDN.mois,&u.DDN.annee,u.conx.login,u.conx.mdp,u.role,&u.vote,&u.numbv)!=EOF)
        {
            if(strcmp(ROLE,u.role)==0)
            
               {fprintf(f2,"%s %s %s %s %d %d %d %s %s %s %d %d\n",u.cin,u.nom,u.prenom,u.genre,u.DDN.jour,u.DDN.mois,u.DDN.annee,u.conx.login,u.conx.mdp,u.role,u.vote,u.numbv);}

        }
    }
    fclose(f);
    fclose(f2);
    

w=lookup_widget(objet,"fenetre1");
gtk_widget_hide(w);


fenetre1 = create_fenetre1 ();
  gtk_widget_show (fenetre1);

treeview1=lookup_widget(fenetre1,"treeview1");
afficher_administrateur(treeview1);
}


///---------------------------------------///

if(strcmp(ROLE,"Agent_de_bureau_de_vote")==0){
utilisateur u;
    FILE * f=fopen("utilisateur.txt", "r");
    FILE * f2=fopen("agent.txt", "w");
    if(f!=NULL && f2!=NULL)
    {
        while(fscanf(f,"%s %s %s %s %d %d %d %s %s %s %d %d\n",u.cin,u.nom,u.prenom,u.genre,&u.DDN.jour,&u.DDN.mois,&u.DDN.annee,u.conx.login,u.conx.mdp,u.role,&u.vote,&u.numbv)!=EOF)
        {
            if(strcmp(ROLE,u.role)==0)
            
               {fprintf(f2,"%s %s %s %s %d %d %d %s %s %s %d %d\n",u.cin,u.nom,u.prenom,u.genre,u.DDN.jour,u.DDN.mois,u.DDN.annee,u.conx.login,u.conx.mdp,u.role,u.vote,u.numbv);}

        }
    }
    fclose(f);
    fclose(f2);
    

w=lookup_widget(objet,"fenetre1");
gtk_widget_hide(w);


fenetre1 = create_fenetre1 ();
  gtk_widget_show (fenetre1);

treeview1=lookup_widget(fenetre1,"treeview1");
afficher_agent(treeview1);
}

//**************************//
if(strcmp(ROLE,"Observateur")==0){
utilisateur u;
    FILE * f=fopen("utilisateur.txt", "r");
    FILE * f2=fopen("observateur.txt", "w");
    if(f!=NULL && f2!=NULL)
    {
        while(fscanf(f,"%s %s %s %s %d %d %d %s %s %s %d %d\n",u.cin,u.nom,u.prenom,u.genre,&u.DDN.jour,&u.DDN.mois,&u.DDN.annee,u.conx.login,u.conx.mdp,u.role,&u.vote,&u.numbv)!=EOF)
        {
            if(strcmp(ROLE,u.role)==0)
            
               {fprintf(f2,"%s %s %s %s %d %d %d %s %s %s %d %d\n",u.cin,u.nom,u.prenom,u.genre,u.DDN.jour,u.DDN.mois,u.DDN.annee,u.conx.login,u.conx.mdp,u.role,u.vote,u.numbv);}

        }
    }
    fclose(f);
    fclose(f2);
    

w=lookup_widget(objet,"fenetre1");
gtk_widget_hide(w);


fenetre1 = create_fenetre1 ();
  gtk_widget_show (fenetre1);

treeview1=lookup_widget(fenetre1,"treeview1");
afficher_observateur(treeview1);
}


}


void
on_calculer97_clicked                  (GtkWidget      *objet,
                                        gpointer         user_data)
{GtkWidget *tvb,*tpe;

float a,b ;

char ch1[30];
char ch2[30];


tvb=lookup_widget(objet,"label97");
tpe=lookup_widget(objet,"label98");

  a= TPE("utilisateur.txt");
     b=TVB("utilisateur.txt");

sprintf(ch1,"%f",a);
sprintf(ch2,"%f",b);



gtk_label_set_text(GTK_LABEL(tvb),ch1);
gtk_label_set_text(GTK_LABEL(tpe),ch2);



}


void
on_retourner_stat0123_clicked          (GtkWidget      *objet,
                                        gpointer         user_data)
{GtkWidget *w,*fenetre1;
GtkWidget *treeview1 ; 

w=lookup_widget(objet,"stat_souhail");
gtk_widget_hide(w);
fenetre1 = create_fenetre1 ();
  gtk_widget_show (fenetre1);
treeview1=lookup_widget(fenetre1,"treeview1");
afficher_utilisateur(treeview1);

}


void
on_actualiser_souhail02_clicked        (GtkWidget      *objet,
                                        gpointer         user_data)
{GtkWidget *w,*fenetre1 ;
GtkWidget *treeview1 ;
w=lookup_widget(objet,"fenetre1");
gtk_widget_hide(w);


fenetre1 = create_fenetre1 ();
  gtk_widget_show (fenetre1);

treeview1=lookup_widget(fenetre1,"treeview1");
afficher_utilisateur(treeview1);

}


void
on_ok_12_clicked                       (GtkWidget      *objet,
                                        gpointer         user_data)
{GtkWidget *w ;
w=lookup_widget(objet,"ajout_succes");
gtk_widget_hide(w);
}

