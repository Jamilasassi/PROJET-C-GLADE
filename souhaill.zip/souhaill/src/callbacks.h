#include <gtk/gtk.h>


void
on_button_gestion_des_utilisateurs_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_comboboxentry10_changed             (GtkComboBox     *combobox,
                                        gpointer         user_data);

void
on_button_ajouter_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_modifier_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_supprimer_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_retour_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_retourner_ajout_clicked      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_retourner_modifier_clicked   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_retourner_supprimer_clicked  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_radiobutton_homme_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_femme_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_ajouter1_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);





void
on_button_identifier1_clicked          (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_checkbutton_supprimer_utilisateur_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_supprimer1_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_supprimer2_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);
/*
void
on_femme_modifier_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);*/

void
on_button_modifier1_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_afficher_modifier_clicked    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_homme_modifier_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_femme_modifier_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_identifier1_clicked          (GtkWidget      *objet_graphique,
                                        gpointer         user_data);




void
on_stat_souhail_clicked                (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_afficher_souhail1_clicked           (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_calculer97_clicked                  (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_retourner_stat0123_clicked          (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_actualiser_souhail02_clicked        (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_ok_12_clicked                       (GtkWidget      *objet,
                                        gpointer         user_data);
